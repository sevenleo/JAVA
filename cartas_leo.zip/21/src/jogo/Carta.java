package jogo;

public class Carta {

	private String Nome;
	private String Naipe;
	private int Valor;
	private int Valor2;
	
	
	
	
	


	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public String getNaipe() {
		return Naipe;
	}

	public void setNaipe(String naipe) {
		Naipe = naipe;
	}

	public int getValor() {
		return Valor;
	}

	public void setValor(int valor) {
		Valor = valor;
	}

	public int getValor2() {
		return Valor2;
	}

	public void setValor2(int valor2) {
		Valor2 = valor2;
	}

	
	
	

	
	public Carta(int num,String Np){
		
		this.Naipe=Np;
		
		
		if (num>=2 && num<=10){	
			this.Nome = ""+num;
			Valor=num;
			Valor2=num;
		}
		else if ( num==13 ||num==12|| num>=11) {
			Valor=10;
			Valor2=10;
			if (num==11) this.Nome="J";
			if (num==12) this.Nome="Q";
			if (num==13) this.Nome="K";
		} 
		else if (num==1 ){
			if (num==1) this.Nome="As";
			Valor=1;
			Valor2=11;
		}
		
		else System.out.println("Essa carta nao existe.");
		
		
	}
	
	
	@Override public String toString(){
		if (Valor!=Valor2) return this.Nome+" de " + this.Naipe + "=="+ this.Valor +" ou =="+ this.Valor2;
		return this.Nome+" de " + this.Naipe + "==="+ this.Valor ;
	}
}
