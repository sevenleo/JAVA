package jogo;

import java.util.ArrayList;
import java.util.Random;

import Controle.ControleRemoto;




public class Baralho implements ControleRemoto{
	

	private ArrayList<Carta> monte;
	
	
	
	public Baralho(){
		monte=new ArrayList<Carta>();
	}
	
	


	
	public void emBaralha(){
		this.addNaipe("copas");
		this.addNaipe("espadas");
		this.addNaipe("ouros");
		this.addNaipe("paus");
		
	}

	

	
	public void addNaipe(String np){
		int i;
		for(i=1;i<=13;i++){
			this.monte.add( new Carta(i, np) );
		}
		
	}

	

	public Carta sorteia(){
		
		Random luck = new Random();
		Carta sorte = monte.get( luck.nextInt( this.monte.size() ) );
	//	System.out.println("\n\nA sua sorte foi \n");
	//	System.out.println(sorte);
		this.monte.remove(sorte);
		return sorte;
	}
	
	
	
	public void quantas(){
		System.out.println("Temos "+this.monte.size()+" cartas no monte");
	}
	
	
	
	public ArrayList<Carta> getMonte() {
		return monte;
	}


	
	public void setMonte(ArrayList<Carta> monte) {
		this.monte = monte;
	}

	









}
