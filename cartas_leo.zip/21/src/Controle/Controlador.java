package Controle;

import java.util.Scanner;

public class Controlador implements ControleRemoto{

	
	public Controlador(){
		
	}
	
	public void saidaTela(String go){
		System.out.println(go);
	}
	
	public String entrada(){
		Scanner linha = new java.util.Scanner(System.in);
		return linha.next();
	}
	
}
