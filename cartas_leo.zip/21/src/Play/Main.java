package Play;
import jogo.*;

public class Main {

	/**
	 * @param args
	 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Baralho mesa = new Baralho();
		mesa.emBaralha();
		
		Jogador p1 = new Jogador("jogador");
		Jogador p2 = new Jogador("oponente");
		
		
		//for(int i=0;i<5;i++) mao.getMonte().add( deck.sorteia() );
		p1.puxa(5,mesa);
		p2.puxa(5,mesa);
		
		p1.show();
		p2.show();
		
		if ( p1.disputa(p2) )System.out.println("\n**ganhou");
		else System.out.println("\n**perdeu");
		
		
		
	}

}
