import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;


public class TesteDicionarioSerializado {
	static Dicionario dic;	
	static String arqDic = "";
	static Scanner sc = new Scanner(System.in);
	 
	public static void main(String[] args) {
		menu();
		
	}
	
	public static void menu(){
		boolean fim = false;
		while (!fim ){
			System.out.println("Dicion�rio Ingl�s-Portugu�s online");
			System.out.println("O que voc� deseja?");
			System.out.println("------------------");
			System.out.println("0. Abrir um dicion�rio existente");
			System.out.println("1. Iniciar um novo dicion�rio");
			System.out.println("2. Adicionar uma entrada no dicion�rio");
			System.out.println("3. Consultar uma palavra do dicion�rio");
			System.out.println("4. Modificar uma entrada do dicion�rio");
			System.out.println("5. Remover uma entrada do dicion�rio");
			System.out.println("6. Salvar o dicionario");
			System.out.println("7. Salvar e sair do programa");
			System.out.println("8. Sair do programa");
			System.out.println("------------------");
			int maiorOpcao = 8;
			String opcao;
			boolean opcaoBoa = false;
			int opcaoInt= 6;
			while(!opcaoBoa){
				System.out.print("Escolha a sua op��o e tecle ENTER a seguir: ");
				try{
					opcao = sc.nextLine();
					opcaoInt = Integer.parseInt(opcao);
					if (opcaoInt>= 0 && opcaoInt <=8){
						opcaoBoa = true;
					}
					else throw new NumberFormatException();
				}
				catch(NumberFormatException nfe){
					msgDestaque("Sua op��o deve ser um n�mero entre 0 e " + maiorOpcao);
				}
			}
			
			
			switch(opcaoInt){
				case 0: abrir(); break;
				case 1: novo(); break;
				case 2: adicionar(); break;
				case 3: consultar();break;
				case 4: modificar();break;
				case 5: remover();break;
				case 6: salvar(); break;
				case 7: salvar(); 
						System.out.println("Encerrando o programa... ");
				        fim = true; break;
				case 8: msgDestaque("Saindo sem salvar...."); fim = true;
			}
		}
	}
	
	public static void abrir(){
		System.out.println("Abrindo um dicion�rio existente. ");
		System.out.print("Digite o nome do arquivo serializado: ");
		arqDic = sc.nextLine();
		try{
			dic = Dicionario.recuperar(arqDic);
			msgDestaque("Dicionario " + dic.getNome()+ " aberto com sucesso");
		}
		catch (ClassNotFoundException cnfEx){
			System.out.println("Classe do dicion�rio n�o foi encontrada!");
		}
		catch (IOException ioe){
			System.out.println("N�o foi poss�vel abrir o arquivo "+ arqDic);
		}	
	}
	
	
	public static void novo(){
		dic = new Dicionario(); 
		System.out.println("Dicion�rio novo criado.");
		System.out.println("Nome do Dicion�rio: (ENTER se n�o tiver nome): ");
		String nomeDic = sc.nextLine();
		if (nomeDic!= "")dic.setNome(nomeDic);
	}
	
	public static void adicionar(){
		System.out.println("Adicionando par chave-valor ao dicion�rio...");
		System.out.print("Digite a chave: ");
		String chave = sc.nextLine();
		if (dic.getDados().containsKey(chave)){
			msgDestaque("O Diciin�rio j� contem essa chave");
		}
		else{
			System.out.print("Digite o valor: ");
			String valor = sc.nextLine();
			dic.adicionar(chave, valor);
			msgDestaque("Entrada adicionada");
		}
	}
	
	public static void consultar(){ 
		System.out.println("Consultando o dicion�rio...");
		System.out.print("Digite a chave da palavra a procurar:");
		String chave = sc.nextLine();
		String valor = dic.consultar(chave);
		if (valor == null){
			msgDestaque("A palavra " + chave + " n�o consta do dicion�rio.");
		}
		else{
			System.out.println(valor);
		}	
	}
	
	public static void modificar(){
		System.out.println("Alterando o valor correspondente a uma chave existente...");
		System.out.print("Digite a chave: ");
		String chave = sc.nextLine();
		if (dic.getDados().containsKey(chave)){
			System.out.println("Digite o valor: ");
			String valor = sc.nextLine();
			dic.adicionar(chave, valor);
			msgDestaque("Dicion�rio alterado com �xito");
		}
		else{
			msgDestaque("A palavra " + chave + " n�o consta do dicion�rio.");
		}
	}
	
	
	public static void remover(){
		System.out.println("Digite a chave a remover: ");
		String chave = sc.nextLine();
		if(dic.getDados().containsKey(chave)){
			dic.remover(chave);
		}
		else{
			msgDestaque("O dicion�rio n�o contem essa chave");
		}	
	}
	
	public static void salvar(){
		msgDestaque("Salvando....");
		if(arqDic.equals("")){
			System.out.print("Escolha o nome do arquivo a salvar serializado ");
			arqDic = sc.nextLine();
		}
		try{
			dic.salvar(arqDic);
			msgDestaque("Dicion�rio salvo com sucesso no arquivo " + arqDic);
		}
		catch(IOException fnf){
			msgDestaque("Erro ao tentar serializar o Dicion�rio");
		}
		
	}

	
	public static void msgDestaque(String msg){
		for(int i =0; i<msg.length(); i++){
			System.out.print("=");
		}
		System.out.println("\n"+msg);	
		for(int i =0; i<msg.length(); i++){
			System.out.print("=");
		}
		System.out.println();
	}

}
