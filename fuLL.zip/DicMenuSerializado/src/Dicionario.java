import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.TreeMap;


public class Dicionario implements Serializable{

	private static final long serialVersionUID = -7700142151088656725L;
	
	private String nome;
	private TreeMap<String,String> dados ;
	
	public Dicionario(String nome) {
		this();
		this.nome = nome;

	}
	
	public Dicionario(){
		dados =new TreeMap<String, String>();
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public TreeMap<String, String> getDados() {
		return dados;
	}

	public void setDados(TreeMap<String, String> dados) {
		this.dados = dados;
	}
	
	public void adicionar(String ing, String port){
		dados.put(ing, port);
	}
	
	public String consultar(String ing){
		return dados.get(ing);
	}
	
	public void remover(String chave){
		dados.remove(chave);
	}
	
	public void salvar(String arquivo)throws FileNotFoundException, IOException{
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(arquivo));
			oos.writeObject(this);
			oos.close();		
	}	
	
	public static Dicionario recuperar(String arquivo)throws IOException, ClassNotFoundException{
		Dicionario dic = null;
		ObjectInputStream ois = 
		new ObjectInputStream(new FileInputStream(arquivo));
		dic = (Dicionario)ois.readObject();
		ois.close();
		return dic;
	}

}

