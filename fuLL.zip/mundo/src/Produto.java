import java.io.Serializable;


public class Produto extends Caminhao implements Serializable{
	
	public String nome;
	public int quantidade;
	public float preco;


		//construtor
		public Produto (String nome2,float preco2,int quantidade2){
			nome=nome2;
			preco = preco2;
			quantidade = quantidade2;
		}
		
		
		public void ShowProduto(){
			System.out.println("Quer comprar "+this.nome+" por "+this.preco+"dins ?");
			System.out.println("Ol� n�s temos "+this.quantidade+" "+this.nome+"(s)");
			System.out.println("produto Made in "+this.importado);
		}
		public String venda(Pessoa pessoa){
			
			if (this.quantidade <=0){
				
				return "> Acabou o chouri�o troXa!! xD";
			} 
			else{
				if (pessoa.Dinheiro < this.preco){
					return "Voce nao tem dinheiro suficiente \n vai trabalhar. _|_";
				}
				else{
					this.quantidade=this.quantidade-1;
					pessoa.Dinheiro=pessoa.Dinheiro-this.preco;
					return "Obrigado por compar, o meu bolso agradece =)";
				}
				
		
			}
		}
				
		
}
