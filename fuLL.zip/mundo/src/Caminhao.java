
public class Caminhao {

	public String importado;
	
	public Caminhao(){
		importado = "Brasil";
	}
	
	
}
