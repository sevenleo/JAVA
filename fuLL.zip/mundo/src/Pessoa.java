import java.util.Scanner;
import java.io.*;

public class Pessoa implements Serializable{

	/**
	 * @param args
	 */
	public String Nome;
	public int Id;
	public float Dinheiro;
	public String Status;
	
	
	public void statuzeitor() {
		setStatus("Fudido");
		if (Dinheiro >= 1000){
			setStatus("De bem com a vida");
			if (Dinheiro >= 2000){
				setStatus("Rico");
				if (Dinheiro >= 5000 && Nome.equals("leo") ){
					setStatus("Sou Foda - Digdin Digdin");
				}
			}
			System.out.println("++++Seu status foi mudado!!");
		}
		
	}
	
	
	
	
	
	
	public void identificator(){
		
	}
	
	public boolean Passear(){
		Scanner Digita = new java.util.Scanner (System.in);
		System.out.println("::Digite para caminhar::");		
		int i=1;
		while(!Digita.next().equals("voltar")){
	
				System.out.println(" .... Passeando .... \nVoce percorreu '"+i +" KM'");
				System.out.println("Se quiser 'voltar' para casa � s� digitar.");
				i=i+1;
			
		}
		return false;
	}
	
	public void  LamberSabao(){
		System.out.println("ECA!!!");
	}
	
	public void Nada() {
		System.out.println("Descanse..");
		Scanner Digita = new java.util.Scanner (System.in);
		while( !Digita.next().equals("descansei")){
			
		}
	}
	
	
	
	public void ShowPessoa(){

		System.out.println("-------------------------------");
		System.out.println("Ol� '"+this.Nome + "' seu ID � '" + this.Id+"'");
		System.out.println("voce tem " + this.Dinheiro + "Dins");
		System.out.println("Voce � '" + this.Status +"'");

	}
	
	public boolean changePessoa(){
		boolean continua=true;
		String MenuPessoa;
		
		//inicia o uso do teclado
		Scanner Teclado = new java.util.Scanner (System.in);
		
		System.out.println("Quer alterar alguma caracter�stica?");
		System.out.print(" .. din,nome,id,nao?");
		
		MenuPessoa =Teclado.next();

		if (  MenuPessoa.equals("status") ){ 
			System.out.println("Voce nao pode mundar seu status");
		
		}
		if (  MenuPessoa.equals("dinheiro") || MenuPessoa.equals("din")){ 
			System.out.println("Entao quantos Dins voce tem?");
			this.setDinheiro(Teclado.nextFloat());
		}
		if (  MenuPessoa.equals("id") ){ 
			System.out.println("Entao qual seu Id?");
			this.setId(Teclado.nextInt());
			
		}
		if (  MenuPessoa.equals("nome") ){ 
			System.out.println("Entao qual seu Nome?");
			this.setNome(Teclado.next());
		}
		if (MenuPessoa.equals("nao")){
			continua = false;
		}
		
		
		this.statuzeitor();
		
		return continua;
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public float getDinheiro() {
		return Dinheiro;
	}

	public void setDinheiro(float dinheiro) {
		Dinheiro = dinheiro;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	
	//construtor
	public Pessoa(){
		Nome = "Ninguem";
		Id = 0000;
		Dinheiro = 545;
		Status = "Normal";
	}
	
	
	
	
		
	
}
