import java.io.*;
import java.util.Scanner;


public class Loja implements Serializable{

	public String Nome;
	public String Endereco;
	public boolean portas;
	public boolean aberta = true;
	public Produto chourico = new Produto("Chouri�o",200,2);
	
	public void loja(Pessoa pessoa){
		
		Scanner Digita = new java.util.Scanner (System.in);
		String escolhe;
		aberta=true;
		while(aberta==true){
			pessoa.ShowPessoa();
			System.out.println("Voce est� na loja");
			
			chourico.ShowProduto();
			System.out.println("sim ou nao(sair)");
			
			escolhe= Digita.next();
			if (escolhe.equals("sim")){
				System.out.println(chourico.venda(pessoa));
				System.out.println("Voce ainda tem "+pessoa.Dinheiro+"dins");
				
			}
			if (escolhe.equals("sair") || escolhe.equals("nao")){
				aberta=false;
			}
			
		}
	}
	
}
