import java.util.*;
import java.io.*;
/*import java.util.ArrayList;
import java.io.Serializable;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
*/





public class BancoDados implements Serializable{

	
	
	
	
	
	
	
	public BancoDados(){
		ArrayList<Pessoa> Dados = new ArrayList<Pessoa>();
	}
	
	
	
	
	
	
	
	
	public void salva(Pessoa spessoa,Loja sloja) {

			
			try	{
				String str = "Estou salvando pra nao esquecer como se faz serializacao";
				
				FileOutputStream data = null;
				System.out.println("Digite o arquivo aonde quer salvar .:.");
				data = new FileOutputStream(  new java.util.Scanner(System.in).nextLine()   );
				
				ObjectOutputStream save  = new ObjectOutputStream(data);
				
				
				
				
				System.out.println("gravando ........");
				//save.writeChars(spessoa.Nome);
				//save.writeFloat(spessoa.Dinheiro);
				//save.writeChars(str);		
		
				save.writeObject(spessoa);
				
				System.out.println("                .....");
				//entra.flush();
				save.writeObject(sloja);
				save.flush();
				System.out.println("                		.....");
				save.close();
		        System.out.println("                				.....");
		        save.flush();
		        System.out.println("                						.....");
		        data.close();
		
		        System.out.println("JOGO SALVO");
			}
			catch(FileNotFoundException e){
				System.out.println("\n\nBurro .. o file nao existe\n");
				e.printStackTrace( );
			}
			catch(IOException e ){
				System.out.println("\n\n TELA AZUL ~~~~~~~ TELA AZUL \n");
				e.printStackTrace( );
			}
	}
	
	
	
	
	
	
	
	
	
	public void carrega(Pessoa spessoa,Loja sloja) throws IOException, ClassNotFoundException {
		System.out.println("Digite o arquivo para LOAD ...");
		String arq = new java.util.Scanner(System.in).nextLine()  ;
		
		FileInputStream data= new FileInputStream(arq);
		spessoa =carregapessoa(data);
		//sloja = carregaloja(data);
		data.close();
	}
		/*
		 Pessoa p = null;
		
		Loja l=null;
		
		try{
				System.out.println("Digite o arquivo para LOAD ...");
				FileInputStream data= new FileInputStream(  new java.util.Scanner(System.in).nextLine()   );
				//data=new FileInputStream("leo.rox");
				ObjectInputStream load= new ObjectInputStream(data);
				
				p = (Pessoa) load.readObject();
				
				l=(Loja)load.readObject();
				
				data.close();
			}
			catch(FileNotFoundException e){
				System.out.println("\n\nBurro .. o file nao existe\n");
				e.printStackTrace( );
			}
			catch(IOException e ){
				System.out.println("\n\n TELA AZUL ~~~~~~~ TELA AZUL \n");
				e.printStackTrace( );
			}
			catch(ClassNotFoundException e){
				System.out.println("Caregando a coisa errada!");
				e.printStackTrace( );
				
			}
			
			spessoa=p;
			sloja=l;
			
		
	}*/
	
	
	public Pessoa carregapessoa(FileInputStream data) throws IOException, ClassNotFoundException{
		ObjectInputStream load= new ObjectInputStream(data);
		return (Pessoa) load.readObject();
	}
	public Loja carregaloja(FileInputStream data) throws IOException, ClassNotFoundException{
		ObjectInputStream load= new ObjectInputStream(data);
		
		return (Loja)load.readObject();
	}
	
}
