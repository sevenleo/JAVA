
public class Crianca {

/*
		public String Nome;
		private String Sexo;
		public String sorte;

		//� errado fazer
		//Crianca c = new Crianca;

			public String MetodoDeOndeVemOsBebes(){

				pai.getMae();
				mae.setCama();
				pai.setEsperma();
				
			return bebe;		
				
			} 	
*/

		
}
