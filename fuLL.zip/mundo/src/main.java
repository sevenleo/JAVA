import java.io.IOException;
import java.util.Scanner;



public class main {
	
	
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		
		boolean mundogira = true;
		boolean acao = true;
		boolean loja = false,passear=false,lambersabao = false, showpessoa=false;
		Pessoa Leo = new Pessoa();
		Loja Loja1 = new Loja();
		String MenuAcao;
		
		
		
		//Leo.Nome = "Leo Neves";
		//Leo.Dinheiro = 500;
		//Leo.Id = 7007;
		//Leo.Status = "normal";
		
		//inicia o uso do teclado
		Scanner linha = new java.util.Scanner (System.in);
	
			//loopinfinito
			while(mundogira == true){	
				
				//menu de acao
				while(acao == true){
					
					System.out.println("O que quer fazer?");
					System.out.println(" .. eu,loja, passear,lamber sabao,sair , SAVE OU LOAD");
					MenuAcao = linha.next();
					
					if(MenuAcao.equalsIgnoreCase("loja")){
						loja = true;
						acao=false;
					}
					if(MenuAcao.equalsIgnoreCase("passear")){
						passear = true;
						acao=false;
					}
					if( MenuAcao.equalsIgnoreCase("lamber") || MenuAcao.equalsIgnoreCase("lamber sabao") || MenuAcao.equalsIgnoreCase("sabao")){
						lambersabao = true;
						acao=false;
					}
					if(MenuAcao.equalsIgnoreCase("eu")){
						showpessoa = true;
						acao=false;
					}
					if(MenuAcao.equalsIgnoreCase("sair")){
						acao = false;
						mundogira=false;
						System.out.println("      !!!Adeus mundo cruel!!!");
					}
					
					if(MenuAcao.equalsIgnoreCase("nada")){
						Leo.Nada();
					}
					
					if(MenuAcao.equalsIgnoreCase("save") || MenuAcao.equalsIgnoreCase("load")){
						
						BancoDados banco = new BancoDados();
						if ( MenuAcao.equalsIgnoreCase("save")) banco.salva(Leo, Loja1);
						if ( MenuAcao.equalsIgnoreCase("load")) banco.carrega(Leo, Loja1);
						/*try {
							BancoDados.class.newInstance().salvar(Leo, Loja1);
						} 
						catch (InstantiationException e) { System.out.println("\n\nMerda1"); }
						catch (IllegalAccessException e) { System.out.println("\n\nMerda2"); }
						*/
					}
					
					
					
					
				}//acao
				
				//PESSOA
				while (showpessoa == true){
					Leo.ShowPessoa();
					showpessoa = Leo.changePessoa();
					acao=!showpessoa;
					/*if (Leo.MenuPessoa.equalsIgnoreCase("nao")){
						showpessoa = false;
						acao=true;
					}*/
					
				}//pessoa
			
				//PASSEAR
				while (passear == true){
						passear = Leo.Passear();
						acao=true;
					
					
				}//passear
				
				//LOJA
				while(loja==true){
					Loja1.loja(Leo);
					loja=false;
					acao=true;
				}//loja
				
				//lmbersabao
				while(lambersabao==true){
					Leo.LamberSabao();
					lambersabao=false;
					acao=true;
				}//lambersabao
				
				
		}//infinito			
			

			
	}//main
	
	
	
	
	

	
	
	
	
	
}//class
