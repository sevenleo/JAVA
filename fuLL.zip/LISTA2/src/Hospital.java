import java.util.Scanner;


public class Hospital extends Lugar {

	private String consulta;
	
	public Hospital(){
		Nome="Hospital Santa Clara da Escuridao";
		this.consulta="Sem consulta marcada!";
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void ir(String VaiPara, Pessoa pessoa){
	
		
		VaiPara=VaiPara.toLowerCase();
		if (VaiPara.endsWith("ir")|| VaiPara.equals("naosei") || VaiPara.equals("casa") || VaiPara.equals("loja") || VaiPara.equals("sair") || VaiPara.equals("hospital") || VaiPara.equals("deposito")|| VaiPara.equals("estalagem") || VaiPara.equals("praca") ){	

				if(VaiPara.endsWith("loja")){			System.out.println(" ** Nao tem caminho para la. Verifique o mapa.");		}
				if(VaiPara.endsWith("casa")){			pessoa.Local="casa";		}
				if(VaiPara.endsWith("hospital")){		System.out.println(" ** Ja estamos no <HOSPITAL>.");		}
				if(VaiPara.endsWith("deposito")){		System.out.println(" ** Nao tem caminho para la. Verifique o mapa.");		}
				if(VaiPara.endsWith("estalagem")){		System.out.println(" ** Nao tem caminho para la. Verifique o mapa.");		}
				if(VaiPara.endsWith("praca")){			pessoa.Local="praca";		}
				if(VaiPara.endsWith("sair")){			pessoa.Local="sair";	 System.exit(0);	}
				if(VaiPara.endsWith("naosei")){			System.out.println("Voce pode ir para:   <PRACA>,<CASA> OU <SAIR>");		}
				if(VaiPara.endsWith("ir")) {
					System.out.println("Vai para onde? <NAOSEI>");
					Scanner linha = new java.util.Scanner(System.in);
					this.ir(linha.nextLine(), pessoa );
				}
			
		}
		else{
			System.out.println("\n  *   Esse lugar n�o existe na cidade.Arrume um Mapa");
		}
		
	
		
		
	}
	
	
	
	
	public void listar(){
		System.out.println("Aqui temos um [medico], um [recepcionista] e uma {TV} ");
		System.out.println("Daqui podemos [ir] para  <casa>,<praca> ou <sair>");
	}
	
	
	
	public void olhar(String capta){
		if(capta.endsWith("olhar")) System.out.println("    Voce esta em no(a) "+this.Nome+" aqui tem um [Recepcionista],  uma {tv} ligada em algum canal e varios [medico] passando");
		if(capta.endsWith("recepcionista")) System.out.println("Se quiser marcar uma consulta va ate a recepcao");
		if(capta.endsWith("tv")) System.out.println("Esta passando um filme muito chato na sessao da tarde!  =/  ");
		if(capta.endsWith("medico")) System.out.println("Se quiser falar com algum medico vai precisar entrar em sem caminho, pois eles parecem muito atarefados.");
		
		
	}
	
	
	
	
	
	
	
	
	

	public void interagir(String capta,Pessoa voce){
		if(capta.endsWith("medico")) this.medico(voce);
		if(capta.endsWith("recepcionista")) this.recepcionista(voce);
	
	}
	
	
	public void medico (Pessoa voce){
		Scanner linha = new java.util.Scanner(System.in);
		String resposta; 
		System.out.println("O que voce quer? Estou com pressa tenho varios pacientes para atender\n (diga-> tratar)");
		resposta=linha.nextLine();
		resposta=resposta.toLowerCase();
		if (resposta.equals("tratar")) {
			System.out.println(" Tome esse remedio que ficara bem.");
			System.out.println("   Agora me de licenca e marque uma consulta com o [recepcionista].");
			voce.saude+=50; 
		}else{
			System.out.println("Se nao esta doente,me de licenca. Adeus.");
		}
	}
	
	
	public void recepcionista (Pessoa voce){
		int dia=0,mes=0,ano=0;
		Scanner linha = new java.util.Scanner(System.in);
		String resposta;
		
		System.out.println("Bom dia!\n gostaria de marcar uma consulta? <sim><nao>");
		resposta=linha.nextLine();
		resposta=resposta.toLowerCase();
		if (resposta.equals("sim")) {
			
				System.out.println("Para qual ano ser� a consulta?");
				ano=linha.nextInt();
				if (ano<2012){
						System.out.println("Escolha apartir de 2012!");
					
				}
				else{
						System.out.println("Para qual mes sera a consulta? [diga o numero]");
						mes=linha.nextInt();
						if (mes>12 || mes<=0){
							System.out.println("Escolha de 1 a 12!");
						}
						else{
							System.out.println("Para qual dia sera a consulta? [diga o numero]");
							dia=linha.nextInt();
							if (dia>30 || dia<=0){
								System.out.println("Escolha de 1 a 30!");
							}
							else{
								this.consulta="Sua consulta esta marcada para "+dia+"/"+mes+"/"+ano;
								System.out.println(this.consulta);
							}
							
						}

				}
				
		}
		else{
				System.out.println("Ja tem consulta marcada?");
				resposta=linha.nextLine();
				resposta=resposta.toLowerCase();
				if (resposta.equals("sim")) {
					System.out.println(this.consulta);
				}
				else{
					System.out.println("Dificilmente vai conseguir se tratar sem consulta marcada");	
				}
			
		}
	}
	
	
	
	
	
}
