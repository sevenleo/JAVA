
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			boolean GiraMundo= true;	
			System.out.println("Mundo Girando...");
			
			
			Pessoa Men = new Pessoa();
			Casa Casa1 = new Casa();
			Loja Loja1 = new Loja();
			Praca Praca1 = new Praca();
			Estalagem Estalagem1 = new Estalagem();	
			Hospital Hospital1 = new Hospital();	
			Deposito Deposito1 = new Deposito();	
			
			Men.Carrega("mapa");
			Men.Carrega("lapis");
			Men.Carrega("chinelo");
			
//			System.out.println("Ola '"+Men.Nome+"' Voce esta no(a) '"+Men.Local+"' com "+Men.Din+"dins");
					
			while(GiraMundo == true){
	
								
					if( Men.Local.equals("casa")){
						Casa1.EmCasa(Men);
						
					}//if
							
							
					if(Men.Local.equals("loja")){
						Men.Local="loja";
						Loja1.aberto(Men);
					
						
					}//if
					
					if(Men.Local.equals("praca")){
						Men.Local="praca";
						Praca1.aberto(Men);
			
						
					}//if
					
					if(Men.Local.equals("estalagem")){
						Men.Local="estalagem";
						Estalagem1.aberto(Men);
					
					}//if
					
					if(Men.Local.equals("hospital")){
						Men.Local="hospital";
						Hospital1.aberto(Men);
			
					}//if
					
					if(Men.Local.equals("deposito")){
						Men.Local="deposito";
						Deposito1.aberto(Men);
				
					}//if
					
						
					if( Men.Local.equals("sair")){
						System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
						System.out.println("Adeus Mundo Cruel!!!!!!!");
						System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
						GiraMundo=false;
						
					}//if
					
	
			}//Mundo
	
	
	
		
	}//main

}//main classe
