
import java.util.*;

public class Lugar {

	
	String Nome;

	
	
	//funcao para caso seja criado um lugar ainda sem funcao
	public void aberto(Pessoa P){
		Scanner linha = new java.util.Scanner(System.in);

		
		System.out.println("------------------------------------------------------------");
		System.out.println("Ola '"+P.Nome+"' voce ja chegou no(a) '"+this.Nome+"'");
		while(true){
			System.out.println("    \nO que deseja fazer por aqui no(a) '"+this.Nome+"' ?");
			System.out.println("     [listar]  [eu] [interagir *]  [ir *]  {olhar *}");
			//this.listar(P);
			String capta = linha.nextLine();
			capta=capta.toLowerCase();
			
			
			if ( capta.startsWith("sair")||capta.startsWith("ir") || capta.startsWith("olhar") || capta.startsWith("listar") || capta.startsWith("interagir") || capta.startsWith("eu")){
			
					if(capta.startsWith("sair")) System.exit(0);	
					if(capta.startsWith("eu")) {
						P.ShowPessoa(); P.changePessoa(); 
					}
					if (capta.startsWith("olhar")) this.olhar(capta); 
					if (capta.startsWith("listar")) this.listar();
					if (capta.startsWith("interagir")) this.interagir(capta,P);
					if (capta.startsWith("ir")){
					
								if(capta.endsWith("loja")){
									this.ir("loja",P);
									break;
								}
								if(capta.endsWith("casa")){
									this.ir("casa",P);
									break;
								}
								if(capta.endsWith("hospital")){
									this.ir("hospital",P);
									break;
								}
								if(capta.endsWith("deposito")){
									this.ir("deposito",P);
									break;
								}
								if(capta.endsWith("estalagem")){
									this.ir("estalagem",P);
									break;
								}
								if(capta.endsWith("praca")){							
									this.ir("praca",P);
									break;
								}
								if(capta.endsWith("sair")){
									this.ir("sair",P);
									break;
								}
								if(capta.endsWith("ir") ){
									System.out.println(" para onde? <naosei>"); 
									this.ir(linha.nextLine(),P);
									break;
								}
							
					}//if_starts
			}//ir,olhar,interagir,listar
			else{
				System.out.println("\n  ** Esse comando n�o � valido aqui **");
			}
			
			
			
			
			
			
			
			
			
			
			
		}
		
	}//abertolo
	
	
	
	
	

	public void olhar(String capta){
		
	}
	
	public void listar(){
		System.out.println("Aqui tem 2 NPCS E 1 OBSERVAVEL ");
		System.out.println("E o mapa nos mostra os caminhos.");
				
	}

	public void interagir(String capta,Pessoa voce){
	
	}

	
	
	
	
	
	
	
	
	public void ir(String VaiPara, Pessoa pessoa){
		
		VaiPara=VaiPara.toLowerCase();
		if (VaiPara.endsWith("ir")|| VaiPara.endsWith("sair") || VaiPara.endsWith("naosei") || VaiPara.endsWith("casa") || VaiPara.endsWith("loja") ||  VaiPara.endsWith("hospital") || VaiPara.endsWith("deposito")|| VaiPara.endsWith("estalagem") || VaiPara.endsWith("praca") ){	

			if(VaiPara.endsWith("loja"))			pessoa.Local="loja";		
			if(VaiPara.endsWith("casa"))			pessoa.Local="casa";		
			if(VaiPara.endsWith("hospital"))		pessoa.Local="hospital";	
			if(VaiPara.endsWith("deposito"))		pessoa.Local="deposito";	
			if(VaiPara.endsWith("estalagem"))		pessoa.Local="estalagem";	
			if(VaiPara.endsWith("praca"))			pessoa.Local="praca";		
			if(VaiPara.endsWith("sair")){			pessoa.Local="sair";	System.exit(0);}	
			if(VaiPara.endsWith("naosei"))			System.out.println("Voce pode ir para:   <LOJA>,<DEPOSITO>,<HOSPITAL>,<PRACA>,<ESTALAGEM>,<CASA> OU <SAIR>");		
			if(VaiPara.endsWith("ir")) {
				System.out.println("Vai para onde? <NAOSEI>");
				Scanner linha = new java.util.Scanner(System.in);
				this.ir(linha.nextLine(), pessoa );
			}
			
		}
		else{
			System.out.println("\n  *   Esse lugar nAo existe na cidade.Arrume um Mapa");
		}
		
		
		
	}
	
	
}
