import java.util.Scanner;



public class Loja extends Lugar {

	String itemsecreto = "Smartphone";
	
	//construtor
	public Loja(){
		Nome = "Shop MEGAzine";
	}
	
	
	
	public void ir(String VaiPara, Pessoa pessoa){
	
		
		VaiPara=VaiPara.toLowerCase();
		if (VaiPara.endsWith("ir")|| VaiPara.equals("naosei") || VaiPara.equals("casa") || VaiPara.equals("loja") || VaiPara.equals("sair") || VaiPara.equals("hospital") || VaiPara.equals("deposito")|| VaiPara.equals("estalagem") || VaiPara.equals("praca") ){	

				if(VaiPara.endsWith("loja")){			System.out.println(" ** Ja estamos na <LOJA>.");		}
				if(VaiPara.endsWith("casa")){			pessoa.Local="casa";		}
				if(VaiPara.endsWith("hospital")){		System.out.println(" ** Nao tem caminho para la. Verifique o mapa.");			}
				if(VaiPara.endsWith("deposito")){		System.out.println(" ** Nao tem caminho para la. Verifique o mapa.");		}
				if(VaiPara.endsWith("estalagem")){		System.out.println(" ** Nao tem caminho para la. Verifique o mapa.");		}
				if(VaiPara.endsWith("praca")){			pessoa.Local="praca";		}
				if(VaiPara.endsWith("sair")){			pessoa.Local="sair";		System.exit(0);}
				if(VaiPara.endsWith("naosei")){			System.out.println("Voce pode ir para:   <PRACA>,<CASA> OU <SAIR>");	}
				if(VaiPara.endsWith("ir")) {
					System.out.println("Vai para onde? <NAOSEI>");
					Scanner linha = new java.util.Scanner(System.in);
					this.ir(linha.nextLine(), pessoa );
				}
			
		}
		else{
			System.out.println("\n  *   Esse lugar n�o existe na cidade.Arrume um Mapa");
		}
		
	
		
		
	}

	
	
	public void olhar(String capta){
		
		
		if(capta.endsWith("olhar")) System.out.println("    Voce esta em no(a) "+this.Nome+" aqui tem um [VENDEDOR] e uma {PRATELEIRA} de livros e revistas, e ainda um [HOMEM] na porta");
		if(capta.endsWith("vendedor")) System.out.println("    O vendedor parece estar lendo o Jornal de hoje, tem certeza de que quer interromper? ...");
		if(capta.endsWith("prateleira")) System.out.println("    Essa � uma prateleira especial, com varios livros e revistas de colecionador como:\n *Manual chines de como fazer macarrao \n *O Jornal Planeta Diario\n *A Primeira edi��o do SpidermanHQ\n *e diversas outras que estao lacradas.");
		if(capta.endsWith("homem")) System.out.println("    H� um homem bem na porta que observa todos que entram e saem, ser� que ele quer conversa?");
		
		
	}
	


	
	public void listar(){
		System.out.println("Aqui temos um [homem],um [vendedor] e uma {prateleira} ");
		System.out.println("Daqui podemos [ir] para  <casa>,<praca> ou <sair>");
	}
	



	public void interagir(String capta,Pessoa voce){
		if(capta.endsWith("vendedor")) this.vendedor(voce);
		if(capta.endsWith("homem")) this.homemdaloja(voce);
		
		
	}
	
	
	
		
	
	public void vendedor(Pessoa voce){
		Scanner linha = new java.util.Scanner(System.in);
		System.out.println("Bom dia!");
		String resposta;
		
			while(true){
				System.out.println("Quer comprar alguma coisa? <sim><nao>");
				resposta = linha.nextLine();
				resposta=resposta.toLowerCase();
				
				if (resposta.equals("nao")) break;
				else{
					System.out.println("Aqui n�s temos : \n -JornalX \n -RevistaY \n -LivroZ \n -Ipad\n -bala");
					System.out.println("Entao qual vai levar?");
					resposta=linha.nextLine();
					resposta=resposta.toLowerCase();
					
					if ( resposta.equals("jornalx") || resposta.equals("livroz") || resposta.equals("revistay") || resposta.equals("bala") || resposta.equals("ipad")){
							if ( resposta.equals("jornalx")){
								if (voce.pagamento(2.5)) voce.Carrega(resposta);
							}
							if ( resposta.equals("livroz") ){
								if (voce.pagamento(20)) voce.Carrega(resposta);
							}
							if ( resposta.equals("revistay")){
								if (voce.pagamento(10)) voce.Carrega(resposta);
							}
							if ( resposta.equals("ipad")){
								if (voce.pagamento(1000)) voce.Carrega(resposta);
							}
							if ( resposta.equals("bala")){
								if (voce.pagamento(1)) voce.Carrega(resposta);
							}
					}else{
						System.out.println("Desculpe nao tenho esse produto");
					}
					
				}
			}
			while(true){
				System.out.println("Quer me vender alguma coisa?  <sim><nao> \n   S� aceito coisas para minha loja.");
				resposta = linha.nextLine();
				resposta=resposta.toLowerCase();
				
				if (resposta.equals("nao")) break;
				else{
					System.out.println("Entao tem algum dos items .. para vender?\n -JornalX \n -RevistaY \n -LivroZ \n -Ipad\n -bala");
					System.out.println("Pagarei pela metade do preco ...");
					resposta=linha.nextLine();
					resposta=resposta.toLowerCase();
					
					if ( resposta.equals("jornalx") || resposta.equals("livroz") || resposta.equals("revistay") || resposta.equals("bala") || resposta.equals("ipad")){
						
							boolean vende=false;
							for(String it: voce.Mochila) if(it.equals(resposta)) vende=true;
						
							if (vende == true){
									if ( resposta.equals("jornalx")){
										voce.Deposita(resposta);
										voce.Din+=2;
									}
									if ( resposta.equals("livroz") ){
										voce.Deposita(resposta);
										voce.Din+=10;
									}
									if ( resposta.equals("revistay")){
										voce.Deposita(resposta);
										voce.Din+=5;
									}
									if ( resposta.equals("ipad")){
										voce.Carrega(resposta);
										voce.Din+=500;
									}
									if ( resposta.equals("bala")){
										voce.Carrega(resposta);
										voce.Din+=0.5;
									}
							}		
					}else{
						System.out.println("Ja disse s� aceito item da loja.Volte Sempre");
					}
				}
			
			
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void homemdaloja(Pessoa voce){

		Scanner linha = new java.util.Scanner(System.in);
		String escolhe,temp2;
		boolean troca=false;
		
		System.out.println("Oi amigo tenho aqui comigo um item e quero troca-lo por qualquer coisa.\n Mas voce so vai saber o que � quando trocar.");
		System.out.println("Aceita? <sim><nao>");
		if (linha.nextLine().equals("sim") ){
				
						System.out.println("Entao qual item vai me dar?   -----");
						
						voce.ShowMochila();
						escolhe=linha.nextLine();
						for(String it: voce.Mochila) if(it.equals(escolhe)) troca=true;
						
						if (troca == true){
										temp2=escolhe;
										voce.Deposita(escolhe);
										escolhe=itemsecreto;
										voce.Carrega(itemsecreto);
										itemsecreto=temp2;
										
										System.out.println("BOA TROCA!!");
										voce.ShowMochila();										
						}
						else{
							System.out.println("Nao seja espertinho, voce nao tem '"+escolhe+"'");
						}
							
					
				
		}
		else{
				System.out.println("Se mudar de ideia estou aqui...");
		}
		
		
	}
	
	

	
}
