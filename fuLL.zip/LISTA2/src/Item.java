
public class Item {
			
	
	
	public String Nome;
	public int Tamanho;
	public String Descricao;

	/*
	Item(String Nome, String Tamanho,String descricao){
		super(nome, endereco, sexo);
		setDepartamento(departamento);
	}*/
}

