import java.util.*;
public class Praca extends Lugar {

		public Praca(){
			Nome="Praca da PE";

		}
		
		
		
		
		
		
		
		
		public void olhar(String capta){
				
				
				if(capta.endsWith("olhar")) System.out.println("    Voce esta em no(a) "+this.Nome+" aqui tem um [jogador] uma {arvore}, um [banco] tudo isso por que a praca � nossa");
				if(capta.endsWith("jogador")) System.out.println("Um camarada tipico das pracas , um pouco suspeito, mas tem com muita gente apostando com ele.");
				if(capta.endsWith("arvore")) System.out.println("Parece que estamos na primavera por que a arvora esa cheia de folhas e flores");
				if(capta.endsWith("banco")) System.out.println("� um banco de concreto tipo em todas as pracas, sente logo enquanto niguem aparece.Fica bem na sombra da {arvore}");
				
				
			}
			


			
			public void listar(){
				System.out.println("Aqui temos uma [jogador],um [banco] e uma {arvore} ");
				System.out.println("Daqui podemos [ir] para   <LOJA>,<DEPOSITO>,<HOSPITAL>,<PRACA>,<ESTALAGEM>,<CASA> OU <SAIR>");
			}
			
			

			
			
			public void interagir(String capta,Pessoa voce){
				if(capta.endsWith("jogador")) this.jogador(voce);
				if(capta.endsWith("banco")) this.banco(voce);
				
				
			}
			
		
		
		
		
		
		
		
		public void jogador(Pessoa voce){
			
		
				Scanner diga = new java.util.Scanner (System.in);
				int palpite = 0;
				System.out.println("Aqui voce nao tem escolha, tem que jogar! hahaha");
				System.out.println("Toda pra�a tem um joguinho.");
				System.out.println("O jogo s� acaba quando voce ganha.Quando acertar voce leva 100Dins e cada erro perde 20Dins.");
				while(true){
						if(palpite > 9) palpite = 8;
						System.out.println("ESCOLHA de 0 a 9");
						if (diga.nextInt() == palpite ){
							System.out.println("WIN");
							voce.Din+=100;
							System.out.println("Seu carteira tem '"+voce.Din+"' Dins");
							break;
						}
						else{
							System.out.println("Denovo..");
							if (voce.pagamento(20)){
									palpite+=1;
									System.out.println("Seu carteira ainda tem '"+voce.Din+"' Dins");
							}
							else{
								System.out.println("Voce nao pode mais jogar seu dinheiro acabou");
								System.out.println("Seu carteira ainda tem '"+voce.Din+"' Dins");
								break;	
							}
						}
						
				}
		}
		
		
		public void banco (Pessoa voce){
			Scanner diga = new java.util.Scanner (System.in);
			String resposta;
			System.out.println("Voce esta sentado se quiser pode <levantar>.");
			while(true){
				resposta=diga.nextLine();
				resposta=resposta.toLowerCase();
				if (resposta.equals("levantar")) break;
				else System.out.println("Voce esta sentado se quiser pode <levantar>.");
			}
			
			
		
			
		}
		
		
		
		
		
		
}
