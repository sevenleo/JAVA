import java.util.ArrayList;
import java.util.Scanner;



public class Deposito extends Lugar {

	private float poupanca;
	private ArrayList<String> bau = new ArrayList<String>();
	
	public Deposito(){
		Nome="Banco e Deposito S/A";
		//ArrayList<String> bau = new ArrayList<String>();
		poupanca=2000;
		this.bau.add("notebook");
		this.bau.add("mp4");
		this.bau.add("estojo");
		this.bau.add("caderno");
		this.bau.add("mochila velha");
		this.bau.add("relogio");
		
	}
	
	public void ir(String VaiPara, Pessoa pessoa){
	
		
		VaiPara=VaiPara.toLowerCase();
		if (VaiPara.endsWith("ir")|| VaiPara.equals("naosei") || VaiPara.equals("casa") || VaiPara.equals("loja") || VaiPara.equals("sair") || VaiPara.equals("hospital") || VaiPara.equals("deposito")|| VaiPara.equals("estalagem") || VaiPara.equals("praca") ){	

				if(VaiPara.endsWith("loja")){			System.out.println(" ** Nao tem caminho para la. Verifique o mapa.");		}
				if(VaiPara.endsWith("casa")){			pessoa.Local="casa";		}
				if(VaiPara.endsWith("hospital")){		System.out.println(" ** Nao tem caminho para la. Verifique o mapa.");			}
				if(VaiPara.endsWith("deposito")){		System.out.println(" ** Ja estamos no <DEPOSITO>.");		}
				if(VaiPara.endsWith("estalagem")){		System.out.println(" ** Nao tem caminho para la. Verifique o mapa.");		}
				if(VaiPara.endsWith("praca")){			pessoa.Local="praca";		}
				if(VaiPara.endsWith("sair")){			pessoa.Local="sair";	System.exit(0);	}
				if(VaiPara.endsWith("naosei")){			System.out.println("Voce pode ir para:   <PRACA>,<CASA> OU <SAIR>");		}
				if(VaiPara.endsWith("ir")) {
					System.out.println("Vai para onde? <NAOSEI>");
					Scanner linha = new java.util.Scanner(System.in);
					this.ir(linha.nextLine(), pessoa );
				}
			
		}
		else{
			System.out.println("\n  *   Esse lugar n�o existe na cidade.Arrume um Mapa");
		}
		
	
		
		
	}


	
	
	
	
	
	
	public void olhar(String capta){
			
			
			if(capta.endsWith("olhar")) System.out.println("    Voce esta em no(a) "+this.Nome+" aqui tem um [cofre] um [gerente] e uma {porta} com 5 cadeados");
			if(capta.endsWith("gerente")) System.out.println("  Esse � o homem que pode te ajudar a ver o que tem na sua conta.");
			if(capta.endsWith("cofre")) System.out.println("  Cofre de altissimo sigilo,feito de chumbo com a�o, � quase impenetravel");
			if(capta.endsWith("porta")) System.out.println("  Essa porta deve estar trancando algum segredo muito valioso, melhor nao passar nem perto para o alarme nao tocar.");
			
			
		}
		


		
		public void listar(){
			System.out.println("Aqui temos um [gerente],um [cofre] e uma {porta} ");
			System.out.println("Daqui podemos [ir] para  <casa>,<praca> ou <sair>");
		}
		
		
		
		
		
		
		
		
		
		public void interagir(String capta,Pessoa voce){
			if(capta.endsWith("porta")) System.out.println("Nao pode '"+capta+"' � s� observavel");
			if(capta.endsWith("cofre")) this.cofre(voce);
			if(capta.endsWith("gerente")) this.gerente(voce);
			
			
		}
		
	
	
		public void gerente(Pessoa voce){
			Scanner linha = new java.util.Scanner(System.in);
			String resposta;
			float valor;
			
			System.out.println("Olao bem vindo ao "+this.Nome);
			System.out.println("Em que posso ajuda-lo? gostaria de <depositar> dinheiro da poupanca ou ver os itens do seu <bau>?");
			System.out.println("<depositar> ou <bau>");
			resposta=linha.nextLine();
			resposta=resposta.toLowerCase();
			
			if (resposta.equals("bau") || resposta.equals("depositar")){
				if (resposta.equals("bau")){
				
						System.out.println("Seu bau tem :");
						for(String it : this.bau){
								System.out.println("   ~~"+it);
						}
									
				}
				if (resposta.equals("depositar")){	
						System.out.println("Quer depositar quanto na sua conta?");
						valor = linha.nextFloat(); 
						if (voce.Din >= valor){
								voce.Din-=valor;
								//voce.conta+=valor;
								this.poupanca+=valor;
								System.out.println("Sua carteira tem: "+voce.Din+" Dins \n e sua conta tem: "+this.poupanca+" Dins");
						}
						else{
								System.out.println("  * S� pode depositar o valor que tem na carteira.  *");	
						}
						
				
				
				}
				
			}
			else{
			System.out.println("Nao fazemos isso aqui!");	
			}
			
		}
	
	
	
		public void cofre(Pessoa voce){
			Scanner linha = new java.util.Scanner(System.in);
			String resposta;
			boolean deposita=false,retira=false;
			
			System.out.println("Aqui voce pode <depositar> ou <retirar> itens  da sua mochila no bau");
			
			System.out.println("\n    O que deseja fazer?   <depositar>  <retirar>");
			
			resposta=linha.nextLine();
			resposta=resposta.toLowerCase();
			
			if (resposta.equals("depositar") || resposta.equals("retirar") || resposta.equals("saque")){

				
				if (resposta.equals("depositar")){
						voce.ShowMochila();
						System.out.println("Quer depositar o que? ");
						resposta=linha.nextLine();
						for(String it: voce.Mochila) if(it.equals(resposta)) deposita=true;
						
						if (deposita == true){
							this.bau.add(resposta);
							voce.Mochila.remove(resposta);
							System.out.println("   == transicao realizada com sucesso!");
						}
						else{
							System.out.println("   == transicao NAO realizada !");	
						}

				}
				if (resposta.equals("retirar") || resposta.equals("saque")){
					
				
						System.out.println("Seu bau tem :");
						for(String it : this.bau){
								System.out.println("   ~~"+it);
						}
	
						System.out.println("Quer retirar o que? ");
						resposta=linha.nextLine();
						for(String it: this.bau) if(it.equals(resposta)) retira=true;
						
						if (retira == true){
								this.bau.remove(resposta);
								voce.Mochila.add(resposta);
								System.out.println("   == transicao realizada com sucesso!");
						}
						else{
							System.out.println("   == transicao NAO realizada !");	
						}

				}

				
			}
			else{	
				System.out.println("Nao fazemos isso aqui!\n S� fazemos depositos e saques");	
				
			}
			
			
		}
	
	
	
	
	
	
	


}
