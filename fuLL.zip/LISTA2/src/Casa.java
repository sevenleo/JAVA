import java.util.*;

public class Casa extends Lugar {

	
	
	public void EmCasa (Pessoa voce){
			System.out.println("Ola voce est� em <CASA>");
			System.out.println("Quer ver/alterar alguma caracteistica ou quer ir para algum lugar? \n   <IR *> ou <EU> ou <ALTERA>");
			
			Scanner Teclado = new java.util.Scanner (System.in);
			String entra=Teclado.nextLine();
			entra=entra.toLowerCase();
			
			if ( entra.startsWith("sair")) System.exit(0);	
			if ( entra.startsWith("eu") )   voce.ShowPessoa();
			if ( entra.startsWith("ir") ) 	this.ir(entra, voce); 
			if ( entra.startsWith("altera") )   while( voce.changePessoa());
	}
	
}
