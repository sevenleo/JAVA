import java.util.*;

public class Pessoa {

		/**
		 * @param args
		 */
		public String Nome;
		public int Id;
		public float Din; //Dinheiro
		public String Local;
		public int saude;
		public String consulta;
		ArrayList<String> Mochila = new ArrayList<String>();
		
		
	
	
		public String getNome() {
			return Nome;
		}
		public void setNome(String nome) {
			Nome = nome;
		}
		public int getId() {
			return Id;
		}
		public void setId(int id) {
			Id = id;
		}
		public float getDin() {
			return Din;
		}
		public void setDin(float din) {
			Din = din;
		}
		public String getLocal() {
			return Local;
		}
		public void setLocal(String local) {
			Local = local;
		}



		
		

		//construtor
		public Pessoa(){
			Scanner Teclado = new java.util.Scanner (System.in);
			System.out.println("Qual seu nome?");
			this.setNome(Teclado.nextLine());
			 
			
			//this.Nome = "Ninguem";
			this.Id = 1;
			this.Din= 545; //salario minimo
			this.Local = "casa";
			this.saude=100;
		}
		
		
		
		
		
		
		
		public void ShowPessoa(){							
							System.out.println("____________________________________\n");
							System.out.println("Ol� '"+this.Nome + "' seu ID � '" + this.Id+"'");
							System.out.println("Voce esta em '" + this.Local +"'");
							System.out.println("Seu nivel de sa�de � =" + this.saude );
							this.ShowMochila();
							System.out.println("____________________________________\n");
			
		}
		
			
		
		
		
		
		public boolean changePessoa(){
			boolean continua=true;
			String MenuPessoa;
			
			
			Scanner Teclado = new java.util.Scanner (System.in);
			while(true){
					System.out.println("Quer alterar alguma caracter�stica sua?");
					System.out.print(" ..dinheiro,nome,id,local,pensa ou nao?");
					
					MenuPessoa =Teclado.nextLine();
					MenuPessoa =MenuPessoa.toLowerCase(); 
					
					if (  MenuPessoa.equals("local") ){ 
						System.out.println("         Voce nao pode se se teletransportar");
					
					}
					if (  MenuPessoa.equals("dinheiro") || MenuPessoa.equals("din")){ 
						System.out.println("         Entao quantos Dins voce tem?");
						this.setDin(Teclado.nextFloat());
					}
					if (  MenuPessoa.equals("id") ){ 
						System.out.println("         Entao qual seu Id?");
						this.setId(Teclado.nextInt());
						
					}
					if (  MenuPessoa.equals("nome") ){ 
						System.out.println("         Entao qual seu Nome?");
						this.setNome(Teclado.nextLine());
					}
					if (MenuPessoa.equals("nao")){
						continua=false;
						break;
					}
					if (MenuPessoa.equals("pensa")){
						this.Pensa();
					}
					
			}		
		return continua;	
		}
		
		
		
		
	
		
		public void ShowMochila(){
			System.out.println("Sua carteira ainda tem '"+this.Din+"'Dins");
			System.out.println("Sua mochila conta com os itens:");
			for(String it : this.Mochila){
				System.out.println("   -"+it);
			}
		}
		
		
		public void Carrega(String i){
			this.Mochila.add(i);
			System.out.println("            ..."+i+" adcionado.");

		}
		
		public void Deposita(String i){
			this.Mochila.remove(i);
			System.out.println("            ..."+i+" se foi.");
		}
		
		
		public boolean pagamento(double d){
			if(this.Din>=d){
				this.Din=(float) (this.Din-d);
				return true;
			}else{
				System.out.println("\nQue pena, voce n�o tem dinheiro suficiente.\n");
				return false;
			}
				
		}
		
		
		
		
		public void Pensa(){
			
			ArrayList<String> p1 = new ArrayList<String>();
			
			
			Scanner Teclado = new java.util.Scanner (System.in);
			String digita;
			
			p1.add("java ..");
			while(true){			
				System.out.println("Deseja <nada>,<pensar>,<esquecer> ou <organizar> os pensamentos?");
				digita=Teclado.nextLine();	
				digita=digita.toLowerCase();
								
				
				if ( digita.equals("nada") ) break;
				if ( digita.equals("pensar") ) { p1.add(Teclado.nextLine()); System.out.println("adcionado"); } 
				if ( digita.equals("esquecer") ) {p1.remove(Teclado.nextLine()); System.out.println("removido"); }
				if ( digita.equals("organizar") ){
					System.out.println("Penso em ..");
					for(String temp : p1){
						System.out.println("     - "+temp);
					}//for
					
				}//if
			}//wh	
				
		}
		
		
	
		
		
		
		
		
		
		
}

	
	
	
	

