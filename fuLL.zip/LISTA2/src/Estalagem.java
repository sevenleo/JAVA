import java.util.Scanner;


public class Estalagem extends Lugar {

	
	public Estalagem(){
		Nome=" Hotel *****";
	}


	
	
	
	public void ir(String VaiPara, Pessoa pessoa){
	
		
		VaiPara=VaiPara.toLowerCase();
		if (VaiPara.endsWith("ir")|| VaiPara.equals("naosei") || VaiPara.equals("casa") || VaiPara.equals("loja") || VaiPara.equals("sair") || VaiPara.equals("hospital") || VaiPara.equals("deposito")|| VaiPara.equals("estalagem") || VaiPara.equals("praca") ){	

				if(VaiPara.endsWith("loja")){			System.out.println(" ** Nao tem caminho para la. Verifique o mapa.");		}
				if(VaiPara.endsWith("casa")){			pessoa.Local="casa";		}
				if(VaiPara.endsWith("hospital")){		System.out.println(" ** Nao tem caminho para la. Verifique o mapa.");			}
				if(VaiPara.endsWith("deposito")){		System.out.println(" ** Nao tem caminho para la. Verifique o mapa.");		}
				if(VaiPara.endsWith("estalagem")){		System.out.println(" ** Ja estamos na <ESTALAGEM>.");		}
				if(VaiPara.endsWith("praca")){			pessoa.Local="praca";		}
				if(VaiPara.endsWith("sair")){			pessoa.Local="sair";	System.exit(0);	}
				if(VaiPara.endsWith("naosei")){			System.out.println("Voce pode ir para:   <PRACA>,<CASA> OU <SAIR>");	}
				if(VaiPara.endsWith("ir")) {
					System.out.println("Vai para onde? <NAOSEI>");
					Scanner linha = new java.util.Scanner(System.in);
					this.ir(linha.nextLine(), pessoa );
				}
			
		}
		else{
			System.out.println("\n  *   Esse lugar n�o existe na cidade.Arrume um Mapa");
		}
		
	
		
		
	}
	
	
	
	
	
public void olhar(String capta){
		
		
		if(capta.endsWith("olhar")) System.out.println("    Voce esta em no(a) "+this.Nome+" aqui tem uma [Recepcionista] um velho {Sofa} de livros e revistas, e ainda um [chuveiro] de agua quente");
		if(capta.endsWith("recepcionista")) System.out.println("� uma bela mo�a com um lindo sorriso, tudo que ela quer � que voce alugue um quarto.");
		if(capta.endsWith("sofa")) System.out.println("Um sof� de espera com as molas para fora e fedorento, se eu fosse voce n�o sentaria ai");
		if(capta.endsWith("chuveiro")) System.out.println("Parece ser um chuveiro de agua quente. Quer arriscar? rs");
		
		
	}
	


	
	public void listar(){
		System.out.println("Aqui temos uma [recepcionista],um [chuveiro] e uma {sofa} ");
		System.out.println("Daqui podemos [ir] para  <casa>,<praca> ou <sair>");
	}
	
	
	
	
	
	
	
	
	
	public void interagir(String capta,Pessoa voce){
		
		if(capta.endsWith("chuveiro")) this.chuveiro(voce);
		if(capta.endsWith("recepcionista")) this.recepcionista(voce);
		
		
	}
	
	
	
	
	
	
	
	public void recepcionista(Pessoa voce){
		Scanner linha = new java.util.Scanner(System.in);
		int i;
		System.out.println("Deve estar cansado depois de tanto caminhar.\n Aqui voce pode descansar por apenas 200Dins, quer alugar um quarto?");
		String resposta; 
		resposta=linha.nextLine();
		resposta=resposta.toLowerCase();
		if (resposta.equals("sim")){
			
			if (voce.pagamento(200)){
				System.out.println("Tenha uma boa noite de sono.");
				for (i=0;i<40;i++)System.out.println("          ~Zzzzzzzzzzz  ");
				System.out.println(" * DORMIU BEM?");
				voce.saude=100;
			}
			
		}
		else{
			System.out.println(" * N�o quer gastar dinheiro com uma boa cama? Voce que sabe.");
		}
	}
	
	
	
	
	
	
	public void chuveiro(Pessoa voce){
			Scanner linha = new java.util.Scanner(System.in);
			int i;
			String resposta; 
			
			System.out.println("Para tomar banho aqui � gr�tis, quer tomar uma ducha?");
			resposta=linha.next();
			resposta=resposta.toLowerCase();
			if (resposta.equals("sim")){
						for (i=0;i<10;i++)System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
						System.out.println(" * BANHO TOMADO, CORPO REVIGORADO!    =)");
			}
			else{
						System.out.println(" * Voce que sabe.");
			}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
