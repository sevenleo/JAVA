package rpg;
//import java.util.Scanner;

public class Taverna  implements controleremoto{
	public void dormir(Hero y){
		remoto.saida("Voc� esta em uma taverna...O lugar esta cheio e h� um [atendente] no balc�o, uma {mulher} sentada em uma mesa pr�xima e uma [caneca de hidromel] em cima de uma mesa sem ninguem.... ");
	//	Scanner scan = new Scanner (System.in);
		String texto = remoto.entrada();
		if(texto.equalsIgnoreCase("listar")){
			remoto.saida("Pra�a");
		}
		if(texto.equalsIgnoreCase("ir pra�a")){
			y.setLugar("Pra�a");
		}
		if(texto.equalsIgnoreCase("olhar atendente")){
			remoto.saida("Um homem incirvelmente grande e com uma cicatriz no rosto.... Parece que esta trabalahdno muito hoje");
		}
		
		else if(texto.equalsIgnoreCase("olhar mulher")){
			remoto.saida("Uma belissima mulher e parece estar sozinha....");
		}
		
		else if(texto.equalsIgnoreCase("olhar caneca de hidromel")){
			remoto.saida("Parece que essa caneca esta me esperando....");
		}
		
		else if(texto.equalsIgnoreCase("interagir caneca de hidromel")){
			remoto.saida("Hmm... Ta ali dando sopa e eu estou com sede...");
			remoto.saida("---------------");
			remoto.saida("Voce bebeu o hidromel, estava gelado e muito gostoso");
			texto = remoto.entrada();
			if(texto.equalsIgnoreCase("sim")){
				remoto.saida("Voc� jogou gam�o com o velho e perdeu feio!");
			}
			else if(texto.equalsIgnoreCase("n�o")){
				remoto.saida("Ok ent�o.... ");
			}
		}
		
		else if(texto.equalsIgnoreCase("interagir atendente")){
			remoto.saida("Hahaha!Ol� l� viajante!Bem vindo ao Cr�nio Furado, o que vc deseja? 1-Quarto");
			texto = remoto.entrada();
			if(texto.equalsIgnoreCase("quarto")){
				remoto.saida("Voc� parece realmente cansado.... O quarto custa 45 Zentys a di�ria, voce quer um?");
				texto = remoto.entrada();
				if(texto.equalsIgnoreCase("sim")){
					y.setDinheiro(y.getDinheiro() - 45);
					remoto.saida("Voce desca�ou bem e foi curado!");
				}
			}
		}
	}
}
