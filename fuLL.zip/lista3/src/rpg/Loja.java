package rpg;
//import java.util.Scanner;


public class Loja  implements controleremoto{
	
	public static void inserirItens(Item [] item){
		item[0] = new Item("Escudo",90,6);
		item[1] = new Item("Espada Bastarda",130,3);
		item[2] = new Item("Camis�o de cota de malha",115,4);
		item[3] = new Item("Full Plate",250,2);
	}
	
	
	public void vender(Item [] item, Hero y){
		remoto.saida("Voc� entrou em uma loja armeira... H� {espadas} nas paredes, um [atendente] no balc�o e um [rapaz] parado ao canto");
	//	Scanner scan = new Scanner (System.in);
		String texto = remoto.entrada();
		if(texto.equalsIgnoreCase("listar")){
			remoto.saida("Pra�a");
		}
		if(texto.equalsIgnoreCase("ir pra�a")){
			y.setLugar("Pra�a");
		}
		if(texto.equalsIgnoreCase("olhar espadas")){
			remoto.saida("Espadas de todos os tipos e tamanhos est�o presas nas paredes");		
		}
		else if(texto.equalsIgnoreCase("olhar atendente")){
			remoto.saida("Um homem j� com certa idade tentando vender algumas de suas armas...");
		}
		else if(texto.equalsIgnoreCase("olhar rapaz")){
			remoto.saida("Um jovem rapaz...Parece ser um guerreiro");
		}
		else if(texto.equalsIgnoreCase("interagir rapaz")){
			remoto.saida("Essa loja possui itens muito bons! Vale a pena comprar aqui.");
		}
		else if(texto.equalsIgnoreCase("interagir atendente")){
			remoto.saida("Ol� jovem guerreiro,  que deseja?  1-Comprar   2-Vender");
			while(!remoto.entrada().equals("sair")){
				texto = remoto.entrada();
				if(remoto.entrada().equalsIgnoreCase("comprar")){
					remoto.saida("Qual item deseja comprar?");
					for(int i = 0; i < item.length; i++ ){
						remoto.saida(item[i].getQuantidade() + "x " + item[i].getNome() + " - "+ item[i].getPre�o() +" Zenty");
					}
					texto = remoto.entrada();
					for(int i = 0; i < item.length; i++ ){
						if(item[i].getNome().equalsIgnoreCase(texto)){
							y.compra(item[i]);
						}
					}
					
				}
				else if(remoto.entrada().equalsIgnoreCase("vender")){
					remoto.saida("Hmm.... O que tem a oferecer?");
					texto = remoto.entrada();
					remoto.saida("Pagarei a metade do pre�o que isso vale, voc� aceita?");
					String texto1 = remoto.entrada();
					if(texto1.equalsIgnoreCase("n�o")){
						remoto.saida("Ok ent�o...");
					}
					else if(texto1.equalsIgnoreCase("sim")){
						for(Item a : item){
							if(a.getNome().equalsIgnoreCase(texto1)){
								if(a.getQuantidadeHero() == 0){
									remoto.saida("Parece que voc� n�o tem esse item para vender...");
								}
								else{
									a.setQuantidadeHero(a.getQuantidadeHero() - 1);
									y.setDinheiro(a.getPre�o()/2 + y.getDinheiro());
								}
							}
						}
					}
				}
			}
		}
	}
}
