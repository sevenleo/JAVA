package rpg;

public class Item  implements controleremoto{
	private String nome;
	private int pre�o;
	private int quantidade;
	private int quantidadeDeposito;
	private int quantidadeHero;
	
	
	public Item(String nome, int pre�o, int quantidade){
		this.nome = nome;
		this.pre�o = pre�o;
		this.quantidade = quantidade;
		this.quantidadeHero = 0;
		this.quantidadeDeposito = 0;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getPre�o() {
		return pre�o;
	}

	public void setPre�o(int pre�o) {
		this.pre�o = pre�o;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}

	public int getQuantidadeDeposito() {
		return quantidadeDeposito;
	}

	public void setQuantidadeDeposito(int quantidadeDeposito) {
		this.quantidadeDeposito = quantidadeDeposito;
	}

	public int getQuantidadeHero() {
		return quantidadeHero;
	}

	
	public void setQuantidadeHero(int quantidadeHero) {
		this.quantidadeHero = quantidadeHero;
	}
	

}
