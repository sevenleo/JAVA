package rpg;

//import java.util.Scanner;

public class Principal implements controleremoto{

	/*/**
	 * @param args
	 */
	public static void main(String[] args) {
		
	
	//public void jogar(){
		remoto.saida("ola");
		remoto.saida("Gira mundo");
		Item[] item = new Item[4];
		Loja.inserirItens(item);
		
		Pra�a pra�a = new Pra�a();
		Taverna taverna = new Taverna();
		Loja loja = new Loja();
		Hospital hospital = new Hospital();
		Deposito deposito = new Deposito();
		
		Hero hero = new Hero();
		remoto.saida("Qual o seu nome?");
		//Scanner scan = new Scanner (System.in);
		//String texto = scan.nextLine();
		String texto = 	remoto.entrada();
		hero.setNome(texto);
		if(hero.getNome()== null){
			hero.setNome("Azenom");
		}
			
		
		while(!texto.equalsIgnoreCase("fechar jogo")){
			if(texto.equalsIgnoreCase("inventario")){
				for(int i = 0; i < item.length; i++){
					if(item[i].getQuantidadeHero() > 0){
					     remoto.saida(item[i].getQuantidadeHero() + "x" + item[i].getNome());
					}
				}
			}
			if(texto.equalsIgnoreCase("dinheiro")){
				hero.setDinheiro(hero.getDinheiro() + 1000);
			}
			if(hero.getLugar().equals("Pra�a")){
				pra�a.velho(hero);
			}

			if(hero.getLugar().equals("Hospital")){
				hospital.cura(hero);
			}
			if(hero.getLugar().equals("Deposito")){
				deposito.depositar(item, hero);
			}
			if(hero.getLugar().equals("Loja")){
				loja.vender(item, hero);
				
			}
			if(hero.getLugar().equals("Taverna")){
				taverna.dormir(hero);
				
			}

		}



	}

}
