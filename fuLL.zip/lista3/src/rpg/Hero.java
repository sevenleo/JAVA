package rpg;

public class Hero  implements controleremoto{
	private String nome;
	private int dinheiro;
	private String lugar;
	
	public void compra(Item x){
		if(x.getPre�o() >= this.getDinheiro()){
			remoto.saida("Voc� n�o tem Zentys suficiente para comprar este item");	
		}
		
		if(x.getQuantidade() == 0){
			remoto.saida("Desculpe, este item esta em falta...Porque n�o escolhe outro?");	
		}
		
		if(x.getPre�o() <= this.getDinheiro()&& x.getQuantidade() > 0){
			this.dinheiro = x.getPre�o() - this.getDinheiro();
			x.setQuantidade(x.getQuantidade() - 1);
			x.setQuantidadeHero(x.getQuantidadeHero() + 1 );
			remoto.saida("Muito obrigado! Deseja mais alguma coisa?");
		}
		
	}
	public Hero(){
		setDinheiro(5000);
		setLugar("Pra�a");
		
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getDinheiro() {
		return dinheiro;
	}
	public void setDinheiro(int dinheiro) {
		this.dinheiro = dinheiro;
	}
	public String getLugar() {
		return lugar;
	}
	public void setLugar(String lugar) {
		this.lugar = lugar;
	}
	

}
