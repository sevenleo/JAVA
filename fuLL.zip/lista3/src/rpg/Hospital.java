package rpg;

//import java.util.Scanner;

public class Hospital  implements controleremoto{
	public void cura(Hero y){
		remoto.saida("O hospital da cidade. H� uma [enfermeira] proxima a uma {maca} e uma [senhora] sentada em um banco ");
	//	Scanner scan = new Scanner (System.in);
		String texto = remoto.entrada();
		if(texto.equalsIgnoreCase("listar")){
			remoto.saida("Pra�a");
		}
		if(texto.equalsIgnoreCase("ir pra�a")){
			y.setLugar("Pra�a");
		}
		if(texto.equalsIgnoreCase("olhar enfermeira")){
			remoto.saida("Uma linda enfermeira parada ali...Mas n�o tenho tempo para paqueras agora");
			
		}
		else if(texto.equalsIgnoreCase("olhar senhora")){
			remoto.saida("Uma senhora j� com certa idade... Deve estar esperando atendimento");
		}
		else if(texto.equalsIgnoreCase("olhar maca")){
			remoto.saida("Uma maca em bom estado");
		}
		else if(texto.equalsIgnoreCase("interagir senhora")){
			remoto.saida("Aqui h� medicos muito bons. Venho e aquela mocinha ali *aponta pra enfermeira* � um amor de pessoa!");
		}
		else if(texto.equalsIgnoreCase("interagir enfermeira")){
			remoto.saida("Ol� meu querido, deseja reparar seus ferimentos?");
			texto = remoto.entrada();
			if(texto.equalsIgnoreCase("sim")){
				remoto.saida("Voc� realmente precisa....Deite-se ali, eu cuido de voce.");
				remoto.saida("------------");
				remoto.saida("Voc� foi curado e esta revigorado!");
			}
		}
		
	}
}
