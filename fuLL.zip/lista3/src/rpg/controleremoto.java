package rpg;

import java.awt.EventQueue;
import javax.swing.JFrame;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.util.*;


public interface controleremoto {
	
	
	public JFrame frame = new JFrame();;
	
	public JTextField textField = new JTextField();
	
	
	JTextArea textArea = new JTextArea();
	
	public static controle remoto = new controle();
	
	
	public class controle{
		
		public String nextLine(){
			return this.entrada();
			
		}
		
		
		public void saida(String end){
			//textArea.append(end);
			System.out.println(end);
			
		}
		
		public String entrada(){
			Scanner scan = new Scanner (System.in);
			String begin = scan.nextLine();
			return begin;
		}
	}
}
