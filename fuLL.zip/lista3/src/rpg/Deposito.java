package rpg;

//import java.util.Scanner;

public class Deposito  implements controleremoto{
	
	public void depositar(Item [] item, Hero y){
		remoto.saida("� um deposito de itens.... Um lugar muito bom para voce deixar suas coisas se estiver carregando muito peso.H� um [atendente] atr�s da bancada com um grande {martelo} no cord�o em seu pesco�o. Falando com ele h� um [homem]");
		//Scanner scan = new Scanner (System.in);
		String texto = remoto.entrada();
		if(texto.equalsIgnoreCase("listar")){
			remoto.saida("Pra�a");
		}
		if(texto.equalsIgnoreCase("ir pra�a")){
			y.setLugar("Pra�a");
		}
		if(texto.equalsIgnoreCase("olhar atendente")){
			remoto.saida("Esse atendente n�o parece ser daqui.");
		}
		else if(texto.equalsIgnoreCase("olhar martelo")){
			remoto.saida("Um simbolo de religi�o pag�! Deve ser descendente de Vikings...");
		}
		else if(texto.equalsIgnoreCase("olhar homem")){
			remoto.saida("Deve ser algum mercador negociando mais produtos...");
		}
		else if(texto.equalsIgnoreCase("interagir homem")){
			remoto.saida("A seguran�a daqui � confiavel, pode guardar seus pertences sem remorso!");
		}
		else if(texto.equalsIgnoreCase("interagir atendente")){
			remoto.saida("Ol�! O que deseja?  1-Depositar   2-Retirar");
			while(!remoto.entrada().equals("sair")){
				texto = remoto.entrada();
				if(remoto.entrada().equalsIgnoreCase("depositar")){
					remoto.saida("Qual item deseja depositar?");
					for(int i = 0; i < item.length; i++ ){
						if(item[i].getQuantidadeHero()>0){
							remoto.saida(item[i].getQuantidadeHero() + "x " + item[i].getNome());
						}
					}
					texto = remoto.entrada();
					for(int i = 0; i < item.length; i++ ){
						if(item[i].getNome().equalsIgnoreCase(texto)){
							if(item[i].getQuantidadeHero() == 0){
								remoto.saida("Desculpe,voc� n�o possui esse item");	
							}
							
							else{
								item[i].setQuantidadeDeposito(item[i].getQuantidadeDeposito() + 1);
								item[i].setQuantidadeHero(item[i].getQuantidadeHero() - 1 );
								remoto.saida("Muito obrigado! Deseja mais alguma coisa?");
							}
						}
					}
				}
				else if(remoto.entrada().equalsIgnoreCase("retirar")){
					remoto.saida("O que deseja retirar?");
					texto = remoto.entrada();
					for(Item a : item){
						if(a.getNome().equalsIgnoreCase(texto)){
							if(a.getQuantidadeDeposito() == 0){
								remoto.saida("Parece que voc� n�o possui nada no deposito");
							}
							else{
								a.setQuantidadeHero(a.getQuantidadeHero() + 1);
								a.setQuantidadeDeposito(a.getQuantidadeDeposito()-1);
							}
						}
					}
					
				}
			}
		}
		
	}

}
