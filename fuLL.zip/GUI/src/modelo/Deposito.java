package modelo;


import java.util.ArrayList;
public class Deposito extends Lugar {
		private NPC martelo = new NPC("Martelo","Um simbolo de religi�o pag�! Deve ser descendente de Vikings...",null);
		private NPC atendente = new NPC("Atendente","Esse atendente n�o parece ser daqui.","Ol�! O que deseja?");
		private NPC armarios = new NPC("Armarios","Arm�rio de metal com cadeado grande, parece ser seguro.","Voc� checou o arm�rio e ele realmente � seguro.");
		private NPC homem = new NPC("Homem","Deve ser algum mercador negociando mais produtos...","A seguran�a daqui � confiavel, pode guardar seus pertences sem remorso!");
		
		private ArrayList<Item> armario = new ArrayList<Item>();
			
		//construtor
		public Deposito(){
			setNome("Dep�sito de itens");
			setResponsavel(atendente);
			setDescricao("Um deposito de itens.... " +
					"Um lugar muito bom para voce deixar suas " +
					"coisas se estiver carregando muito peso. Ha [arm�rios] " +
					"por todos os lados. H� um " +
					"[atendente] atr�s da bancada com um grande" +
					"{martelo} no cord�o em seu pescoco. Falando com " +
					"ele h� um [homem]");
			getCoisas().add(martelo);
			getCoisas().add(homem);
			getCoisas().add(armarios);
			
			Item descartavel1=new Item("",0,0);
			this.armario=descartavel1.geraArrayArmas();
			
			//colocando todo o array com quantidade 0;
			for(Item descartavel2 : this.armario){
				while(descartavel2.diminuiQuantidade()){}
			}
		}

		//get&set
		public ArrayList<Item> getEstoque(){
			return this.armario;
		} 
		//metodos
		public boolean entregarItem(Item a){
			Item entregueDeposito = null;
			for(Item descartavel : this.armario){
				if(descartavel.getNome().equals(a.getNome())){
					entregueDeposito=descartavel;
					break;
				}
			}
			if(entregueDeposito==null){
				return false;
			}else if(entregueDeposito.diminuiQuantidade()){
				return true;
			}else{
				return false;
			}
			
		}
		public boolean receberItem(Item a){
			Item recebidoDeposito = null;
			for(Item descartavel : this.armario){
				if(descartavel.getNome().equals(a.getNome())){
					recebidoDeposito=descartavel;
					break;
				}
			}
			if(recebidoDeposito==null){
				return false;
			}else {
				recebidoDeposito.aumentaQuantidade();
				return true;
			}
		}
	}


