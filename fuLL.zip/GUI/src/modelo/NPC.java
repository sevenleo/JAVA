package modelo;


public class NPC {
	private String nome;
	private String descricao;
	private String interacao;
	
	public NPC(String nome, String descricao, String interacao) {
		this.nome = nome;
		this.descricao = descricao;
		this.interacao=interacao;
	}
	
	public String getInteracao(){
		return this.interacao;
	}
	public String getDescricao(){
		return this.descricao;
	}
	public String getNome(){
		return this.nome;
	}
	
}
