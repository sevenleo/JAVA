package modelo;

public class Praca extends Lugar{
	NPC boneco=new NPC("Bonecos de massa","Uma quimera com cabe�a de le�o e corpo de cavalo fazendo coisas",null);
	NPC quimera = new NPC("Quimera","Uma quimera com cabeca de leao e corpo de cavalo fazendo quimerices",null);
	NPC velho = new NPC("Velho","Um [velho] observando a pra�a.... Parece estar olhando para voc�","Voc� jogou gam�o com o velho e perdeu feio!");
	NPC banco = new NPC("Banco de pra�a","Um banco de pra�a fedorento","Voc� dormiu no banco da pra�a");
	
	public Praca(){
		setNome("Praca");
		setResponsavel(null);
		setDescricao("Voce esta na Alameda dos Anjos.... \n" +
				"Existem {bonecos de massa} plantando no jardim, \n" +
				"uma {quimera} fazendo acrobacias de circo \n e um [velho] " +
				"sentado no [banco].");
		getCoisas().add(boneco);
		getCoisas().add(quimera);
		getCoisas().add(velho);
		getCoisas().add(banco);
	}

}

