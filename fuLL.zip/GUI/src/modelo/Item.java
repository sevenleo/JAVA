package modelo;



import java.util.ArrayList;
import java.util.Random;

public class Item {
	private String nome;
	private double preco;
	private int quantidade;
	
	//construtor
	public Item(String name, double price, int qt){
		this.nome=name;
		this.preco=price;
		this.quantidade=qt;
	}

	//get & set
	public String getNome(){
		return this.nome;
	}
	public double getPrecoNovo(){
		return this.preco;
	}
	public double getPrecoUsado(){
		return (this.preco)/2;
	}
	
	//metodos
	public ArrayList<Item> geraArrayArmas(){
		ArrayList<Item> coisas = new ArrayList<Item>();
		
		Random geraQTfaca = new Random();
		int qtfaca=geraQTfaca.nextInt(11)+20;
		Item faca=new Item("Faca", 7.50,qtfaca);
		coisas.add(faca);
		
		Random geraQTespada = new Random();
		int qtespada = geraQTespada.nextInt(11)+20;
		Item espada = new Item("Espada", 18.00,qtespada);
		coisas.add(espada);
		
		Random geraQTescudo = new Random();
		int qtescudo = geraQTescudo.nextInt(11)+20;
		Item escudo = new Item("Escudo",20.70,qtescudo);
		coisas.add(escudo);
		
		return coisas;
	}
	private boolean verificaQuantidade(){
		if (this.quantidade>0){
			return true;
		}
		return false;
	}
	public boolean diminuiQuantidade(){
		if(this.verificaQuantidade()){
			this.quantidade--;
			return true;
		}
		return false;
	}
	public void aumentaQuantidade(){
		this.quantidade++;
	}
}
