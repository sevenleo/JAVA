package modelo;

public class Estalagem extends Lugar {
	private double precoQuarto;
	private NPC mulher = new NPC("Mulher","Uma belissima mulher e parece estar sozinha....",null);
	private NPC atendente = new NPC("Atendente","Um homem incirvelmente grande e com uma cicatriz no rosto.... Parece que esta trabalahdno muito hoje","Hahaha!Ol� l� viajante!Bem vindo ao Cr�nio Furado. Deseja um quarto por "+this.getPrecoQuarto()+"?");
	private NPC caneca = new NPC("Caneca de Hidromel","Parece que essa caneca esta me esperando....","Voc� bebeu o hidromel, estava gelado e muito gostoso.");
	private NPC mesa = new NPC("Mesa","Mesa de madeira, voc� esta tentado a subir na mesa e gritar.","Voc� subiu na mesa e come�ou a gritar 'eu sou o rei daqui!' /n Talvez voc� tenha tomado muito hidromel.");
		
	//construtor
	public Estalagem(){
		this.precoQuarto=35.00;
		setNome("Cr�nio Furado");
		setResponsavel(atendente);
		setDescricao("Cr�nio Furado /n Voc� esta em uma taverna..." +
				"O lugar esta cheio e h� um [atendente] no " +
				"balc�o, uma {mulher} sentada em uma mesa pr�xima " +
				"e uma [caneca de hidromel] em cima de uma [mesa] sem " +
				"ninguem.... ");
		getCoisas().add(mulher);
		getCoisas().add(caneca);
		getCoisas().add(mesa);
	}

	//get&set
	public double getPrecoQuarto(){
		return this.precoQuarto;
	}
	
	
	//metodo
	public boolean dormir(Hero p){
		if(p.verificaDinheiro(this.precoQuarto)){
			p.diminuiDinheiro(this.precoQuarto);
			p.dorme();
			return true;
		}
		return false;
	}

}
