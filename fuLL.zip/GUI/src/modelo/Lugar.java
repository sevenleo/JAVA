package modelo;

import java.util.ArrayList;




public abstract class Lugar {
	private ArrayList<NPC> coisas = new ArrayList<NPC>();
	private String descricao;
	private String nome;
	private NPC responsavel;
	
	public NPC getResponsavel() {
		return responsavel;
	}
	public void setResponsavel(NPC responsavel) {
		this.responsavel = responsavel;
	}
	public void setCoisas(ArrayList<NPC> coisas) {
		this.coisas = coisas;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getNome() {
		return this.nome;
	}
	public ArrayList<NPC> getCoisas() {
		return this.coisas;
	}
	public String getDescricao() {
		return this.descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}
