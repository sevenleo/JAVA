package modelo;


import java.util.ArrayList;


public class Loja extends Lugar{
	private NPC espadas = new NPC("Espadas","Espadas de todos os tipos e tamanhos est�o presas nas paredes",null);
	private NPC atendente = new NPC("Atendente","Um homem j� com certa idade tentando vender algumas de suas armas...","Ol� jovem guerreiro,  que deseja?");
	private NPC rapaz = new NPC("Guerreiro","Um jovem rapaz...Parece ser um guerreiro","Essa loja possui itens muito bons! Vale a pena comprar aqui.");
	private NPC escudos = new NPC("Escudos","Escudos de todos os tipos e tamanhos est�o presos nas paredes","Voc� tentou pegar um escudo mas o atendente lhe repreendeu.");
	private ArrayList<Item> estoque = new ArrayList<Item>();
		
	//construtor
	public Loja(){
		
		setNome("LojaGui de Armas");
		
		setResponsavel(atendente);
		setDescricao("LojaGui de armas." +
			"Voce entrou em uma loja armeira... \n" +
			"H� {espadas} e [escudos] nas paredes, \n" +
			"um [atendente] no balcao e \n" +
			"um [rapaz] parado ao canto.");
		getCoisas().add(espadas);
		getCoisas().add(escudos);
		getCoisas().add(rapaz);
		
		Item descartavel=new Item("",0,0);
		this.estoque=descartavel.geraArrayArmas();
	}
	

	//get&set
	public ArrayList<Item> getEstoque(){
		return this.estoque;
	} 
	//metodos
	public boolean venderItem(Item a){
		Item vendidoLoja = null;
		for(Item descartavel : this.estoque){
			if(descartavel.getNome().equals(a.getNome())){
				vendidoLoja=descartavel;
				break;
			}
		}
		if(vendidoLoja==null){
			return false;
		}else if(vendidoLoja.diminuiQuantidade()){
			return true;
		}else{
			return false;
		}
		
	}
	public boolean comprarItem(Item a){
		Item vendidoLoja = null;
		for(Item descartavel : this.estoque){
			if(descartavel.getNome().equals(a.getNome())){
				vendidoLoja=descartavel;
				break;
			}
		}
		if(vendidoLoja==null){
			return false;
		}else {
			vendidoLoja.aumentaQuantidade();
			return true;
		}
	}
}

