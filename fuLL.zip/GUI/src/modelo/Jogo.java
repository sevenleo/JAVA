package modelo;

import Controlador.ControleRemoto;


public class Jogo implements ControleRemoto{

	
	private String sobre ;
	private Hero heroi;
	private Loja loja;
	private Praca praca;
	
	



	public Jogo(){
		sobre = "Esse jogo foi feito para o trabalho de comp2";
		heroi = new Hero();
		loja = new Loja();
		praca = new Praca();
	}


	
	public Loja getLoja() {
		return loja;
	}


	public void setLoja(Loja loja) {
		this.loja = loja;
	}
	
	
	public String getSobre() {
		return sobre;
	}


	public void setSobre(String sobre) {
		this.sobre = sobre;
	}


	public Hero getHeroi() {
		return heroi;
	}


	public void setHeroi(Hero heroi) {
		this.heroi = heroi;
	}
	public Praca getPraca() {
		return praca;
	}
	public void setPraca(Praca praca) {
		this.praca = praca;
	}

	
	
}
