package modelo;

public class Hospital extends Lugar {
	
		private NPC maca = new NPC("Maca","Uma maca em bom estado....",null);
		private NPC enfermeira = new NPC("Enfermeira","Uma linda enfermeira parada ali...Mas n�o tenho tempo para paqueras agora","Ol� meu querido, deseja reparar seus ferimentos?");
		private NPC senhora = new NPC("Senhora","Uma senhora j� com certa idade... Acho que o moleque � neto dela","Aqui h� medicos muito bons. Venho e aquela mocinha ali *aponta pra enfermeira* � um amor de pessoa!");
		private NPC crianca = new NPC("Crian�a","Crian�a melequenta, mas t���o fofinha.","U������. A crian�a se assustou com a sua cara feia.");
			
		//construtor
		public Hospital(){
			setNome("HospitalGUI da cidade");
			setResponsavel(enfermeira);
			setDescricao("O hospital da cidade. " +
					"H� uma [enfermeira] proxima a uma {maca} " +
					"e uma [senhora] sentada em um banco segurando uma [crian�a].");
			getCoisas().add(senhora);
			getCoisas().add(crianca);
			getCoisas().add(maca);
		}

		//metodos
		public String cuidar(Hero p){
			p.dorme();
			return "Hummm voc� est� bastante mal, acho melhor passar a noite no hospital. " +
					"/n/nVoc� est� curado";
		}

	}

