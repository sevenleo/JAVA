import Controlador.*;
import vista.*;
import modelo.*;


public class Main implements ControleRemoto{


		public static void main(String[] args){
		
			
			controlador.getMenu().mostrar();
			 
			
		}

		
}
