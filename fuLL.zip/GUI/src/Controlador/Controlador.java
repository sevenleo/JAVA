package Controlador;

import vista.Menu;
import modelo.Jogo;

public class Controlador {
	
	private Jogo jogo;
	private Menu menu;

	public Controlador()
	{
		
		jogo= new Jogo();
		menu = new Menu();			
	}

	public Jogo getJogo() {
		return jogo;
	}

	public void setJogo(Jogo jogo) {
		this.jogo = jogo;
	}

	public Menu getMenu() {
		return menu;
	}

	public void setMenu(Menu menu) {
		this.menu = menu;
	}
	
	
}
	
	
	
	