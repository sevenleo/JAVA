package vista;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


import Controlador.*;

import vista.Menu.IniciarOuvinte;

public class PracaGui extends JFrame implements ControleRemoto {
	
	
    JLabel labelLocal;
    JTextArea taDescricao;
    JScrollPane sp_taDescricao;
    JButton botOlhar;
    JButton botInteragir;
    JButton botIr;
    JTextField tfMensagem;
    JLabel labelMensagem;
    JComboBox cbItens;
    JLabel labelItens;
    JButton botAddDinheiro;
    JButton botMenu;
    JButton botSair;
    JButton botSalvar;
    JComboBox cbOlhar;
    JComboBox cbInteragir;
    JTextField tfDinheiro;
    JLabel labelDinheiro;
    JComboBox cbVizinhos;

    public PracaGui() {
        LocalLayout customLayout = new LocalLayout();
        Font font = new Font("calibri", Font.BOLD, 28);

        getContentPane().setFont(new Font("Helvetica", Font.PLAIN, 12));
        getContentPane().setLayout(customLayout);

        
        labelLocal = new JLabel();
        labelLocal.setFont(font);
        labelLocal.setText("Praca");
        getContentPane().add(labelLocal);
        
        taDescricao = new JTextArea("");
        taDescricao.setEditable(false);
        getContentPane().add(taDescricao);

        botOlhar = new JButton("Olhar");
        getContentPane().add(botOlhar);
        botOlhar.addActionListener(new OlharOuvinte());

        botInteragir = new JButton("Interagir");
        getContentPane().add(botInteragir);

        botIr = new JButton("Ir");
        getContentPane().add(botIr);
        botIr.addActionListener(new IrOuvinte());

        tfMensagem = new JTextField("");
        tfMensagem.setEditable(false);
        getContentPane().add(tfMensagem);

        labelMensagem = new JLabel("Mensagem");
        getContentPane().add(labelMensagem);

        cbItens = new JComboBox();
        cbItens.addItem("item1");
        cbItens.addItem("item2");
        cbItens.addItem("item3");
        cbItens.addItem("item4");
        getContentPane().add(cbItens);

        labelItens = new JLabel("Itens");
        getContentPane().add(labelItens);

        botAddDinheiro = new JButton("Dinheiro");
        getContentPane().add(botAddDinheiro);

        botMenu = new JButton("Menu");
        getContentPane().add(botMenu);
        botMenu.addActionListener(new MenuOuvinte());

        botSair = new JButton("Sair");
        getContentPane().add(botSair);
        botSair.addActionListener(new SairOuvinte());

        cbOlhar = new JComboBox();
        getContentPane().add(cbOlhar);

        cbInteragir = new JComboBox();
        getContentPane().add(cbInteragir);

        tfDinheiro = new JTextField("");
        tfDinheiro.setEditable(false);
        getContentPane().add(tfDinheiro);

        labelDinheiro = new JLabel("Dinheiro");
        getContentPane().add(labelDinheiro);

        cbVizinhos = new JComboBox();
        cbVizinhos.addItem("Hospital");
        cbVizinhos.addItem("Loja");
        cbVizinhos.addItem("Deposito");
        cbVizinhos.addItem("Estalagem");
        
        getContentPane().add(cbVizinhos);
        
        botSalvar = new JButton("Salvar");
        getContentPane().add(botSalvar);

        setSize(getPreferredSize());

        
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
    
    public class MenuOuvinte implements ActionListener{
    	@Override
		public void actionPerformed(ActionEvent ev){
    		new Menu().mostrar( );
    		PracaGui.this.dispose();
    		
		
		}
	
	}
    
    public class SairOuvinte implements ActionListener{
    	@Override
		public void actionPerformed(ActionEvent ev){
    		System.exit(0);
		}
	
	}
    
    public class OlharOuvinte implements ActionListener{
    	@Override
		public void actionPerformed(ActionEvent ev){
    		String olharCoisa = (String)cbOlhar.getSelectedItem();
    		for (modelo.NPC pessoa : controlador.getJogo().getPraca().getCoisas()){
    			if(pessoa.getNome().equals(olharCoisa)) taDescricao.setText(pessoa.getDescricao());
    		}
    		//if(olharCoisa.equalsIgnoreCase("quimera")) taDescricao.append(controlador.getJogo().getPraca());
		}
	}
    
    public class InteragirOuvinte implements ActionListener{
    	@Override
		public void actionPerformed(ActionEvent ev){
		
		
		}
	
	}
    
    public class IrOuvinte implements ActionListener{
    	@Override
		public void actionPerformed(ActionEvent ev){
    		String irLocal = (String)cbVizinhos.getSelectedItem();
    		if(irLocal.equalsIgnoreCase("loja")) new LojaGui().abrir();
    		if(irLocal.equalsIgnoreCase("deposito")) new DepositoGui().abrir();
    		if(irLocal.equalsIgnoreCase("estalagem")) new EstalagemGUI().abrir();
    		if(irLocal.equalsIgnoreCase("hospital")) new HospitalGUI().abrir();
    		PracaGui.this.dispose();
		
		
		}
	
	}
    
    public class DinheiroOuvinte implements ActionListener{
    	@Override
		public void actionPerformed(ActionEvent ev){
		
		
		}
	
	}
    public class SalvarOuvinte implements ActionListener{
    	@Override
		public void actionPerformed(ActionEvent ev){
		
		
		}
	
	}
    
    public void abrir() {
        PracaGui window = new PracaGui();

        window.setTitle("Praca");
        window.pack();
        window.setVisible(true);
        window.taDescricao.setText(controlador.getJogo().getPraca().getDescricao());
        
        for(modelo.NPC pessoas : controlador.getJogo().getPraca().getCoisas()){
        	window.cbOlhar.addItem(pessoas.getNome());
        }
        for(modelo.NPC coisas : controlador.getJogo().getPraca().getCoisas()){
            window.cbInteragir.addItem(coisas.getNome());
            window.cbInteragir.removeItem("Bonecos de massa");
            window.cbInteragir.removeItem("Quimera");
            
        }
    }
    
}










// Gerenciador de layout pr�prio da classe

class LocalLayout implements LayoutManager {

    public LocalLayout() {
    }

    public void addLayoutComponent(String name, Component comp) {
    }

    public void removeLayoutComponent(Component comp) {
    }

    public Dimension preferredLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);

        Insets insets = parent.getInsets();
        dim.width = 543 + insets.left + insets.right;
        dim.height = 324 + insets.top + insets.bottom;

        return dim;
    }

    public Dimension minimumLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);
        return dim;
    }

    public void layoutContainer(Container parent) {
        Insets insets = parent.getInsets();

        Component c;
        c = parent.getComponent(0);
        if (c.isVisible()) {c.setBounds(insets.left+200,insets.top+16,128,32);}
        c = parent.getComponent(1);
        if (c.isVisible()) {c.setBounds(insets.left+40,insets.top+64,400,88);}
        c = parent.getComponent(2);
        if (c.isVisible()) {c.setBounds(insets.left+40,insets.top+168,72,24);}
        c = parent.getComponent(3);
        if (c.isVisible()) {c.setBounds(insets.left+40,insets.top+200,72,24);}
        c = parent.getComponent(4);
        if (c.isVisible()) {c.setBounds(insets.left+40,insets.top+232,48,24);}
        c = parent.getComponent(5);
        if (c.isVisible()) {c.setBounds(insets.left+128,insets.top+280,360,24);}
        c = parent.getComponent(6);
        if (c.isVisible()) {c.setBounds(insets.left+40,insets.top+280,80,24);}
        c = parent.getComponent(7);
        if (c.isVisible()) {c.setBounds(insets.left+296,insets.top+168,72,24);}
        c = parent.getComponent(8);
        if (c.isVisible()) {c.setBounds(insets.left+216,insets.top+168,72,24);}
        c = parent.getComponent(9);
        if (c.isVisible()) {c.setBounds(insets.left+216,insets.top+232,104,24);}
        c = parent.getComponent(10);
        if (c.isVisible()) {c.setBounds(insets.left+456,insets.top+64,72,24);}
        c = parent.getComponent(11);
        if (c.isVisible()) {c.setBounds(insets.left+456,insets.top+96,72,24);}
        c = parent.getComponent(12);
        if (c.isVisible()) {c.setBounds(insets.left+128,insets.top+168,72,24);}
        c = parent.getComponent(13);
        if (c.isVisible()) {c.setBounds(insets.left+128,insets.top+200,72,24);}
        c = parent.getComponent(14);
        if (c.isVisible()) {c.setBounds(insets.left+296,insets.top+200,72,24);}
        c = parent.getComponent(15);
        if (c.isVisible()) {c.setBounds(insets.left+216,insets.top+200,72,24);}
        c = parent.getComponent(16);
        if (c.isVisible()) {c.setBounds(insets.left+128,insets.top+232,72,24);}
        c = parent.getComponent(17);
        if (c.isVisible()) {c.setBounds(insets.left+456,insets.top+128,72,24);}
    }
 
}
