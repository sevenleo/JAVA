package vista;
import Controlador.*;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import modelo.Jogo;

//import Controlador.Controlador;

//import GUI.CapturaListener;

public class Menu extends JFrame implements ActionListener, ControleRemoto {
    JLabel labelJogo;
    JButton botIniciar;
    JButton botCarregar;
    JButton botInstrucoes;
    JButton botSair;

    InstrucoesGui instrucoesGui ;
    LojaGui lojaGui ;
	PracaGui pracaGui ;
	DepositoGui depositoGui;
    NomeGUI nomeGUI;
    
    
	
	
	
	
	
	
	
	
    public Menu() {
        MenuLayout customLayout = new MenuLayout();
        Font font = new Font("calibri", Font.BOLD, 28);
        
        //criando menus
        
        instrucoesGui = new InstrucoesGui();
        lojaGui = new LojaGui();
  		pracaGui = new PracaGui();
  		depositoGui = new DepositoGui();
  		
       // new NomeGUI().abrir();
        
        
        
        getContentPane().setLayout(customLayout);

        labelJogo = new JLabel();
        labelJogo.setFont(font);
        labelJogo.setText("Jogo");
        getContentPane().add(labelJogo);

        botIniciar = new JButton("Iniciar");
        getContentPane().add(botIniciar);
        botIniciar.addActionListener(new IniciarOuvinte());

        botCarregar = new JButton("Carregar");
        getContentPane().add(botCarregar);
        botCarregar.addActionListener(new CarregarOuvinte());

        botInstrucoes = new JButton("Instrucoes");
        getContentPane().add(botInstrucoes);
        botInstrucoes.addActionListener(new InstrucoesOuvinte());

        botSair = new JButton("Sair");
        getContentPane().add(botSair);
        botSair.addActionListener(new SairOuvinte());

        setSize(getPreferredSize());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 

    }
        

    	
    	
    	
    	
    	
    	
    	
    	
    	
    
       public JLabel getLabelJogo() {
		return labelJogo;
	}

	










	class IniciarOuvinte implements ActionListener {
        	@Override
        	public void actionPerformed(ActionEvent ev){
        		//new PracaGui().abrir();
        		//Menu.this.dispose();
        		Menu.this.pracaGui.abrir();
        		Menu.this.setVisible(false);
        		
        		
        	}
        }
       
       class CarregarOuvinte implements ActionListener {
       		@Override
       		public void actionPerformed(ActionEvent ev){
       		
       		}
       	
       }
       
       class InstrucoesOuvinte implements ActionListener {
       		@Override
       		public void actionPerformed(ActionEvent ev){
        		new InstrucoesGui().abrir( );
        		Menu.this.dispose();
       		}
       	
       }
       
       class SairOuvinte implements ActionListener {
    	   @Override
    	   public void actionPerformed(ActionEvent ev){
    		   System.exit(0);
       	
    	   }
       	
       }
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       //public static void main(String args[]) {
       public void mostrar(){
  
       	   Menu window = new Menu();

           window.setTitle(controlador.getJogo().getHeroi().getNome());
       
       	  
       	   //window.setTitle("Ola ");
           window.pack();
           window.setVisible(true);
       }

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}

    



















    
//Gerenciador de layout proprio
class MenuLayout implements LayoutManager {

    public MenuLayout() {
    }

    public void addLayoutComponent(String name, Component comp) {
    }

    public void removeLayoutComponent(Component comp) {
    }

    public Dimension preferredLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);

        Insets insets = parent.getInsets();
        dim.width = 559 + insets.left + insets.right;
        dim.height = 349 + insets.top + insets.bottom;

        return dim;
    }

    public Dimension minimumLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);
        return dim;
    }

    public void layoutContainer(Container parent) {
        Insets insets = parent.getInsets();

        Component c;
        c = parent.getComponent(0);
        if (c.isVisible()) {c.setBounds(insets.left+160,insets.top+32,232,72);}
        c = parent.getComponent(1);
        if (c.isVisible()) {c.setBounds(insets.left+424,insets.top+136,104,32);}
        c = parent.getComponent(2);
        if (c.isVisible()) {c.setBounds(insets.left+424,insets.top+184,104,32);}
        c = parent.getComponent(3);
        if (c.isVisible()) {c.setBounds(insets.left+424,insets.top+232,104,32);}
        c = parent.getComponent(4);
        if (c.isVisible()) {c.setBounds(insets.left+424,insets.top+280,104,32);}
        
    }
}
