package vista;
import Controlador.ControleRemoto;

import java.awt.event.*;
import java.util.*;
import java.awt.*;
import javax.swing.*;



public class NomeGUI extends JFrame implements ControleRemoto {

		
		private JTextArea area = new JTextArea(10,30);
		private JTextField field = new JTextField(20);
	    private JButton button1;
	 
	  
		public JTextArea getSheet(){
			return area;
		}
		
		public JTextField getField(){
			return field;
		}

		public void NomeGUI(){
			
		}
		
		
		void abrir(){
			JFrame frame = new JFrame();
			JPanel panel = new JPanel();
			JPanel panel2 = new JPanel();
			
			area = new JTextArea(10,30);
			field = new JTextField(20);
			JButton button1 = new JButton("Confirmar");
			
			area.setEditable(false);
			panel.add(area);
			frame.getContentPane().add(BorderLayout.NORTH, panel);

			button1.addActionListener(new CapturaListener());
			
			panel2.add(button1);
			
			panel2.add(field);
			frame.getContentPane().add(BorderLayout.CENTER, panel2);
			frame.setSize(400,400);
			frame.setVisible(true);
			
			
			
			area.setText("Qual o seu nome?\n");
			

		}
		

		
		
		public class CapturaListener implements ActionListener{
				
			public void actionPerformed(ActionEvent ev){
					
				controlador.getJogo().getHeroi().setNome(  field.getText()  );
				area.setText("Ok");
				NomeGUI.this.dispose();
				
			}
		}
	

	
}
