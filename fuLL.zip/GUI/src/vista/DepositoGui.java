package vista;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class DepositoGui extends JFrame {
	private static final long serialVersionUID = 1L;
	JTextArea taDescricao;
	JTextField tfMensagem;
	JTextField tfDinheiro;
	JComboBox cbItens;
	JComboBox cbArmazenar;
	JComboBox cbRecuperar;
	JButton botAddDinheiro;
	JButton botMenu;
	JButton botSair;
	JButton botArmazenar;
    JButton botRecuperar;
    JLabel labelLoja;
    JLabel labelMensagem;
    JLabel labelItens;
    JLabel labelDinheiro;

    public DepositoGui() {
        DepositoLayout customLayout = new DepositoLayout();
        Font font = new Font("calibri", Font.BOLD, 28);
        getContentPane().setLayout(customLayout);

        labelLoja = new JLabel();
        labelLoja.setFont(font);
        labelLoja.setText("Dep�sito");
        getContentPane().add(labelLoja);

        taDescricao = new JTextArea("");
        taDescricao.setEditable(false);
        getContentPane().add(taDescricao);

        tfMensagem = new JTextField("");
        tfMensagem.setEditable(false);
        getContentPane().add(tfMensagem);

        labelMensagem = new JLabel("Mensagem");
        getContentPane().add(labelMensagem);

        cbItens = new JComboBox();
        cbItens.addItem("item1");
        cbItens.addItem("item2");
        cbItens.addItem("item3");
        cbItens.addItem("item4");
        getContentPane().add(cbItens);

        labelItens = new JLabel("Itens");
        getContentPane().add(labelItens);

        botAddDinheiro = new JButton("Dinheiro");
        botAddDinheiro.addActionListener(new DinheiroOuvinte());
        getContentPane().add(botAddDinheiro);

        botMenu = new JButton("Menu");
        botMenu.addActionListener(new MenuOuvinte());
        getContentPane().add(botMenu);

        botSair = new JButton("Sair");
        botSair.addActionListener(new SairOuvinte());
        getContentPane().add(botSair);

        tfDinheiro = new JTextField("");
        tfDinheiro.setEditable(false);
        getContentPane().add(tfDinheiro);

        labelDinheiro = new JLabel("Dinheiro");
        getContentPane().add(labelDinheiro);

        botArmazenar = new JButton("Armazenar");
        getContentPane().add(botArmazenar);

        cbArmazenar = new JComboBox();
        cbArmazenar.addItem("item1");
        cbArmazenar.addItem("item2");
        getContentPane().add(cbArmazenar);

        botRecuperar= new JButton("Recuperar");
        botRecuperar.addActionListener(new RecuperarOuvinte());
        getContentPane().add(botRecuperar);

        cbRecuperar = new JComboBox();
        cbRecuperar.addItem("item1");
        cbRecuperar.addItem("item2");
        getContentPane().add(cbRecuperar);

        setSize(getPreferredSize());

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
        
        public  void abrir() {
            DepositoGui window = new DepositoGui();

            window.setTitle("loja");
            window.pack();
            window.setVisible(true);
        }
        
        public class MenuOuvinte implements ActionListener{
        	@Override
    		public void actionPerformed(ActionEvent ev){
        		new Menu().mostrar( );
        		DepositoGui.this.dispose();
        		
    		
    		}
    	
    	}
        
        public class SairOuvinte implements ActionListener{
        	@Override
    		public void actionPerformed(ActionEvent ev){
        		
    		}
    	
    	}
        
        public class DinheiroOuvinte implements ActionListener{
        	@Override
    		public void actionPerformed(ActionEvent ev){
        		
    		}
    	
    	}
        
        public class ArmazenarOuvinte implements ActionListener{
        	@Override
    		public void actionPerformed(ActionEvent ev){
        		
    		}
    	
    	}
        
        public class RecuperarOuvinte implements ActionListener{
        	@Override
    		public void actionPerformed(ActionEvent ev){
        		
    		}
    	
    	}

  }

//Gerenciador pr�prio da classe
class DepositoLayout implements LayoutManager {

    public DepositoLayout() {
    }

    public void addLayoutComponent(String name, Component comp) {
    }

    public void removeLayoutComponent(Component comp) {
    }

    public Dimension preferredLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);

        Insets insets = parent.getInsets();
        dim.width = 620 + insets.left + insets.right;
        dim.height = 376 + insets.top + insets.bottom;

        return dim;
    }

    public Dimension minimumLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);
        return dim;
    }

    public void layoutContainer(Container parent) {
        Insets insets = parent.getInsets();

        Component c;
        c = parent.getComponent(0);
        if (c.isVisible()) {c.setBounds(insets.left+216,insets.top+16,128,32);}
        c = parent.getComponent(1);
        if (c.isVisible()) {c.setBounds(insets.left+40,insets.top+64,448,96);}
        c = parent.getComponent(2);
        if (c.isVisible()) {c.setBounds(insets.left+128,insets.top+320,400,24);}
        c = parent.getComponent(3);
        if (c.isVisible()) {c.setBounds(insets.left+40,insets.top+320,80,24);}
        c = parent.getComponent(4);
        if (c.isVisible()) {c.setBounds(insets.left+128,insets.top+184,72,24);}
        c = parent.getComponent(5);
        if (c.isVisible()) {c.setBounds(insets.left+40,insets.top+184,72,24);}
        c = parent.getComponent(6);
        if (c.isVisible()) {c.setBounds(insets.left+504,insets.top+128,96,24);}
        c = parent.getComponent(7);
        if (c.isVisible()) {c.setBounds(insets.left+504,insets.top+96,96,24);}
        c = parent.getComponent(8);
        if (c.isVisible()) {c.setBounds(insets.left+504,insets.top+64,96,24);}
        c = parent.getComponent(9);
        if (c.isVisible()) {c.setBounds(insets.left+128,insets.top+224,72,24);}
        c = parent.getComponent(10);
        if (c.isVisible()) {c.setBounds(insets.left+40,insets.top+224,72,24);}
        c = parent.getComponent(11);
        if (c.isVisible()) {c.setBounds(insets.left+240,insets.top+184,104,24);}
        c = parent.getComponent(12);
        if (c.isVisible()) {c.setBounds(insets.left+368,insets.top+184,72,24);}
        c = parent.getComponent(13);
        if (c.isVisible()) {c.setBounds(insets.left+240,insets.top+224,104,24);}
        c = parent.getComponent(14);
        if (c.isVisible()) {c.setBounds(insets.left+368,insets.top+224,72,24);}
    }
}
