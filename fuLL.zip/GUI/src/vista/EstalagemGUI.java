﻿package vista;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class EstalagemGUI extends JFrame {
	
    JLabel labelLoja;
    JTextField tfMensagem;
    JTextArea taDescricao;
    JScrollPane sp_taDescricao;
    JButton botOlhar;
    JButton botInteragir;
    JButton botIr;
    JButton botMenu;
    JButton botSair;
    JComboBox cbOlhar;
    JComboBox cbInteragir;
    JComboBox cbIr;
    JLabel labelItens;
    JComboBox cbItens;
    JLabel labelDinheiro;
    JComboBox cbItens2;
    JButton botDinheiro;
    JButton botSim;
    JButton botNao;
    JLabel labelMensagem;

    public EstalagemGUI() {
        EstalagemLayout customLayout = new EstalagemLayout();
        Font font =  new Font("Comic Sans", Font.PLAIN, 32);

        getContentPane().setFont(new Font("Helvetica", Font.PLAIN, 12));
        getContentPane().setLayout(customLayout);

        labelLoja = new JLabel("EstalagemGUI");
        labelLoja.setFont(font);
        getContentPane().add(labelLoja);
        
        tfMensagem = new JTextField();
        tfMensagem.setEditable(false);
        getContentPane().add(tfMensagem);

        taDescricao = new JTextArea();
        taDescricao.setEditable(false);
        sp_taDescricao = new JScrollPane(taDescricao);
        getContentPane().add(sp_taDescricao);

        botOlhar = new JButton("Olhar");
        botOlhar.addActionListener(new olharOuvinte());
        getContentPane().add(botOlhar);

        botInteragir = new JButton("Interagir");
        botInteragir.addActionListener(new interagirOuvinte());
        getContentPane().add(botInteragir);

        botIr = new JButton("Ir");
        botIr.addActionListener(new irOuvinte());
        getContentPane().add(botIr);

        botMenu = new JButton("Menu");
        botMenu.addActionListener(new menuOuvinte());
        getContentPane().add(botMenu);

        botSair = new JButton("Sair");
        botSair.addActionListener(new sairOuvinte());
        getContentPane().add(botSair);

        cbOlhar = new JComboBox();
        cbOlhar.addItem("item1");
        cbOlhar.addItem("item2");
        cbOlhar.addItem("item3");
        cbOlhar.addItem("item4");
        getContentPane().add(cbOlhar);

        cbInteragir = new JComboBox();
        cbInteragir.addItem("item1");
        cbInteragir.addItem("item2");
        cbInteragir.addItem("item3");
        cbInteragir.addItem("item4");
        getContentPane().add(cbInteragir);

        cbIr = new JComboBox();
        cbIr.addItem("Pra�a");
        getContentPane().add(cbIr);

        labelItens = new JLabel("Itens");
        getContentPane().add(labelItens);

        cbItens = new JComboBox();
        cbItens.addItem("item1");
        cbItens.addItem("item2");
        cbItens.addItem("item4");
        cbItens.addItem("");
        getContentPane().add(cbItens);

        labelDinheiro = new JLabel("Dinheiro");
        getContentPane().add(labelDinheiro);

        cbItens2 = new JComboBox();
        cbItens2.addItem("item1");
        cbItens2.addItem("item2");
        cbItens2.addItem("itenm3");
        cbItens2.addItem("item4");
        getContentPane().add(cbItens2);

        botDinheiro = new JButton("Dinheiro");
        botDinheiro.addActionListener(new dinheiroOuvinte());
        getContentPane().add(botDinheiro);

        botSim = new JButton("Sim");
        botSim.addActionListener(new comprarOuvinte());
        getContentPane().add(botSim);

        botNao = new JButton("Nao");
        botNao.addActionListener(new venderOuvinte());
        getContentPane().add(botNao);

        labelMensagem = new JLabel("Mensagem :");
        getContentPane().add(labelMensagem);

        setSize(getPreferredSize());

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
    
    // Classes dos ouvintes dos bot�es
    
    class menuOuvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		
    	}
    }
    
    class sairOuvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		
    	}
    }
    
    class olharOuvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		
    		
    	}
    }
    
    class interagirOuvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		
    	}
    }
    
    class irOuvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		
    		
    	}
    }
    
    class comprarOuvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		
    		
    	}
    }
    
    class venderOuvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		
    		
    	}
    }
    
    class dinheiroOuvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		
    	}
    	
    }
    
    
    public  void abrir() {
        EstalagemGUI window = new EstalagemGUI();

        window.setTitle("Estalagem");
        window.pack();
        window.setVisible(true);
    }
}


class EstalagemLayout implements LayoutManager {

    public EstalagemLayout() {
    }

    public void addLayoutComponent(String name, Component comp) {
    }

    public void removeLayoutComponent(Component comp) {
    }

    public Dimension preferredLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);

        Insets insets = parent.getInsets();
        dim.width = 683 + insets.left + insets.right;
        dim.height = 439 + insets.top + insets.bottom;

        return dim;
    }

    public Dimension minimumLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);
        return dim;
    }

    public void layoutContainer(Container parent) {
        Insets insets = parent.getInsets();

        Component c;
        c = parent.getComponent(0);
        if (c.isVisible()) {c.setBounds(insets.left+250,insets.top+32,216,56);}
        c = parent.getComponent(1);
        if (c.isVisible()) {c.setBounds(insets.left+144,insets.top+384,400,24);}
        c = parent.getComponent(2);
        if (c.isVisible()) {c.setBounds(insets.left+32,insets.top+104,512,136);}
        c = parent.getComponent(3);
        if (c.isVisible()) {c.setBounds(insets.left+32,insets.top+256,104,24);}
        c = parent.getComponent(4);
        if (c.isVisible()) {c.setBounds(insets.left+32,insets.top+296,104,24);}
        c = parent.getComponent(5);
        if (c.isVisible()) {c.setBounds(insets.left+32,insets.top+336,104,24);}
        c = parent.getComponent(6);
        if (c.isVisible()) {c.setBounds(insets.left+560,insets.top+104,96,24);}
        c = parent.getComponent(7);
        if (c.isVisible()) {c.setBounds(insets.left+560,insets.top+384,96,24);}
        c = parent.getComponent(8);
        if (c.isVisible()) {c.setBounds(insets.left+152,insets.top+256,72,24);}
        c = parent.getComponent(9);
        if (c.isVisible()) {c.setBounds(insets.left+152,insets.top+296,72,24);}
        c = parent.getComponent(10);
        if (c.isVisible()) {c.setBounds(insets.left+152,insets.top+336,72,24);}
        c = parent.getComponent(11);
        if (c.isVisible()) {c.setBounds(insets.left+272,insets.top+256,72,24);}
        c = parent.getComponent(12);
        if (c.isVisible()) {c.setBounds(insets.left+360,insets.top+256,72,24);}
        c = parent.getComponent(13);
        if (c.isVisible()) {c.setBounds(insets.left+272,insets.top+296,72,24);}
        c = parent.getComponent(14);
        if (c.isVisible()) {c.setBounds(insets.left+360,insets.top+296,72,24);}
        c = parent.getComponent(15);
        if (c.isVisible()) {c.setBounds(insets.left+560,insets.top+144,96,24);}
        c = parent.getComponent(16);
        if (c.isVisible()) {c.setBounds(insets.left+448,insets.top+256,96,24);}
        c = parent.getComponent(17);
        if (c.isVisible()) {c.setBounds(insets.left+448,insets.top+296,96,24);}
        c = parent.getComponent(18);
        if (c.isVisible()) {c.setBounds(insets.left+32,insets.top+384,104,24);}
    }
}


