package serialswing;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.AbstractAction;
import javax.swing.Action;

public class desktop implements ActionListener {

	private JFrame frame;
	private JTextField textField;


	/**
	 * Launch the application.
	 */
	
	
	
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					desktop window = new desktop();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	
	
	
	
	
	
	
	/**
	 * Create the application.
	 */
	public desktop() {
		
		initialize();
	}

	
	
	
	
	
	
	
	JTextArea textArea = new JTextArea();
	
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame();
		frame.setBackground(Color.ORANGE);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JButton btnMostra = new JButton("CONSOLE");
		btnMostra.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new console().abre();
			}
		});
		
		
		
		
		frame.getContentPane().add(btnMostra, BorderLayout.WEST);
		
		JButton btnDigitaNome = new JButton("DIGITA = NOME");
		
		btnDigitaNome.addActionListener(this);
	
		frame.getContentPane().add(btnDigitaNome, BorderLayout.EAST);
		
		//JTextArea textArea = new JTextArea();
		
		frame.getContentPane().add(textArea, BorderLayout.CENTER);
		textArea.append( "Ola humano");
		
		
		
	}
	public void actionPerformed(ActionEvent evt){
		 Object source = evt.getSource();
	//	if (source = btnDigitaNome ) System.out.println(" ");
	//	System.out.println("tchau");
		textArea.append( "Ola humano2\n");
		//System.exit(0);
	
	}

	
	
	
}
	
