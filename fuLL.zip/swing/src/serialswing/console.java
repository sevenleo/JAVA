package serialswing;

//import java.io.IOException;
import java.util.*;
import java.io.*;

public class console {

	// public static void main( String[] args ) throws IOException, ClassNotFoundException{
		   
			public void abre() {
				   System.out.println("---------------------- Entre com detalhes");
				   
				   detalhes d = new detalhes();
				   detalhes e = new detalhes();
				  
				   
				    try{  
						   
						   d.save();
				    	   System.out.println(d);
						   System.out.println(e);
						   
						   System.out.println("---------------------- digite");
						   new java.util.Scanner(System.in).next();
						   e=e.load();
						   
						 
						   System.out.println("---------------------- digite");
						   new java.util.Scanner(System.in).next();
						   System.out.println(d);
						   System.out.println(e);
				    }
				    catch(IOException e1){
				    	 e1.printStackTrace( );
				    }
				    catch(ClassNotFoundException e1){
				    	 e1.printStackTrace( );
				    }
				   
	   }

}

