package serialswing;

import java.util.*;
import java.io.*;


class detalhes implements Serializable{
	
		String a;
		float b;
	
	
		public void setA() {
			this.a = new java.util.Scanner(System.in).nextLine();
		}
	
	
		public void setB() {
			this.b = new java.util.Scanner(System.in).nextInt();
		}
	
	
		public detalhes(){
			System.out.println("get nome");
			this.setA();
			System.out.println("get num");
			this.setB();
	
		}
		@Override
		 public String toString( ){
			//String s=System.out.println("nome:"+a+ "\nnumero:"+b);
			return "nome:"+a+ "\nnumero:"+b;
		}
	
		
		
		
		
		
		public void save() {
			
			try{
				FileOutputStream file= new FileOutputStream("dados.dat");
				ObjectOutputStream obj = new ObjectOutputStream(file);
				
				obj.writeObject(this);
				obj.close();
				file.close();
				System.out.println("Saved ...\n");
				}
				catch( FileNotFoundException e){
					System.out.println("erro no arquivo");
				}catch(IOException e){
					System.out.println("erro na transicao");
				}
			
			
				
		}		
				
		public detalhes load( ) throws IOException, ClassNotFoundException{
			FileInputStream file =new FileInputStream("dados.dat");
			ObjectInputStream obj =new ObjectInputStream(file);
			
			System.out.println("Load ... \n");

			//obj.close();
			//file.close();
			return (detalhes)obj.readObject();
		}

		
	
		
		
		

}


