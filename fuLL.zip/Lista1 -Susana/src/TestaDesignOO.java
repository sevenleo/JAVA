import java.util.Scanner;
public class TestaDesignOO {
	public static void main(String[] args) {

		//cria loja
		Loja muquifo=new Loja("Loja de armas");

		//cria personagem
		System.out.println("Escolha o nome do seu personagem.");
		Scanner sc = new java.util.Scanner (System.in);
		String nome;
		nome=sc.nextLine();
		Personagem fulano=new Personagem(nome, muquifo.getEstoque());

		do{
			while(!fulano.estaDentro()){
				System.out.println(fulano.getNome()+" o que voc� quer fazer?\n1 - Entrar em "+muquifo.getNome()+"\n2 - Trabalhar");
				Scanner op = new java.util.Scanner (System.in);
				int opcao=op.nextInt();
				if(opcao==2){
					fulano.trabalhar();
				}
				else if(opcao==1){
					fulano.entrar(muquifo);
				}
				else{
					System.out.println("Escolha uma op��o v�lida");
				}
			}
			while(fulano.estaDentro()){
				System.out.println("Voc� tem R$"+fulano.getDinheiro()+".");
				int opcoes = muquifo.mostraEstoque();
				Scanner op = new java.util.Scanner (System.in);
				int opcao=op.nextInt();
				if(opcao>opcoes||opcao<=0){
					System.out.println("Volte quando tiver decidido fazer algo.");
					fulano.sair();
				}
				else if(opcao==opcoes){
					System.out.println("Volte sempre");
					fulano.sair();
				}else if(opcao==opcoes-1){
					fulano.mostraItens();
					int venda=fulano.vende();
					if(venda>=0){
						muquifo.compra(venda);
					}
				}
				else{
					opcao--;
					Item arma=muquifo.getArma(opcao);
					fulano.compra(arma, opcao);
				}
			}
		}while(true);
	
	}
}
