public class Loja {
	//Atributos
	private String nome;
	private Item estoque[];
	
	//Construtor
	public Loja(String nome){
		this.nome=nome;
		this.estoque=new Item[3];
		this.escolheEstoque(this.estoque);
	}

	//M�todos
	public Item getArma(int x){
		return this.estoque[x];
	}
	public void vende(int x){
		System.out.println(x);
		this.estoque[x].quantidade--;
	}
	public String getNome(){
		return this.nome;
	}
	public Item[] getEstoque(){
		return this.estoque; 
	}
	private void escolheEstoque(Item a[]){
		for (int i=1;i<=3;i++){
			Item b = new Item();
			b.geraItem(i);
			a[i-1]=b;
		}
	}
	public void compra(int x){
		this.estoque[x].quantidade++;
	}
	
	public int mostraEstoque(){
		System.out.println("Bem vindo a "+this.getNome()+" o que deseja?");
		int i =1;
		for(Item item:this.estoque){
			System.out.println(i +" - "+item.nome+" por R$"+item.preco+" cada.("+item.quantidade+")");
			i++;
		}
		System.out.println(i+" - Vender itens");
		i++;
		System.out.println((i)+" - Sair");
		return i;
	}
}
