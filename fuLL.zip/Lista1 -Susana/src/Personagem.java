import java.util.Random;
import java.util.ArrayList;
import java.util.Scanner;

public class Personagem {
	//Atributos
	private String nome;
	private float dinheiro;
	private boolean dentro=false;
	private ArrayList<Item> inventario = new ArrayList<Item>();
	
	//Construtor
	public Personagem(String nome, Item[] loja){
		this.nome=nome;
		Random gerador = new Random();
		this.dinheiro = gerador.nextInt(41)+60;
		this.geraInventario(this.inventario, loja);
	}
	
	//M�todos
	public void geraInventario(ArrayList<Item> arrayList, Item[] loja){
		for (int i=1;i<=3;i++){
			Item b = new Item();
			b.geraItem(i);
			arrayList.add(b);
		}
		int i=0;
		for (Item lala: arrayList){
			lala.preco=loja[i].preco/2;
			i++;
		}
		
	}
	public void mostraItens(){
		int i=1;
		for(Item item:this.inventario){
			System.out.println(i +" - "+item.nome+" por R$"+item.preco+" cada.("+item.quantidade+")");
			i++;
		}
		System.out.println("Qual deles voc� deseja me vender?");
	}
	public String getNome(){
		return this.nome;
	}
	public float getDinheiro(){
		return dinheiro;
	}
	public void trabalhar(){
		if(!this.dentro){
			Random geradorValor = new Random();
			int valor = geradorValor.nextInt(11) +20;
			Random geradorHora = new Random();
			int hora = geradorHora.nextInt(8)+1;
			valor*=hora;
			this.dinheiro+=valor;
			System.out.println("Parab�ns, voc� trabalhou "+hora+" horas e ganhou R$"+valor+".");
		}else{
			System.out.println("Voc� precisa sair da loja para poder trabalhar");
		}
	}
	public int vende(){
		Scanner opt = new java.util.Scanner (System.in);
		int option=opt.nextInt();
		option--;
		if (option<0||option>3){
			System.out.println("N�o estou aqui para brincadeira!");
			System.out.println("Voc� foi expulso da loja");
			this.sair();
			return -1;
		}else{
			Item item = this.inventario.get(option);
			if (item.quantidade==0){
				System.out.println("Como voc� vai me vender algo que voc� n�o tem?");
				return -1;
			}else{
				item.quantidade--;
				this.dinheiro+=item.preco;
				return option;
			}
		}
	}
	public void entrar(Loja bangalo){
		dentro=true;
	}
	
	public void sair(){
		dentro=false;
	}
	
	public boolean estaDentro(){
		return this.dentro;
	}
	private boolean temDinheiroParaComprar(float x){
		if(x>this.dinheiro){
			return false;
		}else{
			return true;
		}
	}
	public void compra(Item item, int x){
		if(this.dentro){
			if(this.temDinheiroParaComprar(item.preco)){
				if(item.temEstoque()){
					this.dinheiro-=item.preco;
					item.quantidade--;
					item=this.inventario.get(x);
					item.quantidade++;
				}
				else{
					System.out.println("Lamento, mas n�o temos o item.");
				}
			}else{
				System.out.println("N�O VENDEMOS FIADO!");
				this.dentro=false;
				System.out.println("Voc� foi expulso da loja.");
			}
		}else{
			System.out.println("� necess�rio estar dentro da loja para comprar um item");
		}
	}
}