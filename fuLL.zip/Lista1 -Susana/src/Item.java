import java.util.Random;
public class Item {
	//Atributos
	public String nome;
	public int quantidade;
	public float preco;
	
	//M�todos
	public void foiVendido(int x){
		this.quantidade-=x;
	}
	public boolean temEstoque(){
		if (this.quantidade <=0){
			return false;
		}
		else{
			return true;
		}
	}
	public void geraItem(int tipo){
		if(tipo==1){
			this.nome="Espada";
		}else if(tipo==2){
			this.nome="Adaga";
		}else if(tipo==3){
			this.nome="Bast�o";
		}
		Random gerador = new Random();
		this.preco = gerador.nextInt(11)+20;
		this.quantidade = gerador.nextInt(11);
	}
}
