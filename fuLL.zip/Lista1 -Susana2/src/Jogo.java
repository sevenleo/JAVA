import java.util.Random;

public class Jogo {
	//Atributos
	public String lojaNome=new String ("Loja de Armas");
	public String lojaItensNome[]=new String[3];
	public int lojaItensPreco[] =new int[3];
	public int lojaItensQuantidade[] =new int[3];
	
	public String personagemNome;
	public int personagemDinheiro;
	public boolean personagemDentro=false;
	
	//M�todos sendo usados como fun��es
	public void geraItensNome(String array[]){
		array[0]="Espada";
		array[1]="Adaga";
		array[2]="Bast�o";
	}
	public void geraItensPreco(int array[]){
		for(int i=0;i<array.length;i++){
			Random gerador=new Random();
			array[i]=gerador.nextInt(11)+20;
		}
	}
	public void geraItensQuantidade(int array[]){
		for(int i=0;i<array.length;i++){
			Random gerador=new Random();
			array[i]=gerador.nextInt(11);
		}
	}
	public void geraPersonagemDinheiro(){
		Random gerador=new Random();
		this.personagemDinheiro=gerador.nextInt(41)+60;
	}
	public void entra(){
		System.out.println(personagemNome+"Seja bem vindo a "+lojaNome+"\nO que voc� deseja?");
		this.personagemDentro=true;
	}
	public void sai(){
		this.personagemDentro=false;
	}
	public void trabalha(){
		Random geradorValor=new Random();
		int valor=geradorValor.nextInt(11)+20;
		Random geradorHora=new Random();
		int hora=geradorHora.nextInt(10)+1;
		valor*=hora;
		this.personagemDinheiro+=valor;
		System.out.println("Parab�ns, voc� trabalhou "+hora+" horas e ganhou R$"+valor+",00.");
	}
	public void mostraItens(){
		System.out.println("Voc� tem R$"+this.personagemDinheiro+",00");
		for(int i=0;i<3;i++){
			System.out.println(i+1+" - "+lojaItensNome[i]+" por "+lojaItensPreco[i]+" cada.");
		}
		System.out.println("4 - Sair");
	}
	public void compra(int x){
		if(this.personagemDentro){
			if(x<=0||x>4){
				System.out.println("Volte quando voc� quiser fazer algo.");
			}else if(x==4){
				System.out.println("Volte sempre.");
				sai();
			}else{
				if(this.personagemDinheiro>=this.lojaItensPreco[x-1]){
					if(this.lojaItensQuantidade[x-1]>0){
						this.personagemDinheiro-=lojaItensPreco[x-1];
						this.lojaItensQuantidade[x-1]--;
					}else{
						System.out.println("Lamento, n�o temos mais o item");
					}
				}else{
					System.out.println("N�O VENDEMOS FIADO!");
					sai();
				}
			}
		}else{
			System.out.println("Voc� precisa estar dentro da loja para comprar algo.");
		}
	}
}
