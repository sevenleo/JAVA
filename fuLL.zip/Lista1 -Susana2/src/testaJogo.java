import java.util.Scanner;
public class testaJogo {
	public static void main(String[] args) {
		Jogo jogo=new Jogo();
		
		//cria personagem
		System.out.println("Escolha um nome para seu personagem.");
		Scanner scNome= new Scanner(System.in);
		jogo.personagemNome = scNome.nextLine();
		jogo.geraPersonagemDinheiro();
		
		//cria loja
		jogo.geraItensNome(jogo.lojaItensNome);
		jogo.geraItensPreco(jogo.lojaItensPreco);
		jogo.geraItensQuantidade(jogo.lojaItensQuantidade);
	
		while(true)
		{
			while(!jogo.personagemDentro){
				System.out.println("O que voc� vai fazer?\n1 - Entrar na loja\n2 - Trabalhar");
				Scanner sc=new Scanner(System.in);
				int opcao=sc.nextInt();
				switch(opcao){
					case 1:{
						jogo.entra();
						break;
					}
					case 2:{
						jogo.trabalha();
						break;
					}
					default:{
						System.out.println("Escolha uma op��o v�lida");
						break;
					}
				}
			}
			while(jogo.personagemDentro){
				jogo.mostraItens();
				Scanner sc=new Scanner(System.in);
				int opcao =sc.nextInt();
				jogo.compra(opcao);
			}
		}
	}
}
