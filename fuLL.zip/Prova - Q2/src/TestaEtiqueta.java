import java.util.ArrayList;


public class TestaEtiqueta {

	public static void main(String[] args) {
		ArrayList<Pessoa> pessoas = new ArrayList<Pessoa>();
		pessoas.add(new Aluno("Fulano",1048171142,true,"Rua Whatever"));
		pessoas.add(new Aluno("Fulana",1327174122,false,"Rua 15"));
		pessoas.add(new Professor("Carmona","Instituto de Matem�tica",false,"Avenida Nowhere"));
		pessoas.add(new Professor("Colier","Departamento de Ci�ncia da Computa��o",true,"Sede da NASA"));
		for(Pessoa pessoa : pessoas){
			System.out.println(pessoa.geraEtiquetaCorreio()+"\n");
		}
	}

}
