public class Professor extends Pessoa{
private String departamento;

Professor(String nome, String departamento, boolean sexo, String endereco){
	super(nome, endereco, sexo);
	setDepartamento(departamento);
}

public String getDepartamento() {
	return departamento;
}

public void setDepartamento(String departamento) {
	this.departamento = departamento;
}
	
public String getPrefixo(){
	String prefixo;
	if(this.getSexo() == true){
		prefixo = "Prof.";
	} else {
		prefixo = "Profa.";
	}
	return prefixo;
}

public String getSufixo(){
	return "("+this.getDepartamento()+")";
}
}
