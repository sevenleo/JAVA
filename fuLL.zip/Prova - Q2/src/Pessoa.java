public abstract class Pessoa {
	private String nome;
	private String endereco;
	private boolean sexo; //true = m; false = f
	
	Pessoa(String nome, String endereco, boolean sexo){
		setNome(nome);
		setEndereco(endereco);
		setSexo(sexo);
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public boolean getSexo() {
		return sexo;
	}
	public void setSexo(boolean sexo) {
		this.sexo = sexo;
	}
	public abstract String getPrefixo();
	
	public abstract String getSufixo();
	
	public String geraEtiquetaCorreio(){
		String etiqueta = this.getPrefixo()+" "+this.getNome()+" "+this.getSufixo()+"\n"+this.getEndereco();
		return etiqueta;
	}
}

