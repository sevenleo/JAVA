public class Aluno extends Pessoa {
	private long dre;
	
	public long getDre() {
		return dre;
	}

	public void setDre(long dre2) {
		this.dre = dre2;
	}
	
	Aluno(String nome, long dre, boolean sexo, String endereco){
		super(nome, endereco, sexo);
		setDre(dre);
	}
	
	public String getPrefixo(){
		String prefixo;
		if(this.getSexo() == true){
			prefixo = "Aluno";
		} else {
			prefixo = "Aluna";
		}
		return prefixo;
	}
	
	public String getSufixo(){
		return "("+this.getDre()+")";
	}
	

}
