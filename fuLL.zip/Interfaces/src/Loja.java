

import java.util.ArrayList;

public class Loja extends Local{
	private NPC espadas = new NPC("Espadas","Espadas de todos os tipos e tamanhos est�o presas nas paredes",null);
	private NPC atendente = new NPC("Atendente","Um homem j� com certa idade tentando vender algumas de suas armas...","Ol� jovem guerreiro,  que deseja?");
	private NPC rapaz = new NPC("Guerreiro","Um jovem rapaz...Parece ser um guerreiro","Essa loja possui itens muito bons! Vale a pena comprar aqui.");
	private NPC escudos = new NPC("Escudos","Escudos de todos os tipos e tamanhos est�o presos nas paredes","Voc� tentou pegar um escudo mas o atendente lhe repreendeu.");
	private ArrayList<Item> estoque = new ArrayList<Item>();
		
	//construtor
	public Loja(){
		this.nome="Loja de Armas";
		this.responsavel=atendente;
		this.descricao="Loja de armas." +
			"Voc� entrou em uma loja armeira... " +
			"H� {espadas} e [escudos] nas paredes, " +
			"um [atendente] no balc�o e " +
			"um [rapaz] parado ao canto";
		this.coisas.add(espadas);
		this.coisas.add(escudos);
		this.coisas.add(rapaz);
		
		Item descartavel=new Item("",0,0);
		this.estoque=descartavel.geraArrayArmas();
	}

	//get&set
	public ArrayList<Item> getEstoque(){
		return this.estoque;
	} 
	//metodos
	public boolean venderItem(Item a){
		Item vendidoLoja = null;
		for(Item descartavel : this.estoque){
			if(descartavel.getNome().equals(a.getNome())){
				vendidoLoja=descartavel;
				break;
			}
		}
		if(vendidoLoja==null){
			return false;
		}else if(vendidoLoja.diminuiQuantidade()){
			return true;
		}else{
			return false;
		}
		
	}
	public boolean comprarItem(Item a){
		Item vendidoLoja = null;
		for(Item descartavel : this.estoque){
			if(descartavel.getNome().equals(a.getNome())){
				vendidoLoja=descartavel;
				break;
			}
		}
		if(vendidoLoja==null){
			return false;
		}else {
			vendidoLoja.aumentaQuantidade();
			return true;
		}
	}
}

