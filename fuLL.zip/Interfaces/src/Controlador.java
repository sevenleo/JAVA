

import javax.swing.JTextArea;


public class Controlador {
	public static void main(String[] args){
		GUI gui = new GUI();
	
		gui.jogo();
	}
	
		
	private Hero heroi;
	
	
	
	public Controlador(){
		heroi = new Hero();
	}
	public void setarNomeJogador(String nome){
		heroi.setNome(nome);
	}
	public Hero getHeroi(){
		return heroi;
	}
	
}
