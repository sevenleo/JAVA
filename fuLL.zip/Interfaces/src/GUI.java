import java.awt.event.*;
import java.util.*;
import java.awt.*;
import javax.swing.*;



public class GUI {
	
	private JTextArea area = new JTextArea(10,30);
	private JTextField field = new JTextField(20);
    private JButton button1;
    private JButton button2;
    private JButton button3;
    private JButton button4;
    private Controlador controlador;
    
	public void saida(String saida){
		area.append(saida);
	}
	
	public String entrada(){
		String x = field.getText();
		return x;
	}
	public JTextArea getSheet(){
		return area;
	}
	
	public JTextField getField(){
		return field;
	}

	public void jogo(){
		controlador = new Controlador();
		JFrame frame = new JFrame();
		JPanel panel = new JPanel();
		JPanel panel2 = new JPanel();
		JPanel panel3 = new JPanel();
		area = new JTextArea(10,30);
		field = new JTextField(20);
		JButton button1 = new JButton("Interagir");
		JButton button2 = new JButton("Olhar");
		JButton button3 = new JButton("Ir");
		JButton button4 = new JButton("Focus");
		
		area.setEditable(false);
		panel.add(area);
		frame.getContentPane().add(BorderLayout.NORTH, panel);

		button1.addActionListener(new CapturaListener());
		
		panel2.add(button1);
		panel2.add(button2);
		panel2.add(button3);
		panel2.add(button4);
		panel2.add(field);
		frame.getContentPane().add(BorderLayout.CENTER, panel2);
		frame.setSize(400,400);
		frame.setVisible(true);
		
		this.saida("Qual o seu nome?\n");
		
		this.saida("nome :"+controlador.getHeroi().getNome()+" ...\n\n");

	}
	
	public class CapturaListener implements ActionListener{
			
		public void actionPerformed(ActionEvent ev){
				controlador.setarNomeJogador(field.getText());
				GUI.this.saida("Nome = " +controlador.getHeroi().getNome());
				
		}
	}
}
