

import java.util.ArrayList;
import java.util.Random;
public class Hero implements Runnable{
	private String nome;
	private int dinheiro;
	private int quantidadeItens;
	private Boolean dia;
	Local lugar;
	ArrayList<Item> inventario = new ArrayList<Item>();
	
	//construtor
	public Hero(){
		this.setDinheiro(5000);
		this.setDia(true);
	}
	//get & set
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getDinheiro() {
		return dinheiro;
	}
	public void setDinheiro(int dinheiro) {
		this.dinheiro = dinheiro;
	}
	public int getQuantidadeItens() {
		return quantidadeItens;
	}
	public void setQuantidadeItens(int quantidadeItens) {
		this.quantidadeItens = quantidadeItens;
	}
	private void setDia(Boolean bol){
		this.dia=bol;
	}

/*Metodos da Thread*/
	private Boolean getDia(){
		return this.dia;
	}
	
	private String noite(){
		this.setDia(false);
		return "Ta de noite, v� dormir";
	}
	public void run(){
		if(this.getDia()){
			this.noite();
		}
	}
/*Fim da Thread*/

	//metodos
	public void dorme(){
		this.setDia(true);
	}
	public boolean verificaDinheiro(double x){
		if(this.getDinheiro()<x){
			return false;
		}
		return true;
		
	}
	public boolean diminuiDinheiro(double x){
		if(this.getDinheiro()<x){
			this.dinheiro-=x;
			return true;
		}
		return false;
	}
	private void aumentaDinheiro(double x){
		this.dinheiro+=x;
	}
	public String trabalha(){
		if(this.getDia()){
			Random gerador = new Random();
			int trabalho=gerador.nextInt(8)+1;
			double valor=trabalho*12.3;
			this.aumentaDinheiro(valor);
			return "Voc� trabalhou "+trabalho+"h e ganhou "+valor;
		}
		return "Voc� n�o pode trabalhar de noite";
	}
	public boolean vendeItem(Item a){
		Item vendido = null;
		for(Item descartavel : this.inventario){
			if(descartavel.getNome().equals(a.getNome())){
				vendido=descartavel;
				break;
			}
		}
		if(vendido==null){
			return false;
		}else if(vendido.diminuiQuantidade()){
			this.aumentaDinheiro(vendido.getPrecoUsado());
			return true;
		}else{
			return false;
		}
		
	}
	public boolean compraItem(Item a){
		Item comprado = null;
		for(Item descartavel : this.inventario){
			if(descartavel.getNome().equals(a.getNome())){
				comprado=descartavel;
				break;
			}
		}
		if(comprado==null){
			return false;
		}else {
			comprado.aumentaQuantidade();
			this.diminuiDinheiro(comprado.getPrecoNovo());
			return true;
		}
	}
	public boolean depositaItem(Item a){
		Item depositado = null;
		for(Item descartavel : this.inventario){
			if(descartavel.getNome().equals(a.getNome())){
				depositado=descartavel;
				break;
			}
		}
		if(depositado==null){
			return false;
		}else if(depositado.diminuiQuantidade()){
			return true;
		}else{
			return false;
		}
		
	}
	public boolean pegaItem(Item a){
		Item pego = null;
		for(Item descartavel : this.inventario){
			if(descartavel.getNome().equals(a.getNome())){
				pego=descartavel;
				break;
			}
		}
		if(pego==null){
			return false;
		}else {
			pego.aumentaQuantidade();
			return true;
		}
	}

}