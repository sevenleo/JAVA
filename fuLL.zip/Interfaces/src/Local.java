
import java.util.ArrayList;



public abstract class Local {
	protected ArrayList<NPC> coisas = new ArrayList<NPC>();
	protected String descricao;
	protected String nome;
	protected NPC responsavel;
	
	public String getNome() {
		return this.nome;
	}
	public ArrayList<NPC> getCoisas() {
		return this.coisas;
	}
	public String getDescricao() {
		return this.descricao;
	}
}
