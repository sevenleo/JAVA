import java.awt.event.*;

public class EscreverUsuario implements ActionListener{
	
	@Override
	public void actionPerformed(ActionEvent ev){
		String temp;
		
		
	}

}
