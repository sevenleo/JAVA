
public abstract class Item {
	//Vari�veis
	private String name;
	private String description;
	private int price;
	private int qntloja;
	private int qnthero;
	
	//Sets & Gets
	public String getName() {return name;}
	public void setName(String name) {this.name = name;}
	public int getPrice() {return price;}
	public void setPrice(int price) {this.price = price;}
	public int getQntloja() {return qntloja;}
	public void setQntloja(int qntloja) {this.qntloja = qntloja;}
	public int getQnthero() {return qnthero;}
	public void setQnthero(int qnthero) {this.qnthero = qnthero;}
	public String getDescription() {return description;}
	public void setDescription(String description) {this.description = description;}
	
	//Outros M�todos
	
}