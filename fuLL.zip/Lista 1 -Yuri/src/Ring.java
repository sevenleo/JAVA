
public class Ring extends Item {
	//Construtor
	public Ring(String name, String description, int price, int qntloja){
		setName(name);
		setDescription(description);

		setPrice(price);
		setQntloja(qntloja);
		setQnthero(0);	
	}
}