
public class Hero {
	//Vari�veis
	private String name;
	private double money;
	private String place;

	//Gets & Sets
	public String getName() {return name;}
	public void setName(String name) {this.name = name;}
	public double getMoney() {return money;}
	public void setMoney(double money) {this.money = money;}
	public String getPlace() {return place;}
	public void setPlace(String place) {this.place = place;}
	
	//Outros M�todos
	public void showStats(Item[] item){
		System.out.println("Nome: " + name);
		System.out.println("Dinheiro: " + money);
		System.out.println("Voc� est� em: " + place);
		System.out.println("Meu invent�rio:");
		this.showInventory(item);
	}

	public void showInventory(Item[] item){
		for(int i=0; i<item.length; ++i){
			if(item[i].getQnthero()>0){
				System.out.println(item[i].getQnthero() + "x " + item[i].getName() + " - " + item[i].getDescription());
			}
		}
	}

	public void buy(Item[] item, Input input){
		System.out.println("Vendedor: 'Bem Vindo, "+ this.getName() + "! O que gostaria de comprar?'");
		while(!input.getEntrada().equals("Sair")){
			System.out.println("\nSeu dinheiro: " + this.getMoney() + "GP\n");
			for(int i=0; i<item.length; ++i){
				if(item[i].getQntloja()>0){
					System.out.println(item[i].getQntloja() + "x " + item[i].getName() + " - "+ item[i].getPrice() +"GP");
					System.out.println(item[i].getDescription() + "\n");
		}
			}
			System.out.println("--------------------");
			System.out.println("Meu invent�rio:");
			for(int i=0; i<item.length; ++i){
				if(item[i].getQnthero()>0){
					System.out.println(item[i].getQnthero() + "x " + item[i].getName() + " - " + item[i].getDescription());
				}
			}
			System.out.println("--------------------");
			input.getInput("Comprar qual item?\n");
			for(int i=0; i<item.length; ++i){
				if(item[i].getName().equals(input.getEntrada())){
					if(item[i].getQntloja()>0){
						input.getInput("Comprar quantos?");
						while(input.getEntrada().length()==0)input.getInput("Comprar quantos?");
						if(this.getMoney()>=item[i].getPrice()*Integer.parseInt(input.getEntrada())){
							if(item[i].getQntloja()>=Integer.parseInt(input.getEntrada())){
								System.out.println("Comprado " + Integer.parseInt(input.getEntrada()) + "x " + item[i].getName() + " por " + item[i].getPrice()*Integer.parseInt(input.getEntrada()) + "GP!");
								this.setMoney(this.getMoney()-item[i].getPrice()*Double.parseDouble(input.getEntrada()));
								item[i].setQnthero(item[i].getQnthero()+Integer.parseInt(input.getEntrada()));
								item[i].setQntloja(item[i].getQntloja()-Integer.parseInt(input.getEntrada()));
							}
							else{
								System.out.println("Desculpe, eu n�o possuo tantos itens assim...");
							}
						}
						else{
							System.out.println("Desculpe, voc� n�o tem dinheiro suficiente para isso...");
						}
					}
					else{
						System.out.println("Desculpe, n�o possuo esse item...");
					}
				}
			}
		}
	}
	
	public void sell(Item[] item, Input input){
		System.out.println("Vendedor: 'Bem Vindo, "+ this.getName() + "! O que gostaria de vender? Compro seus itens por 1/3 do pre�o nominal.'");
		while(!input.getEntrada().equals("Sair")){
			System.out.println("\nSeu dinheiro: " + this.getMoney() + "GP");
			System.out.println("Meu invent�rio:");
			for(int i=0; i<item.length; ++i){
				if(item[i].getQnthero()>0){
					System.out.println(item[i].getQnthero() + "x " + item[i].getName() + " por " +item[i].getPrice()/3 + "GP cada. " + item[i].getDescription());
				}
			}
			System.out.println("--------------------");
			input.getInput("vender qual item?\n");
			for(int i=0; i<item.length; ++i){
				if(item[i].getName().equals(input.getEntrada())){
					input.getInput("Vender quantos?");
					while(input.getEntrada().length()==0)input.getInput("Vender quantos?");
					if(item[i].getQnthero()>=Integer.parseInt(input.getEntrada())){
						System.out.println("Vendido " + Integer.parseInt(input.getEntrada()) + "x " + item[i].getName() + " por " + (item[i].getPrice()/3)*Integer.parseInt(input.getEntrada()) + "GP!");
						this.setMoney(this.getMoney()+(item[i].getPrice()/3)*Integer.parseInt(input.getEntrada()));
						item[i].setQnthero(item[i].getQnthero()-Integer.parseInt(input.getEntrada()));
						item[i].setQntloja(item[i].getQntloja()+Integer.parseInt(input.getEntrada()));
					}
					else{
						System.out.println("Voc� n�o possui tantos itens assim");
					}
				}
			}
		}
	}

	
	//Construtor
	public Hero(){
		setPlace("Rua");
		setMoney(10000);
	}
	
}