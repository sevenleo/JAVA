
public class Main {
	public static void main(String[] args) {
		Input input = new Input();
		Hero p1= new Hero();
		
		//Lista de itens existentes
		Item item[] = new Item[12];
		item[0] = new Potion("Barrow Bree","Eu n�o comeria esse queijo podre se fosse voc�...", 0, 100);
		item[1] = new Potion("Po��o Pequena","Recupera uma quantidade pequena de HP.", 10, 10);
		item[2] = new Potion("Po��o M�dia","Recupera uma quantidade razo�vel de HP.",  20, 7);
		item[3] = new Potion("Po��o Grande","Recupera uma grande quantidade de HP.",  30, 5);
		item[4] = new Shield("Escudo", "Escudo simples.", 100, 2);
		item[5] = new Armor("Armadura", "Armadura pouco resistente.", 120, 1);
		item[6] = new Weapon("Espada Velha", "Espada fraca.",100, 2);
		item[7] = new Weapon("Espada Pesada", "Espada dif�cil de ser empunhada.", 130, 1);
		item[8] = new Ring("Anel Antigo", "Anel achado em antigas ru�nas.", 80, 2);
		item[9] = new Ring("Anel M�gico", "Anel criado por feiticeiros.", 90, 1);
		item[10] = new Ring("Anel De Fogo", "Anel criado das chamas de um vulc�o.", 100, 2);
		item[11] = new Ring("Anel De Mithril", "Anel feito de Mithril, o material mais raro que existe.", 9999999, 1);
		
		//Entrada do nome do personagem
		p1.setName(input.getInput("Qual o seu nome?\n"));
		if(p1.getName()==null){
			p1.setName("Yuri");
		}
		p1.showStats(item);
		
		//Main loop
		do {
			input.hints(p1);
			input.getInput("Qual o seu comando?");
			input.act(p1, item);

		
		}while(!input.getEntrada().equals("Quit"));//End of loop
		System.out.println("FIM DO JOGO");
	}//End of main

}//End of class