
public class Potion extends Item {
	//Construtor
	public Potion(String name, String description, int price, int qntloja){
		setName(name);
		setDescription(description);

		setPrice(price);
		setQntloja(qntloja);
		setQnthero(0);	
	}
}