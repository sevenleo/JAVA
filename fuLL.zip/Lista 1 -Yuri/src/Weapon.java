
public class Weapon extends Item {
	//Construtor
	public Weapon(String name, String description, int price, int qntloja){
		setName(name);
		setDescription(description);
		setPrice(price);
		setQntloja(qntloja);
		setQnthero(0);	
	}
}