
public class Item {
	//Vari�veis
	private String name;
	private int price;
	private int qntloja;
	private int qnthero;
	
	//Sets & Gets
	public String getName() {return name;}
	public void setName(String name) {this.name = name;}
	public int getPrice() {return price;}
	public void setPrice(int price) {this.price = price;}
	public int getQntloja() {return qntloja;}
	public void setQntloja(int qntloja) {this.qntloja = qntloja;}
	public int getQnthero() {return qnthero;}
	public void setQnthero(int qnthero) {this.qnthero = qnthero;}
	
	//Outros M�todos
	
	//Construtor
	public Item(String name, int price, int qntloja){
		setName(name);
		setPrice(price);
		setQntloja(qntloja);
		setQnthero(0);	
	}
}