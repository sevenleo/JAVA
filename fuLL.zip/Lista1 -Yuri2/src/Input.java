import java.io.*;

public class Input {
	//Vari�veis
	private String entrada;
	
	//Gets & Sets
	public String getEntrada(){return entrada;}
	public void setEntrada(String entrada){this.entrada=entrada;}
	
	//Outros M�todos
	public void act(Hero p1, Item[] item){
		if(getEntrada().equals("Personagem")){
			p1.showStats(item);
		}
		else if(getEntrada().equals("Entrar na loja") && p1.getPlace() == "Rua"){
			p1.setPlace("Loja");
			System.out.println("Voc� entrou na loja.");
			this.getInput("Deseja 'Comprar' ou 'Vender' seus itens?");
			if(getEntrada().equals("Comprar")){
				p1.buy(item, this);
			}
			if(getEntrada().equals("Vender")){
				p1.sell(item, this);
			}

		}
		else if(getEntrada().equals("Sair da loja") && p1.getPlace() == "Loja"){
			p1.setPlace("Rua");
			System.out.println("Voc� saiu da loja.");
		}
		else if(getEntrada().equals("Mudar dinheiro")){
			getInput("Quanto dinheiro voc� deseja adicionar/subtrair?");
			p1.setMoney(p1.getMoney()+Integer.parseInt(getEntrada()));
			System.out.println("Voc� alterou seu dinheiro em " + getEntrada());
			System.out.println("Voc� possui " + p1.getMoney() + " Penya");
		}
	}
	
	public void hints(Hero p1){
		System.out.println("---------------------");
		System.out.println("Comandos dispon�veis:");
		System.out.println("Personagem");
		System.out.println("Mudar dinheiro");
		System.out.println("Quit");
		
		if(p1.getPlace() == "Rua"){
			System.out.println("Entrar na loja");
		}
		System.out.println("---------------------");
	}//End of hints()
	
	
	//Construtor
	public String getInput(String prompt){
		String inputLine = null;
		System.out.print(prompt + "  ");
		try{
			BufferedReader is = new BufferedReader(new InputStreamReader(System.in));
			inputLine = is.readLine();
			if(inputLine.length()==0) return null;
		} catch (IOException e){
			System.out.println("IOException: " + e);
		}
		setEntrada(inputLine);
		return inputLine;
	}
}