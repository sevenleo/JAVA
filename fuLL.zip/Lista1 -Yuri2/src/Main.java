
public class Main {
	public static void main(String[] args) {
		Input input = new Input();
		Hero p1= new Hero();
		
		//Lista de itens existentes
		Item item[] = new Item[6];
		item[0] = new Item("Po��o Pequena", 10, 10);
		item[1] = new Item("Po��o M�dia", 20, 7);
		item[2] = new Item("Escudo", 100, 2);
		item[3] = new Item("Armadura", 120, 1);
		item[4] = new Item("Espada Velha", 100, 2);
		item[5] = new Item("Anel Antigo", 80, 2);
		
		//Entrada do nome do personagem
		p1.setName(input.getInput("Qual o seu nome?\n"));
		if(p1.getName()==null){
			p1.setName("Yuri");
		}
		p1.showStats(item);
		
		//Main loop
		do {
			input.hints(p1);
			input.getInput("Qual o seu comando?");
			input.act(p1, item);

		
		}while(!input.getEntrada().equals("Quit"));//End of loop
		System.out.println("FIM DO JOGO");
	}//End of main

}//End of class