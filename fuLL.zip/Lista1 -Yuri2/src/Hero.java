
public class Hero {
	//Vari�veis
	private String name;
	private int money;
	private String place;

	//Gets & Sets
	public String getName() {return name;}
	public void setName(String name) {this.name = name;}
	public int getMoney() {return money;}
	public void setMoney(int money) {this.money = money;}
	public String getPlace() {return place;}
	public void setPlace(String place) {this.place = place;}
	
	//Outros M�todos
	public void showStats(Item[] item){
		System.out.println("Nome: " + name);
		System.out.println("Dinheiro: " + money + " Penya");
		System.out.println("Voc� est� em: " + place);
		System.out.println("Meu invent�rio:");
		this.showInventory(item);
	}

	public void showInventory(Item[] item){
		for(int i=0; i<item.length; ++i){
			if(item[i].getQnthero()>0){
				System.out.println(item[i].getQnthero() + "x " + item[i].getName());
			}
		}
	}

	public void buy(Item[] item, Input input){
		System.out.println("Vendedor: 'Bem Vindo, "+ this.getName() + "! O que gostaria de comprar?'");
		while(!input.getEntrada().equals("Sair")){
			System.out.println("\nSeu dinheiro: " + this.getMoney() + " Penya");
			for(int i=0; i<item.length; ++i){
				if(item[i].getQntloja()>0){
					System.out.println(item[i].getQntloja() + "x " + item[i].getName() + " - "+ item[i].getPrice() +" Penya");
				}
			}
			System.out.println("Sair");
			System.out.println("--------------------");
			System.out.println("Meu invent�rio:");
			for(int i=0; i<item.length; ++i){
				if(item[i].getQnthero()>0){
					System.out.println(item[i].getQnthero() + "x " + item[i].getName());
				}
			}
			System.out.println("--------------------");
			input.getInput("Comprar qual item?\n");
			for(int i=0; i<item.length; ++i){
				if(item[i].getName().equals(input.getEntrada())){
					if(item[i].getQntloja()>0){
						if(this.getMoney()>=item[i].getPrice()){
							if(item[i].getQntloja()>0){
								this.setMoney(this.getMoney()-item[i].getPrice());
								item[i].setQnthero(item[i].getQnthero()+1);
								item[i].setQntloja(item[i].getQntloja()-1);
							}
							else{
								System.out.println("Desculpe, eu n�o possuo tantos itens assim...");
							}
						}
						else{
							System.out.println("Desculpe, voc� n�o tem dinheiro suficiente para isso...");
						}
					}
					else{
						System.out.println("Desculpe, n�o possuo esse item...");
					}
				}
			}
		}
		this.setPlace("Rua");
	}
	
	public void sell(Item[] item, Input input){
		System.out.println("Vendedor: 'Bem Vindo, "+ this.getName() + "! O que gostaria de vender? Compro seus itens por 1/3 do pre�o nominal.'");
		while(!input.getEntrada().equals("Sair")){
			System.out.println("\nSeu dinheiro: " + this.getMoney() + "GP");
			System.out.println("Meu invent�rio:");
			for(int i=0; i<item.length; ++i){
				if(item[i].getQnthero()>0){
					System.out.println(item[i].getQnthero() + "x " + item[i].getName() + " por " +item[i].getPrice()/3 + "GP cada");
				}
			}
			System.out.println("--------------------");
			input.getInput("vender qual item?\n");
			for(int i=0; i<item.length; ++i){
				if(item[i].getName().equals(input.getEntrada())){
					if(item[i].getQnthero()>0){
						this.setMoney(this.getMoney()+(item[i].getPrice()/3));
						item[i].setQnthero(item[i].getQnthero()-1);
						item[i].setQntloja(item[i].getQntloja()+1);
					}
					else{
						System.out.println("Voc� n�o possui tantos itens assim");
					}
				}
			}
		}
		this.setPlace("Rua");
	}

	
	//Construtor
	public Hero(){
		setPlace("Rua");
		setMoney(10000);
	}
	
}