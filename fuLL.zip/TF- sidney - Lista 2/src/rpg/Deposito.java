package rpg;

import java.util.Scanner;

public class Deposito {
	
	public void depositar(Item [] item, Hero y){
		System.out.println("� um deposito de itens.... Um lugar muito bom para voce deixar suas coisas se estiver carregando muito peso.H� um [atendente] atr�s da bancada com um grande {martelo} no cord�o em seu pesco�o. Falando com ele h� um [homem]");
		Scanner scan = new Scanner (System.in);
		String texto = scan.nextLine();
		if(texto.equalsIgnoreCase("listar")){
			System.out.println("Pra�a");
		}
		if(texto.equalsIgnoreCase("ir pra�a")){
			y.setLugar("Pra�a");
		}
		if(texto.equalsIgnoreCase("olhar atendente")){
			System.out.println("Esse atendente n�o parece ser daqui.");
		}
		else if(texto.equalsIgnoreCase("olhar martelo")){
			System.out.println("Um simbolo de religi�o pag�! Deve ser descendente de Vikings...");
		}
		else if(texto.equalsIgnoreCase("olhar homem")){
			System.out.println("Deve ser algum mercador negociando mais produtos...");
		}
		else if(texto.equalsIgnoreCase("interagir homem")){
			System.out.println("A seguran�a daqui � confiavel, pode guardar seus pertences sem remorso!");
		}
		else if(texto.equalsIgnoreCase("interagir atendente")){
			System.out.println("Ol�! O que deseja?  1-Depositar   2-Retirar");
			while(!scan.nextLine().equals("sair")){
				texto = scan.nextLine();
				if(scan.nextLine().equalsIgnoreCase("depositar")){
					System.out.println("Qual item deseja depositar?");
					for(int i = 0; i < item.length; i++ ){
						if(item[i].getQuantidadeHero()>0){
							System.out.println(item[i].getQuantidadeHero() + "x " + item[i].getNome());
						}
					}
					texto = scan.nextLine();
					for(int i = 0; i < item.length; i++ ){
						if(item[i].getNome().equalsIgnoreCase(texto)){
							if(item[i].getQuantidadeHero() == 0){
								System.out.println("Desculpe,voc� n�o possui esse item");	
							}
							
							else{
								item[i].setQuantidadeDeposito(item[i].getQuantidadeDeposito() + 1);
								item[i].setQuantidadeHero(item[i].getQuantidadeHero() - 1 );
								System.out.println("Muito obrigado! Deseja mais alguma coisa?");
							}
						}
					}
				}
				else if(scan.nextLine().equalsIgnoreCase("retirar")){
					System.out.println("O que deseja retirar?");
					texto = scan.nextLine();
					for(Item a : item){
						if(a.getNome().equalsIgnoreCase(texto)){
							if(a.getQuantidadeDeposito() == 0){
								System.out.println("Parece que voc� n�o possui nada no deposito");
							}
							else{
								a.setQuantidadeHero(a.getQuantidadeHero() + 1);
								a.setQuantidadeDeposito(a.getQuantidadeDeposito()-1);
							}
						}
					}
					
				}
			}
		}
		
	}

}
