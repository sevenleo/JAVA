package rpg;
import java.util.Scanner;

public class Taverna {
	public void dormir(Hero y){
		System.out.println("Voc� esta em uma taverna...O lugar esta cheio e h� um [atendente] no balc�o, uma {mulher} sentada em uma mesa pr�xima e uma [caneca de hidromel] em cima de uma mesa sem ninguem.... ");
		Scanner scan = new Scanner (System.in);
		String texto = scan.nextLine();
		if(texto.equalsIgnoreCase("listar")){
			System.out.println("Pra�a");
		}
		if(texto.equalsIgnoreCase("ir pra�a")){
			y.setLugar("Pra�a");
		}
		if(texto.equalsIgnoreCase("olhar atendente")){
			System.out.println("Um homem incirvelmente grande e com uma cicatriz no rosto.... Parece que esta trabalahdno muito hoje");
		}
		
		else if(texto.equalsIgnoreCase("olhar mulher")){
			System.out.println("Uma belissima mulher e parece estar sozinha....");
		}
		
		else if(texto.equalsIgnoreCase("olhar caneca de hidromel")){
			System.out.println("Parece que essa caneca esta me esperando....");
		}
		
		else if(texto.equalsIgnoreCase("interagir caneca de hidromel")){
			System.out.println("Hmm... Ta ali dando sopa e eu estou com sede...");
			System.out.println("---------------");
			System.out.println("Voce bebeu o hidromel, estava gelado e muito gostoso");
			texto = scan.nextLine();
			if(texto.equalsIgnoreCase("sim")){
				System.out.println("Voc� jogou gam�o com o velho e perdeu feio!");
			}
			else if(texto.equalsIgnoreCase("n�o")){
				System.out.println("Ok ent�o.... ");
			}
		}
		
		else if(texto.equalsIgnoreCase("interagir atendente")){
			System.out.println("Hahaha!Ol� l� viajante!Bem vindo ao Cr�nio Furado, o que vc deseja? 1-Quarto");
			texto = scan.nextLine();
			if(texto.equalsIgnoreCase("quarto")){
				System.out.println("Voc� parece realmente cansado.... O quarto custa 45 Zentys a di�ria, voce quer um?");
				texto = scan.nextLine();
				if(texto.equalsIgnoreCase("sim")){
					y.setDinheiro(y.getDinheiro() - 45);
					System.out.println("Voce desca�ou bem e foi curado!");
				}
			}
		}
	}
}
