package rpg;

import java.util.Scanner;

public class Hospital {
	public void cura(Hero y){
		System.out.println("O hospital da cidade. H� uma [enfermeira] proxima a uma {maca} e uma [senhora] sentada em um banco ");
		Scanner scan = new Scanner (System.in);
		String texto = scan.nextLine();
		if(texto.equalsIgnoreCase("listar")){
			System.out.println("Pra�a");
		}
		if(texto.equalsIgnoreCase("ir pra�a")){
			y.setLugar("Pra�a");
		}
		if(texto.equalsIgnoreCase("olhar enfermeira")){
			System.out.println("Uma linda enfermeira parada ali...Mas n�o tenho tempo para paqueras agora");
			
		}
		else if(texto.equalsIgnoreCase("olhar senhora")){
			System.out.println("Uma senhora j� com certa idade... Deve estar esperando atendimento");
		}
		else if(texto.equalsIgnoreCase("olhar maca")){
			System.out.println("Uma maca em bom estado");
		}
		else if(texto.equalsIgnoreCase("interagir senhora")){
			System.out.println("Aqui h� medicos muito bons. Venho e aquela mocinha ali *aponta pra enfermeira* � um amor de pessoa!");
		}
		else if(texto.equalsIgnoreCase("interagir enfermeira")){
			System.out.println("Ol� meu querido, deseja reparar seus ferimentos?");
			texto = scan.nextLine();
			if(texto.equalsIgnoreCase("sim")){
				System.out.println("Voc� realmente precisa....Deite-se ali, eu cuido de voce.");
				System.out.println("------------");
				System.out.println("Voc� foi curado e esta revigorado!");
			}
		}
		
	}
}
