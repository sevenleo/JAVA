package rpg;
import java.util.Scanner;


public class Loja {
	
	public static void inserirItens(Item [] item){
		item[0] = new Item("Escudo",90,6);
		item[1] = new Item("Espada Bastarda",130,3);
		item[2] = new Item("Camis�o de cota de malha",115,4);
		item[3] = new Item("Full Plate",250,2);
	}
	
	
	public void vender(Item [] item, Hero y){
		System.out.println("Voc� entrou em uma loja armeira... H� {espadas} nas paredes, um [atendente] no balc�o e um [rapaz] parado ao canto");
		Scanner scan = new Scanner (System.in);
		String texto = scan.nextLine();
		if(texto.equalsIgnoreCase("listar")){
			System.out.println("Pra�a");
		}
		if(texto.equalsIgnoreCase("ir pra�a")){
			y.setLugar("Pra�a");
		}
		if(texto.equalsIgnoreCase("olhar espadas")){
			System.out.println("Espadas de todos os tipos e tamanhos est�o presas nas paredes");		
		}
		else if(texto.equalsIgnoreCase("olhar atendente")){
			System.out.println("Um homem j� com certa idade tentando vender algumas de suas armas...");
		}
		else if(texto.equalsIgnoreCase("olhar rapaz")){
			System.out.println("Um jovem rapaz...Parece ser um guerreiro");
		}
		else if(texto.equalsIgnoreCase("interagir rapaz")){
			System.out.println("Essa loja possui itens muito bons! Vale a pena comprar aqui.");
		}
		else if(texto.equalsIgnoreCase("interagir atendente")){
			System.out.println("Ol� jovem guerreiro,  que deseja?  1-Comprar   2-Vender");
			while(!scan.nextLine().equals("sair")){
				texto = scan.nextLine();
				if(scan.nextLine().equalsIgnoreCase("comprar")){
					System.out.println("Qual item deseja comprar?");
					for(int i = 0; i < item.length; i++ ){
						System.out.println(item[i].getQuantidade() + "x " + item[i].getNome() + " - "+ item[i].getPre�o() +" Zenty");
					}
					texto = scan.nextLine();
					for(int i = 0; i < item.length; i++ ){
						if(item[i].getNome().equalsIgnoreCase(texto)){
							y.compra(item[i]);
						}
					}
					
				}
				else if(scan.nextLine().equalsIgnoreCase("vender")){
					System.out.println("Hmm.... O que tem a oferecer?");
					texto = scan.nextLine();
					System.out.println("Pagarei a metade do pre�o que isso vale, voc� aceita?");
					String texto1 = scan.nextLine();
					if(texto1.equalsIgnoreCase("n�o")){
						System.out.println("Ok ent�o...");
					}
					else if(texto1.equalsIgnoreCase("sim")){
						for(Item a : item){
							if(a.getNome().equalsIgnoreCase(texto1)){
								if(a.getQuantidadeHero() == 0){
									System.out.println("Parece que voc� n�o tem esse item para vender...");
								}
								else{
									a.setQuantidadeHero(a.getQuantidadeHero() - 1);
									y.setDinheiro(a.getPre�o()/2 + y.getDinheiro());
								}
							}
						}
					}
				}
			}
		}
	}
}
