import java.util.*;
import java.io.*;

public class Main implements Serializable{

	   public static void main( String[] args ) throws IOException, ClassNotFoundException{
		   
				   System.out.println("---------------------- Entre com detalhes");
				   
				   detalhes d = new detalhes();
				   detalhes e = new detalhes();
				   saveload sl = new saveload();
				   
				   
				  
				   
				   
				   
				   sl.save(d);
				   System.out.println(d);
				   System.out.println(e);
				   
				   System.out.println("---------------------- digite");
				   new java.util.Scanner(System.in).next();
				   e=sl.load();
				  
				  
				  
				   
				   System.out.println("---------------------- digite");
				   new java.util.Scanner(System.in).next();
				   System.out.println(d);
				   System.out.println(e);
				   
				   
	   }

	    
	

	
	
}
















class detalhes implements Serializable{
	String a;
	float b;


	public void setA() {
		this.a = new java.util.Scanner(System.in).nextLine();
	}


	public void setB() {
		this.b = new java.util.Scanner(System.in).nextInt();
	}


	public detalhes(){
		System.out.println("get nome");
		this.setA();
		System.out.println("get num");
		this.setB();

	}
	@Override
	 public String toString( ){
		//String s=System.out.println("nome:"+a+ "\nnumero:"+b);
		return "nome:"+a+ "\nnumero:"+b;
	}
	

}






class saveload{
	
	public void save(detalhes d) {
		
		try{
			FileOutputStream fileGrava= new FileOutputStream("dados.dat");
			ObjectOutputStream obj = new ObjectOutputStream(fileGrava);
			
			obj.writeObject(d);
			obj.writeChars(d.a);
			//obj.flush();
			obj.close();
			//fileGrava.flush();
			fileGrava.close();
			System.out.println("Saved ...\n");
			}
			catch( FileNotFoundException e){
				System.out.println("erro no arquivo");
			}catch(IOException e){
				System.out.println("erro na transicao");
			}
		
		
			
	}		
			
	public detalhes load( ) throws IOException, ClassNotFoundException{
		FileInputStream file =new FileInputStream("dados.dat");
		ObjectInputStream obj =new ObjectInputStream(file);
		//System.out.println("Nome");
		//System.out.println((detalhes)obj.readObject());
		//System.out.println(obj.readChar());
		//obj.close();
		//file.close();
		System.out.println("Load ... \n");
		return (detalhes)obj.readObject();
	}
	

	
}