package Controlador;

/*
import vista.Menu;
import modelo.Jogo;

import java.awt.event.*;
import java.util.*;
import java.awt.*;
import javax.swing.*;

import vista.Menu;
import modelo.Jogo;
*/

public interface ControleRemoto {
	String Abertura = "Sejam bem-vindos pobres jogadores";
	
	
	Controlador controlador = new Controlador();
	 

	
	
	
	
}

