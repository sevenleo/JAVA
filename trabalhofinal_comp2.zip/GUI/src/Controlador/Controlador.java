package Controlador;


import java.awt.BorderLayout;
import java.awt.Component;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;


import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;


import vista.Menu;
import modelo.*;

public class Controlador implements ControleRemoto, Serializable{
	
	
	
	
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
/////////////////////  RODANDO O JOGO /////////////////////
	
	
	

	public static void main(String[] args) {
		controlador.inicio();

	}

	
	
	
	
	
	
	
	
	
	
/////////////////////   criando modelo e visao  /////////////////////
	
	
	
	private Jogo jogo;
	private Menu menu;


	public Controlador(){
		jogo= new Jogo();
		menu = new Menu();			
	}

	private Jogo getJogo() {
		return jogo;
	}


	private Menu getMenu() {
		return menu;
	}





	
	
	
	
	
	
	
	
	
	
	
	
/////////////////////  funcoes que conectam o M-V  /////////////////////

	
	public void inicio(){
		this.getMenu().mostrar();
	}
	

	public void Instrucoes(String onde,JTextArea ta){
		
		if (onde.equalsIgnoreCase("praca")) 
			onde = controlador.getJogo().getPraca().getDescricao();
		
		if (onde.equalsIgnoreCase("estalagem")) 
			onde = controlador.getJogo().getEstalagem().getDescricao();
		
		if (onde.equalsIgnoreCase("loja"))
			onde = controlador.getJogo().getLoja().getDescricao();
		
		if (onde.equalsIgnoreCase("deposito")) 
			onde = controlador.getJogo().getDeposito().getDescricao();
		
		if (onde.equalsIgnoreCase("hospital"))
			onde = controlador.getJogo().getHospital().getDescricao();
		
		if (onde.equalsIgnoreCase("casa"))
			onde = controlador.getJogo().getCasa().getDescricao();
		
		if (onde.equalsIgnoreCase("jogo"))
			onde =  this.getJogo().getSobre()+" \n" ;
		
		ta.setText(onde);
	
		
	}
	
	public ArrayList<NPC> PegarNpcs(String onde){
			ArrayList<NPC> lista = new  ArrayList<NPC>();
			 
			if (onde.equalsIgnoreCase("praca")) 
				for (NPC pessoa : controlador.getJogo().getPraca().getCoisas()) lista.add(pessoa);
			if (onde.equalsIgnoreCase("estalagem")) 
				for (NPC pessoa : controlador.getJogo().getEstalagem().getCoisas()) lista.add(pessoa);
			if (onde.equalsIgnoreCase("loja"))
				for (NPC pessoa : controlador.getJogo().getLoja().getCoisas()) lista.add(pessoa);
			if (onde.equalsIgnoreCase("deposito")) 
				for (NPC pessoa : controlador.getJogo().getDeposito().getCoisas()) lista.add(pessoa);
			if (onde.equalsIgnoreCase("hospital")) 
				for (NPC pessoa : controlador.getJogo().getHospital().getCoisas()) lista.add(pessoa);
			if (onde.equalsIgnoreCase("casa")) 
				for (NPC pessoa : controlador.getJogo().getCasa().getCoisas()) lista.add(pessoa);
				
			return lista;
	}
	
	public int DinheiroHeroi(int tanto){
		controlador.getJogo().getHeroi().setDinheiro( controlador.getJogo().getHeroi().getDinheiro() + tanto);
		return controlador.getJogo().getHeroi().getDinheiro();
		
	}
	
	public String NomeHeroi(String NovoNome){
		if (NovoNome!=null)	controlador.getJogo().getHeroi().setNome(NovoNome);
		
		return controlador.getJogo().getHeroi().getNome();
	}
	
	public String LugarHeroi(String Novo){
		if (Novo!=null)	controlador.getJogo().getHeroi().setLugar(Novo);
		
		return controlador.getJogo().getHeroi().getLugar();
	}
	
	public Lugar OndeEsta(){
		Lugar onde=null;
		
		if (this.LugarHeroi(null).equalsIgnoreCase("praca")) onde=controlador.getJogo().getPraca(); 
			
		if (this.LugarHeroi(null).equalsIgnoreCase("estalagem"))  onde=controlador.getJogo().getEstalagem();
		
		if (this.LugarHeroi(null).equalsIgnoreCase("loja"))  onde=controlador.getJogo().getLoja();
			
		if (this.LugarHeroi(null).equalsIgnoreCase("deposito")) onde=controlador.getJogo().getDeposito();
		
		if (this.LugarHeroi(null).equalsIgnoreCase("hospital")) onde=controlador.getJogo().getHospital();
		
		if (this.LugarHeroi(null).equalsIgnoreCase("casa")) onde=controlador.getJogo().getCasa();
	
		return onde;
	}

	public void MostraMochila(JComboBox cb){
		ArrayList<Item> lista = controlador.getJogo().getHeroi().getInventario();
		for(Item coisas : lista){
        	cb.addItem(coisas.getNome());
        }
        
	}
	
	public void ListarOpcoes(String onde,JComboBox cbOlhar,JComboBox cbInteragir){
		
		ArrayList<NPC> lista = this.PegarNpcs(onde);
			
		for (NPC p : lista){
			p.getNome();
			 cbOlhar.addItem(p.getNome());
			 if ( p.getInteracao() != null ) cbInteragir.addItem(p.getNome());
		}
        
	}
	
	public void olhar(String onde,JComboBox cb,JTextArea ta){
		
		ArrayList<NPC> lista = this.PegarNpcs(onde);
		
		String npc= (String)cb.getSelectedItem();
		
		for (NPC p : lista){
			p.getNome();
			if (p.getNome().equalsIgnoreCase(npc)) ta.setText(p.getDescricao());
		}
	}
	
	public void interagir(String onde,JComboBox cb,JTextArea ta){
		
		ArrayList<NPC> lista = this.PegarNpcs(onde);
		
		String npc= (String)cb.getSelectedItem();
		
		for (NPC p : lista){
			p.getNome();
			if (p.getNome().equalsIgnoreCase(npc)) ta.setText(p.getInteracao());
		}
		
		
	}

	public void Mostradeposito(String onde,JComboBox cb){
		ArrayList<Item> lista=null;
		if (onde.equalsIgnoreCase("loja")) lista = controlador.getJogo().getLoja().getEstoque();
		if (onde.equalsIgnoreCase("deposito")) lista = controlador.getJogo().getDeposito().getEstoque();
		
		for(Item coisas : lista){
        	cb.addItem(coisas.getNome());
		}

	}

	
	public void habilitabotao(JComboBox cb, JButton bt1,JButton bt2){
		if (cb==null){
			bt1.setVisible(false);
			bt2.setVisible(false);
		}
		else if( cb.getSelectedItem().toString().equalsIgnoreCase(this.OndeEsta().getResponsavel().getNome()) ){
			bt1.setVisible(true);
			bt2.setVisible(true);
		}else{
			bt1.setVisible(false);
			bt2.setVisible(false);
		}

		
	}
	
	public void habilitacaixa(JComboBox cb, JComboBox  cb1,JComboBox cb2){
		if (cb==null){
			cb1.setVisible(false);
			cb2.setVisible(false);
		}
		else if( cb.getSelectedItem().toString().equalsIgnoreCase(this.OndeEsta().getResponsavel().getNome()) ){
			cb1.setVisible(true);
			cb2.setVisible(true);
		}else{
			cb1.setVisible(false);
			cb2.setVisible(false);
		}

		
	}
	
	
	public void salvar()throws FileNotFoundException, IOException{
		JFileChooser janelinha = new JFileChooser();
   		int escolha = janelinha.showOpenDialog(getParent());
   		if(escolha == JFileChooser.APPROVE_OPTION) {

     			JFrame frame = new JFrame();
     			JPanel panel = new JPanel();
     			JTextArea area = new JTextArea();
     			area = new JTextArea(5,30);
     			area.setEditable(false);
     			panel.add(area);
     			frame.getContentPane().add(BorderLayout.NORTH, panel);
     			frame.pack();
   		
     		String local = null;
     		if( janelinha.getSelectedFile().getAbsolutePath().endsWith(".comp2")) {
     			local = janelinha.getSelectedFile().getAbsolutePath();
     		}else{
     			local=janelinha.getSelectedFile().getAbsolutePath() +".comp2";
     		}
     		FileOutputStream arquivo = new FileOutputStream( local);
			ObjectOutputStream oos = new ObjectOutputStream(arquivo);
			
			oos.writeObject(jogo);
			oos.close();		
   		}
	}
	
	

	public void load(String local)throws IOException, ClassNotFoundException{
		
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream(local));
		jogo = (Jogo)ois.readObject();
		ois.close();
		
	}
	
	public void curar(JTextArea a) throws InterruptedException{
		
		a.append(  controlador.getJogo().getHospital().cuidar(getJogo().getHeroi()) );
		Thread.sleep(4000);
	}
	
	
	
	public void dormir(JFrame window,JTextArea ta) throws InterruptedException{
		if (DinheiroHeroi(0) >= getJogo().getEstalagem().getPrecoQuarto()){
			DinheiroHeroi(-500);
			Thread.sleep(5000);
			
			ta.setText( "Como foi a noite de sono ? \nObrigado por passar a noite aqui . ainda lhe restam .."+DinheiroHeroi(0)+"dins" );	
		}else{
			ta.setText("Voce nao tem dinheiro suficiente para passar a noite aqui tente dormir no hospital");
		}
		
	}
	
	
	public void ZERARjogo(){
		
		this.jogo=new Jogo();
	//	this.menu=new Menu();
		
		
	}

	
	
	

	
	
	
	
	
	
	public boolean retira(String item,JComboBox cbsai,JComboBox cbentra){
		
		
		boolean resulta=false;
		if (item.equals(null) || getJogo().getDeposito().getEstoque()==null ) return resulta;
		if (cbsai==null || cbsai.getSelectedItem().toString() == null || cbsai.getSelectedItem().toString().equals("")) return resulta;
		
		
		for(Item it : getJogo().getDeposito().getEstoque()){
			if ( it.getNome().equals(item) ) {
				
				getJogo().getHeroi().getInventario().add(it);
				cbentra.addItem(it.getNome());
				it.diminuiQuantidade();
				if ( it.getQuantidade() <= 0  ){
					getJogo().getDeposito().getEstoque().remove(it);
					cbsai.removeItem( cbsai.getSelectedItem());
				}
				resulta=true;
				break;
			}
		}
		
		return resulta;
	}
	
	
	
	
	
	public boolean armazena(String item,JComboBox cbsai,JComboBox cbentra){
				
		boolean resulta=false;
		
		if (item.equals(null) || getJogo().getHeroi().getInventario()==null) return resulta;
		
		if (cbsai==null || cbsai.getSelectedItem().toString() == null || cbsai.getSelectedItem().toString().equals("")) return resulta;
		
		for(Item it : getJogo().getHeroi().getInventario()){
			if ( it.getNome().equals(item) ) {
				
				getJogo().getDeposito().getEstoque().add(it);
				cbentra.addItem(it.getNome());
				it.diminuiQuantidade();
				if ( it.getQuantidade() <= 0  ){
						getJogo().getHeroi().getInventario().remove(it);
						cbsai.removeItem( cbsai.getSelectedItem());
				}
				resulta=true;
				break;
			}
		}
		
		return resulta;
	}
	
	
	
	public boolean compra(String item,JComboBox cbentra,JComboBox cbsai){
		boolean resulta=false;
		if (item.equals(null) || getJogo().getLoja().getEstoque()==null) return resulta;
		
		for(Item it : getJogo().getLoja().getEstoque() ){ 
			if (item.equals(it.getNome())){
				if ( getJogo().getHeroi().verificaDinheiro(it.getPrecoNovo()) ) {
					int debita= ((int) it.getPrecoNovo()) *(-1) ;
					DinheiroHeroi(debita);
					
					getJogo().getHeroi().getInventario().add(it);
					cbentra.addItem(it.getNome());
					it.diminuiQuantidade();
					if ( it.getQuantidade() <= 0  ){
						getJogo().getLoja().getEstoque().remove(it);
						cbsai.removeItem( cbsai.getSelectedItem());

					}
										
					resulta=true;
					break;
				}
			}
			
		}

		return resulta;
	
	}
	public boolean vende(String item,JComboBox cbentra,JComboBox cbsai){
		boolean resulta=false;
		if (item.equals(null) || getJogo().getHeroi().getInventario()==null) return resulta;
		for(Item it : getJogo().getHeroi().getInventario()){
			if ( it.getNome().equals(item) ) {
				DinheiroHeroi((int) it.getPrecoUsado());
				
				getJogo().getLoja().getEstoque().add(it);
				cbentra.addItem(it.getNome());
				
				it.diminuiQuantidade();
				if ( it.getQuantidade() <= 0  ){
						getJogo().getHeroi().getInventario().remove(it);
						cbsai.removeItem( cbsai.getSelectedItem());
				}
				resulta=true;
				break;
				
			}
		}
		return resulta;
		
	}
	
	public int Desafiante(JTextArea ta){
	    Desafio desafio = new Desafio();
		 Pergunta pergunta= desafio.geraRandom();
		 ta.setText(pergunta.getPergunta()+":\nOp��o 1: "+pergunta.getOpcoes(0)+":\nOp��o 2: "+pergunta.getOpcoes(1)+":\nOp��o 3: "+pergunta.getOpcoes(2)+":\nOp��o 4: "+pergunta.getOpcoes(3));
	
			 return pergunta.getCerta();
		 
			 
			 
	}

	
	
	private Component getParent() {
			// TODO Auto-generated method stub
			return null;
	}
	
	
}

	


	
	