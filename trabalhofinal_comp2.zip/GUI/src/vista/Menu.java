package vista;
import Controlador.*;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

import javax.swing.*;


public class Menu extends JFrame implements ActionListener, ControleRemoto {
    /**
	 * 
	 */
	private static final long serialVersionUID = -1959783845098361503L;
	JLabel labelJogo;
    JButton botIniciar;
    JButton botCarregar;
    JButton botInstrucoes;
    JButton botSair;

    InstrucoesGui instrucoesGui ;
    PracaGui pracaGui ;

   

	
    public Menu() {
 	   	
        MenuLayout customLayout = new MenuLayout();
        Font font = new Font("calibri", Font.BOLD, 28);
        
        //criando menus
        instrucoesGui = new InstrucoesGui();
  		pracaGui = new PracaGui();
  		
     
        getContentPane().setLayout(customLayout);

        labelJogo = new JLabel();
        labelJogo.setFont(font);
        labelJogo.setText("Jogo");
        getContentPane().add(labelJogo);

        botIniciar = new JButton("Iniciar");
        getContentPane().add(botIniciar);
        botIniciar.addActionListener(new IniciarOuvinte());

        botCarregar = new JButton("Carregar");
        getContentPane().add(botCarregar);
        botCarregar.addActionListener(new CarregarOuvinte());

        botInstrucoes = new JButton("Instrucoes");
        getContentPane().add(botInstrucoes);
        botInstrucoes.addActionListener(new InstrucoesOuvinte());

        botSair = new JButton("Sair");
        getContentPane().add(botSair);
        botSair.addActionListener(new SairOuvinte());
        
       
         

        setSize(getPreferredSize());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 

    }
        

    	
    	
    	
    
   






       class IniciarOuvinte implements ActionListener {
        	@Override
        	public void actionPerformed(ActionEvent ev){
        		
        		new PracaGui().abrir();
        		Menu.this.dispose();
        		controlador.ZERARjogo();
        		
        	}
        }
       

		class CarregarOuvinte implements ActionListener {
	       		@Override
	       		public void actionPerformed(ActionEvent ev){
	       			
	       			try {
						if ( new NEW_LOAD_GUI().load() ) Menu.this.dispose();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	       		}
       				
       		}


		class InstrucoesOuvinte implements ActionListener {
       		@Override
       		public void actionPerformed(ActionEvent ev){
        		new InstrucoesGui().abrir( );
        		
        		
       		}
       	
       }
       
       class SairOuvinte implements ActionListener {
    	   @Override
    	   public void actionPerformed(ActionEvent ev){
    		   System.exit(0);
       	
    	   }
       	
       }
       
       
	   	@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
		}
       
       
       
       
       
       
       
       
       
       
       
       
       public void mostrar(){
    	   
       	   Menu window = new Menu();
       	   window.setLocationRelativeTo(null);
       
       	   
           window.pack();
           window.setVisible(true);
           
          
       }



       
}

    









    
//Gerenciador de layout proprio
class MenuLayout implements LayoutManager {

    public MenuLayout() {
    }

    public void addLayoutComponent(String name, Component comp) {
    }

    public void removeLayoutComponent(Component comp) {
    }

    public Dimension preferredLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);

        Insets insets = parent.getInsets();
        dim.width = 683 + insets.left + insets.right;
        dim.height = 439 + insets.top + insets.bottom;

        return dim;
    }

    public Dimension minimumLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);
        return dim;
    }

    public void layoutContainer(Container parent) {
        Insets insets = parent.getInsets();

        Component c;
        c = parent.getComponent(0);
        if (c.isVisible()) {c.setBounds(insets.left+160,insets.top+32,232,72);}
        c = parent.getComponent(1);
        if (c.isVisible()) {c.setBounds(insets.left+424,insets.top+136,104,32);}
        c = parent.getComponent(2);
        if (c.isVisible()) {c.setBounds(insets.left+424,insets.top+184,104,32);}
        c = parent.getComponent(3);
        if (c.isVisible()) {c.setBounds(insets.left+424,insets.top+232,104,32);}
        c = parent.getComponent(4);
        if (c.isVisible()) {c.setBounds(insets.left+424,insets.top+280,104,32);}

    }
}
