package vista;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import Controlador.ControleRemoto;



public class DesafioGui extends JFrame implements ControleRemoto{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel labelDesafio;
    JTextArea taDescricao;
    JScrollPane sp_taDescricao;
    JButton botOp1;
    JLabel labelString;
    JButton botOp2;
    JButton botOp3;
    JButton botOp4;
    int resp;
    int perg;

    public DesafioGui() {
        DesafioLayout customLayout = new DesafioLayout();
        
        
        
        Font font = new Font("Helvetica", Font.PLAIN, 36);
        Font font2 = new Font("Helvetica", Font.PLAIN, 28);
        resp=0;
        
        
        getContentPane().setFont(new Font("Helvetica", Font.PLAIN, 12));
        getContentPane().setLayout(customLayout);

        labelDesafio = new JLabel();
        labelDesafio.setFont(font);
        labelDesafio.setText("Desafio");
        getContentPane().add(labelDesafio);

        
        taDescricao = new JTextArea();
        taDescricao.setEditable(false);
        sp_taDescricao = new JScrollPane(taDescricao);
        getContentPane().add(sp_taDescricao);

        botOp1 = new JButton("Opcao 1");
        botOp1.addActionListener(new op1Ouvinte());
        getContentPane().add(botOp1);

        labelString = new JLabel();
        labelString.setFont(font2);
        labelString.setText("Responda certo para continuar o jogo");
        getContentPane().add(labelString);

        botOp2 = new JButton("Opcao 2");
        botOp2.addActionListener(new op2Ouvinte());
        getContentPane().add(botOp2);

        botOp3 = new JButton("Opcao 3");
        botOp3.addActionListener(new op3Ouvinte());
        getContentPane().add(botOp3);

        botOp4 = new JButton("Opcao 4");
        botOp4.addActionListener(new op4Ouvinte());
        getContentPane().add(botOp4);

        ImagePanel panel = new ImagePanel(new ImageIcon("challenge-accepted.jpg").getImage());
        getContentPane().add(panel);
        setSize(getPreferredSize());
        

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    class op1Ouvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		resp=1;
    		if (perg==resp){
    			controlador.DinheiroHeroi(2000);
    			new PracaGui().abrir();
       		 DesafioGui.this.dispose();
    		}
    	}
    }
    
    class op2Ouvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		resp=2;
    		if (perg==resp){
    			controlador.DinheiroHeroi(2000);
    			new PracaGui().abrir();
       		 DesafioGui.this.dispose();
    		}
    	}
    }

    class op3Ouvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		resp=3;
    		
    		if (perg==resp){
    			controlador.DinheiroHeroi(2000);
    			new PracaGui().abrir();
       		 DesafioGui.this.dispose();
    		}
    	}
    }
    
    class op4Ouvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		resp=4;
    		if (perg==resp){
    			controlador.DinheiroHeroi(2000);
    			new PracaGui().abrir();
       		 	DesafioGui.this.dispose();
    		}
    	}
    }
    
    
    
    
    
    
    
    
    //public static void main(String args[]) {
      public void abrir(){
    	DesafioGui window = new DesafioGui();
    	 window.perg = controlador.Desafiante(window.taDescricao);
    		 
    	 
    	
        window.setTitle("DesafioGui Mortal");
        window.pack();
        window.setVisible(true);
    }
}
















class DesafioLayout implements LayoutManager {

    public DesafioLayout() {
    }

    public void addLayoutComponent(String name, Component comp) {
    }

    public void removeLayoutComponent(Component comp) {
    }

    public Dimension preferredLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);

        Insets insets = parent.getInsets();
        dim.width = 678 + insets.left + insets.right;
        dim.height = 437 + insets.top + insets.bottom;

        return dim;
    }

    public Dimension minimumLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);
        return dim;
    }

    public void layoutContainer(Container parent) {
        Insets insets = parent.getInsets();

        Component c;
        c = parent.getComponent(0);
        if (c.isVisible()) {c.setBounds(insets.left+280,insets.top+48,208,48);}
        c = parent.getComponent(1);
        if (c.isVisible()) {c.setBounds(insets.left+112,insets.top+192,464,136);}
        c = parent.getComponent(2);
        if (c.isVisible()) {c.setBounds(insets.left+112,insets.top+368,96,24);}
        c = parent.getComponent(3);
        if (c.isVisible()) {c.setBounds(insets.left+112,insets.top+120,500,48);}
        c = parent.getComponent(4);
        if (c.isVisible()) {c.setBounds(insets.left+240,insets.top+368,88,24);}
        c = parent.getComponent(5);
        if (c.isVisible()) {c.setBounds(insets.left+368,insets.top+368,88,24);}
        c = parent.getComponent(6);
        if (c.isVisible()) {c.setBounds(insets.left+488,insets.top+368,88,24);}
    }
}

