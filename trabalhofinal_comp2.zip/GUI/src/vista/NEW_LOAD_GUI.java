package vista;


import Controlador.ControleRemoto;


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.Serializable;

import javax.swing.*;



public class NEW_LOAD_GUI extends JFrame implements  ControleRemoto, Serializable, ActionListener {
//public class NEW_LOAD_GUI implements  ControleRemoto {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	
	
	
	@SuppressWarnings("deprecation")
	boolean novo(){
		boolean YN=false;
		
			JFrame frame = new JFrame();
			JPanel panel = new JPanel();
			final JTextField campo;
			JButton bot = new JButton();
			campo = new JTextField(30);
			campo.setEditable(true);
			campo.setText("Digite aqui seu nome");
			
			panel.add(campo);
			panel.add(bot);
			bot.setLabel("OK");
			bot.addActionListener(new ActionListener() {
				
						@Override
						public void actionPerformed(ActionEvent e) {
		
							
								if ( !campo.getText().equalsIgnoreCase("Digite aqui seu nome") ) {
									controlador.NomeHeroi(campo.getText());
					   				campo.setText(null);
					   				
								}
			
							
						}
						
			}
			);
			
			frame.getContentPane().add(BorderLayout.NORTH, panel);
			frame.pack();
			frame.setVisible(true);
	
			YN = true;
 			frame.dispose();
   			return YN;
   			
   			
   			
	}
	
	


	
	
	
	/*
	boolean novo(){
		JFrame frame = new JFrame();
		JPanel panel = new JPanel();
		final JTextField campo;
		JButton bot = new JButton();
		campo = new JTextField(30);
		campo.setEditable(true);
		campo.setText("Digite aqui seu nome");
		frame.setLocationRelativeTo(null);
		panel.add(campo);
		panel.add(bot);
		bot.setLabel("OK");
		bot.addActionListener(new OKOuvinte());
		
		frame.getContentPane().add(BorderLayout.NORTH, panel);
		frame.pack();
		frame.setVisible(true);

		
		return false;
		
	}
	
	class OKOuvinte implements ActionListener {
		
			@Override
			public void actionPerformed(ActionEvent e) {
					
			}
		
	}
	
	*/
	
	
	
	
	
	
	
	
	
	
	boolean load() throws IOException, ClassNotFoundException{
   			boolean YN=false;
			JFileChooser janelinha = new JFileChooser();
	   		int escolha = janelinha.showOpenDialog(getParent());
	   		if(escolha == JFileChooser.APPROVE_OPTION) {
	
	     			JFrame frame = new JFrame();
	     			JPanel panel = new JPanel();
	     			JTextArea area = new JTextArea();
	     			area = new JTextArea(5,30);
	     			area.setEditable(false);
	     			panel.add(area);
	     			frame.getContentPane().add(BorderLayout.NORTH, panel);
	     			frame.pack();
	   			 
	       			if (janelinha.getSelectedFile().getName().endsWith(".comp2")){

		        			area.setText("Os dados foram carregados do arquivo  " +
		       	            janelinha.getSelectedFile().getName() + 
		       	            "\n\n Feche a janela para continuar (X)"
		       	            );
		        			
		        			
		        			controlador.load(janelinha.getSelectedFile().getAbsolutePath());
		        			new PracaGui().abrir();
		       				YN = true;
	       			}
	       			
	       			else{
	       				area.setText("O arquivo nao corresponde a esse programa! " +
	       				"\n\n Feche a janela (X) e tente com outro arquivo");
	       				
	       				YN =false;
	       			}
	       			
	       			
	       			
	       			frame.setVisible(true);

	   		}
	   		
	   		return YN;
	}






	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}


}
