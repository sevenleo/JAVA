package vista;

//package vista;
import java.awt.*;
import java.awt.event.*;
import java.io.FileNotFoundException;

import java.io.IOException;
import javax.swing.*;
import Controlador.*;

public class PracaGui extends JFrame implements ControleRemoto{
	private static final long serialVersionUID = 1L;
	
	JLabel labelLoja;
    JTextField tfMensagem;
    JTextArea taDescricao;
    JScrollPane sp_taDescricao;
    JButton botOlhar;
    JButton botInteragir;
    JButton botIr;
    JButton botMenu;
    JButton botSalvar;
    JButton botSair;
    JComboBox cbOlhar;
    JComboBox cbInteragir;
    JComboBox cbIr;
    JLabel labelDinheiro;
    JTextField tfDinheiro;
    JLabel labelMochila;
    JComboBox cbItens;
    JButton botTrabalhar;
    JLabel labelMensagem;
    JButton botDesafio;
    
    //JLabel labelimagem;
    //ImageIcon imagem;
    
    public PracaGui() {
        PracaLayout customLayout = new PracaLayout();
        Font font =  new Font("Helvetica", Font.PLAIN, 32);

        getContentPane().setFont(new Font("Helvetica", Font.PLAIN, 12));
        getContentPane().setLayout(customLayout);

        labelLoja = new JLabel();
        labelLoja.setFont(font);
        labelLoja.setText("Praca");
        getContentPane().add(labelLoja);
        
        tfMensagem = new JTextField();
        tfMensagem.addKeyListener(new teclado());
        tfMensagem.setEditable(true);
        getContentPane().add(tfMensagem);

        taDescricao = new JTextArea();
        taDescricao.setEditable(false);
        sp_taDescricao = new JScrollPane(taDescricao);
        getContentPane().add(sp_taDescricao);

        botOlhar = new JButton("Olhar");
        botOlhar.addActionListener(new OlharOuvinte());
        getContentPane().add(botOlhar);

        botInteragir = new JButton("Interagir");
        botInteragir.addActionListener(new InteragirOuvinte());
        getContentPane().add(botInteragir);

        botIr = new JButton("Ir");
        botIr.addActionListener(new IrOuvinte());
        getContentPane().add(botIr);

        botMenu = new JButton("Menu");
        botMenu.addActionListener(new MenuOuvinte());
        getContentPane().add(botMenu);

        botSair = new JButton("Sair");
        botSair.addActionListener(new SairOuvinte());
        getContentPane().add(botSair);

        cbOlhar = new JComboBox();
        getContentPane().add(cbOlhar);

        cbInteragir = new JComboBox();
        getContentPane().add(cbInteragir);

        cbIr = new JComboBox();
        cbIr.addItem("Deposito");
        cbIr.addItem("Estalagem");
        cbIr.addItem("Hospital");
        cbIr.addItem("Loja");
        cbIr.addItem("Casa");
        getContentPane().add(cbIr);

        labelDinheiro = new JLabel("Dinheiro");
        getContentPane().add(labelDinheiro);
        
        tfDinheiro = new JTextField();
        tfDinheiro.setEditable(false);
        getContentPane().add(tfDinheiro);

        labelMochila = new JLabel("Mochila");
        getContentPane().add(labelMochila);

        cbItens = new JComboBox();
        getContentPane().add(cbItens);

        botTrabalhar = new JButton("Trabalhar");
        botTrabalhar.addActionListener(new DinheiroOuvinte());
        getContentPane().add(botTrabalhar);

        labelMensagem = new JLabel("Mensagem :");
        getContentPane().add(labelMensagem);
        
        botSalvar = new JButton("Salvar");
        botSalvar.addActionListener(new SalvarOuvinte());
        getContentPane().add(botSalvar);

        botDesafio=new JButton("Desafio");
        botDesafio.addActionListener(new DesafioOuvinte());
        getContentPane().add(botDesafio);
        
        /*
        imagem=new ImageIcon("praca.jpg");
        labelimagem = new JLabel();
        getContentPane().add(labelimagem);
        */
        
        setSize(getPreferredSize());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    } 

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    // Classes dos ouvintes dos botoes
    
    public class teclado implements KeyListener{
    	@Override
    	public void keyTyped ( KeyEvent e ){ 
    		
			
		}

		@Override
		public void keyPressed(KeyEvent e) {
			// TODO Auto-generated method stub
			

		}

		@Override
		public void keyReleased(KeyEvent e) {
			// TODO Auto-generated method stub
			if ( e.getKeyCode() == KeyEvent.VK_ENTER ) {
				controlador.NomeHeroi(tfMensagem.getText());
				tfMensagem.setText("Voce esta jogando como " + controlador.NomeHeroi(null).toUpperCase());
				tfMensagem.setEditable(false);
			} 
    		
		}
	
	}
  
    
    
    
    public class DesafioOuvinte implements ActionListener{
    	@Override
		public void actionPerformed(ActionEvent ev){
    		new DesafioGui().abrir();
    		PracaGui.this.dispose();
    		tfDinheiro.setText("$"+controlador.DinheiroHeroi(545));
		}
    	
	
	}
    
    
    public class MenuOuvinte implements ActionListener{
    	@Override
		public void actionPerformed(ActionEvent ev){
    		new Menu().mostrar( );
    		PracaGui.this.dispose();
    		
		
		}
	
	}
    
    public class SairOuvinte implements ActionListener{
    	@Override
		public void actionPerformed(ActionEvent ev){
    		System.exit(0);
		}
	
	}
    
    public class OlharOuvinte implements ActionListener{
    	@Override
		public void actionPerformed(ActionEvent ev){
    		controlador.olhar("praca", cbOlhar, taDescricao);
	
		}
	}
    
    public class InteragirOuvinte implements ActionListener{
    	@Override
		public void actionPerformed(ActionEvent ev){
    		controlador.interagir("praca", cbInteragir, taDescricao);
		
		}
	
	}
    
    public class IrOuvinte implements ActionListener{
    	@Override
		public void actionPerformed(ActionEvent ev){
    		String irLocal = (String)cbIr.getSelectedItem();
    		if(irLocal.equalsIgnoreCase("loja")) new LojaGui().abrir();
    		if(irLocal.equalsIgnoreCase("deposito")) new DepositoGui().abrir();
    		if(irLocal.equalsIgnoreCase("estalagem")) new EstalagemGUI().abrir();
    		if(irLocal.equalsIgnoreCase("hospital")) new HospitalGUI().abrir();
    		if(irLocal.equalsIgnoreCase("casa")) new CasaGui().abrir();
    		PracaGui.this.dispose();
		}
	
	}
    
    public class DinheiroOuvinte implements ActionListener{
    	@Override
		public void actionPerformed(ActionEvent ev){
    		try {
				Thread.sleep(10000);
				taDescricao.setText("'O trabalho enriquece o homem' \n\n");
	    		taDescricao.append("O unico lugar onde o sucesso vem antes do trabalho e no dicionario. \n (Albert Einstein)");
	    		tfDinheiro.setText("$"+controlador.DinheiroHeroi(545));
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
  
    public class SalvarOuvinte implements ActionListener{
    	@Override
		public void actionPerformed(ActionEvent ev){
			

			try {
				controlador.salvar();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
	}
    
    public void abrir() {
        PracaGui window = new PracaGui();
        window.setLocationRelativeTo(null);
        controlador.LugarHeroi("praca");
        if ( controlador.NomeHeroi(null).equalsIgnoreCase("ze ninguem") ) {
        	window.tfMensagem.setEditable(true);
        	window.tfMensagem.setText("  >>> Digite o seu nome aqui e pressione ENTER");
        }
        else{
        	window.tfMensagem.setText("Voce esta jogando como " + controlador.NomeHeroi(null).toUpperCase());
        	window.tfMensagem.setEditable(false);
        }
        
        window.pack();
        window.setVisible(true);
        
        controlador.Instrucoes("praca",window.taDescricao);
        
        
        window.tfDinheiro.setText("$" + controlador.DinheiroHeroi(0) );
        
        
        controlador.MostraMochila(window.cbItens);
        controlador.ListarOpcoes("praca", window.cbOlhar, window.cbInteragir);
    }
    


}











class PracaLayout implements LayoutManager {

    public PracaLayout() {
    }

    public void addLayoutComponent(String name, Component comp) {
    }

    public void removeLayoutComponent(Component comp) {
    }

    public Dimension preferredLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);

        Insets insets = parent.getInsets();
        dim.width = 683 + insets.left + insets.right;
        dim.height = 439 + insets.top + insets.bottom;

        return dim;
    }

    public Dimension minimumLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);
        return dim;
    }

    public void layoutContainer(Container parent) {
        Insets insets = parent.getInsets();

        Component c;
        int i=0;
        c = parent.getComponent(i);
        if (c.isVisible()) {c.setBounds(insets.left+250,insets.top+32,216,56);}
        i=i+1;
        c = parent.getComponent(i);
        if (c.isVisible()) {c.setBounds(insets.left+144,insets.top+384,400,24);}
        i=i+1;
        c = parent.getComponent(i);
        if (c.isVisible()) {c.setBounds(insets.left+32,insets.top+104,512,136);}
        i=i+1;
        c = parent.getComponent(i);
        if (c.isVisible()) {c.setBounds(insets.left+32,insets.top+256,104,24);}
        i=i+1;
        c = parent.getComponent(i);
        if (c.isVisible()) {c.setBounds(insets.left+32,insets.top+296,104,24);}
        i=i+1;
        c = parent.getComponent(i);
        if (c.isVisible()) {c.setBounds(insets.left+32,insets.top+336,104,24);}
        i=i+1;
        c = parent.getComponent(i);
        if (c.isVisible()) {c.setBounds(insets.left+560,insets.top+104,96,24);}
        i=i+1;
        c = parent.getComponent(i);
        if (c.isVisible()) {c.setBounds(insets.left+560,insets.top+384,96,24);}
        i=i+1;
        c = parent.getComponent(i);
        if (c.isVisible()) {c.setBounds(insets.left+152,insets.top+256,102,24);}
        i=i+1;
        c = parent.getComponent(i);
        if (c.isVisible()) {c.setBounds(insets.left+152,insets.top+296,102,24);}
        i=i+1;
        c = parent.getComponent(i); //10
        if (c.isVisible()) {c.setBounds(insets.left+152,insets.top+336,102,24);}
        i=i+1;
        c = parent.getComponent(i);
        if (c.isVisible()) {c.setBounds(insets.left+560,insets.top+256,72,24);}
        i=i+1;
        c = parent.getComponent(i);
        if (c.isVisible()) {c.setBounds(insets.left+560,insets.top+296,70,24);}
        i=i+1;
        c = parent.getComponent(i);
        if (c.isVisible()) {c.setBounds(insets.left+298,insets.top+256,104,24);}
        i=i+1;
        c = parent.getComponent(i);
        if (c.isVisible()) {c.setBounds(insets.left+392,insets.top+256,104,24);}
        i=i+1;
        c = parent.getComponent(i);
        if (c.isVisible()) {c.setBounds(insets.left+272,insets.top+296,104,24);}
        i=i+1;
        c = parent.getComponent(i);
        if (c.isVisible()) {c.setBounds(insets.left+32,insets.top+384,104,24);}
        i=i+1;
        c = parent.getComponent(i);
        if (c.isVisible()) {c.setBounds(insets.left+560,insets.top+144,96,24);}
        i=i+1;
        c = parent.getComponent(i);
        if (c.isVisible()) {c.setBounds(insets.left+390,insets.top+296,104,24);}
        //i=i+1;
        //c = parent.getComponent(i);
        //if (c.isVisible()) {c.setBounds(insets.left+390,insets.top+296,104,24);}
    }
}


