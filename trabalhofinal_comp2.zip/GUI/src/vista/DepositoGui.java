package vista;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


import Controlador.ControleRemoto;


public class DepositoGui extends JFrame implements ControleRemoto{
	
private static final long serialVersionUID = 1L;
	
	JLabel labelLoja;
    JTextField tfMensagem;
    JTextArea taDescricao;
    JScrollPane sp_taDescricao;
    JButton botOlhar;
    JButton botInteragir;
    JButton botIr;
    JButton botMenu;
    JButton botSair;
    JComboBox cbOlhar;
    JComboBox cbInteragir;
    JComboBox cbIr;
    JLabel labelItens;
    JComboBox cbItens;
    JLabel labelDinheiro;
    JTextField tfDinheiro;
    JButton botDinheiro;
    JButton botArmazenar;
    JComboBox cbArmazenar;
    JButton botRecuperar;
    JComboBox cbRecuperar;
    JLabel labelMensagem;

    public DepositoGui() {
        DepositoLayout customLayout = new DepositoLayout();
        Font font =  new Font("Comic Sans", Font.PLAIN, 36);

        getContentPane().setFont(new Font("Helvetica", Font.PLAIN, 12));
        getContentPane().setLayout(customLayout);

        labelLoja = new JLabel("Deposito");
        labelLoja.setFont(font);
        getContentPane().add(labelLoja);
        
        tfMensagem = new JTextField();
        tfMensagem.setEditable(false);
        getContentPane().add(tfMensagem);

        taDescricao = new JTextArea();
        taDescricao.setEditable(false);
        sp_taDescricao = new JScrollPane(taDescricao);
        getContentPane().add(sp_taDescricao);

        botOlhar = new JButton("Olhar");
        botOlhar.addActionListener(new OlharOuvinte());
        getContentPane().add(botOlhar);

        botInteragir = new JButton("Interagir");
        botInteragir.addActionListener(new InteragirOuvinte());
        getContentPane().add(botInteragir);

        botIr = new JButton("Ir");
        botIr.addActionListener(new IrOuvinte());
        getContentPane().add(botIr);

        botMenu = new JButton("Menu");
        botMenu.addActionListener(new MenuOuvinte());
        getContentPane().add(botMenu);

        botSair = new JButton("Sair");
        botSair.addActionListener(new SairOuvinte());
        getContentPane().add(botSair);

        cbOlhar = new JComboBox();

        getContentPane().add(cbOlhar);

        cbInteragir = new JComboBox();

        getContentPane().add(cbInteragir);

        cbIr = new JComboBox();
        cbIr.addItem("Praca");
        getContentPane().add(cbIr);

        labelItens = new JLabel("Itens");
        getContentPane().add(labelItens);

        cbItens = new JComboBox();

        getContentPane().add(cbItens);

        labelDinheiro = new JLabel("Dinheiro");
        getContentPane().add(labelDinheiro);
        
        tfDinheiro = new JTextField("");
        tfDinheiro.setEditable(false);
        getContentPane().add(tfDinheiro);

        botDinheiro = new JButton("Dinheiro");
       // botDinheiro.addActionListener(new dinheiroOuvinte());
        getContentPane().add(botDinheiro);

        botArmazenar = new JButton("Armazenar");
        botArmazenar.addActionListener(new ArmazenarOuvinte());
        getContentPane().add(botArmazenar);

        cbArmazenar = new JComboBox();

        getContentPane().add(cbArmazenar);

        botRecuperar = new JButton("Recuperar");
        botRecuperar.addActionListener(new RecuperarOuvinte());
        getContentPane().add(botRecuperar);

        cbRecuperar = new JComboBox();

        getContentPane().add(cbRecuperar);

        labelMensagem = new JLabel("Mensagem :");
        getContentPane().add(labelMensagem);

        setSize(getPreferredSize());

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
    
    
    
    
    
    
    
    
    public  void abrir() {
        DepositoGui window = new DepositoGui();
        window.setLocationRelativeTo(null);
        controlador.LugarHeroi("deposito");
		controlador.habilitabotao(null, window.botArmazenar,window.botRecuperar);
		controlador.habilitacaixa(null, window.cbArmazenar, window.cbRecuperar);
        window.setTitle("deposito");
        controlador.Instrucoes("deposito",window.taDescricao);
        window.pack();
        window.setVisible(true);
        if (controlador.NomeHeroi(null).equals(null)  ){
        	
        }else{
        	window.tfMensagem.setText("Voce esta jogando como " + controlador.NomeHeroi(null).toUpperCase());
        }
        	
        	
        controlador.MostraMochila(window.cbArmazenar);
        controlador.Mostradeposito("deposito", window.cbRecuperar);
        controlador.ListarOpcoes("deposito", window.cbOlhar, window.cbInteragir);
       
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    // Classes dos ouvintes dos botoes
    
    class OlharOuvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		controlador.olhar("deposito", cbOlhar, taDescricao);
    		controlador.habilitabotao(null, botArmazenar,botRecuperar);
    		controlador.habilitacaixa(null, cbArmazenar, cbRecuperar);
    	}
    }
    
    class InteragirOuvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		controlador.interagir("deposito", cbInteragir, taDescricao);
    		controlador.habilitabotao(cbInteragir, botArmazenar,botRecuperar);
    		controlador.habilitacaixa(cbInteragir, cbArmazenar, cbRecuperar);    	}
    }
    
    class IrOuvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		new PracaGui().abrir();
    		DepositoGui.this.dispose();
    		
    		
    	}
    }
    
    public class MenuOuvinte implements ActionListener{
    	@Override
		public void actionPerformed(ActionEvent ev){
    		new Menu().mostrar( );
    		DepositoGui.this.dispose();
    		
		
		}
	
	}
    
    public class SairOuvinte implements ActionListener{
    	@Override
		public void actionPerformed(ActionEvent ev){
    		System.exit(0);
		}
	
	}
    
    public class PracaOuvinte implements ActionListener{
    	@Override
		public void actionPerformed(ActionEvent ev){
    		new PracaGui().abrir();
    		DepositoGui.this.dispose();
		}
	
	}
    
    public class ArmazenarOuvinte implements ActionListener{
    	@Override
		public void actionPerformed(ActionEvent ev){
    		taDescricao.setText("Voce tentou depositar um "+cbArmazenar.getSelectedItem().toString());
    		if ( controlador.armazena(cbArmazenar.getSelectedItem().toString(),cbArmazenar, cbRecuperar)){
    			taDescricao.append("\n > com sucesso");
    		}else{
    			taDescricao.append("\n > sem sucesso");
    		}

		}
	
	}
    
    
    
       
    
    
    public class RecuperarOuvinte implements ActionListener{
    	@Override
		public void actionPerformed(ActionEvent ev){
    		taDescricao.setText("Voce tentou retirar um "+cbRecuperar.getSelectedItem().toString());
    		if ( controlador.retira(cbRecuperar.getSelectedItem().toString(), cbRecuperar,cbArmazenar)){
    			taDescricao.append("\n > com sucesso");
    		}else{
    			taDescricao.append("\n > sem sucesso");
    		}
    		
		}
	
	}
    
    

    
}


class DepositoLayout implements LayoutManager {

    public DepositoLayout() {
    }

    public void addLayoutComponent(String name, Component comp) {
    }

    public void removeLayoutComponent(Component comp) {
    }

    public Dimension preferredLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);

        Insets insets = parent.getInsets();
        dim.width = 683 + insets.left + insets.right;
        dim.height = 439 + insets.top + insets.bottom;

        return dim;
    }

    public Dimension minimumLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);
        return dim;
    }

    public void layoutContainer(Container parent) {
        Insets insets = parent.getInsets();

        Component c;
        c = parent.getComponent(0);
        if (c.isVisible()) {c.setBounds(insets.left+250,insets.top+32,216,56);}
        c = parent.getComponent(1);
        if (c.isVisible()) {c.setBounds(insets.left+144,insets.top+384,400,24);}
        c = parent.getComponent(2);
        if (c.isVisible()) {c.setBounds(insets.left+32,insets.top+104,512,136);}
        c = parent.getComponent(3);
        if (c.isVisible()) {c.setBounds(insets.left+32,insets.top+256,104,24);}
        c = parent.getComponent(4);
        if (c.isVisible()) {c.setBounds(insets.left+32,insets.top+296,104,24);}
        c = parent.getComponent(5);
        if (c.isVisible()) {c.setBounds(insets.left+32,insets.top+336,104,24);}
        c = parent.getComponent(6);
        if (c.isVisible()) {c.setBounds(insets.left+560,insets.top+104,96,24);}
        c = parent.getComponent(7);
        if (c.isVisible()) {c.setBounds(insets.left+560,insets.top+384,96,24);}
        c = parent.getComponent(8);
        if (c.isVisible()) {c.setBounds(insets.left+152,insets.top+256,102,24);}
        c = parent.getComponent(9);
        if (c.isVisible()) {c.setBounds(insets.left+152,insets.top+296,102,24);}
        c = parent.getComponent(10);
        if (c.isVisible()) {c.setBounds(insets.left+152,insets.top+336,102,24);}
        c = parent.getComponent(16);
        if (c.isVisible()) {c.setBounds(insets.left+272,insets.top+256,115,24);}
        c = parent.getComponent(17);
        if (c.isVisible()) {c.setBounds(insets.left+403,insets.top+256,72,24);}
        c = parent.getComponent(18);
        if (c.isVisible()) {c.setBounds(insets.left+272,insets.top+296,115,24);}
        c = parent.getComponent(19);
        if (c.isVisible()) {c.setBounds(insets.left+403,insets.top+296,72,24);}
        c = parent.getComponent(20);
        if (c.isVisible()) {c.setBounds(insets.left+32,insets.top+384,104,24);}
    }
}
