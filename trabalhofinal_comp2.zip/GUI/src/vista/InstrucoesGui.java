package vista;
import Controlador.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class InstrucoesGui extends JFrame implements ControleRemoto{
    /**
	 * 
	 */
	private static final long serialVersionUID = -1650449623031070116L;
	JLabel label_1;
    JButton button_3;
    JTextArea textarea_1;
    JScrollPane sp_textarea_1;

    public InstrucoesGui() {
        instrucoesLayout customLayout = new instrucoesLayout(); // Gerenciador de Layout pr�prio
        Font font = new Font("calibri", Font.BOLD, 26);
        
        getContentPane().setLayout(customLayout);

       
        
        
        label_1 = new JLabel();
        label_1.setFont(font);
        label_1.setText("Instrucoes");
        getContentPane().add(label_1);

        button_3 = new JButton("Voltar");
        getContentPane().add(button_3);
        button_3.addActionListener(new VoltarOuvinte());

        textarea_1 = new JTextArea("Instrucoes:\n");
        textarea_1.setEditable(false);
        textarea_1.setLineWrap(true);
        sp_textarea_1 = new JScrollPane(textarea_1);
        getContentPane().add(sp_textarea_1);

        setSize(getPreferredSize());

 
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
    
    public class VoltarOuvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    
    		InstrucoesGui.this.dispose();
    		
    	
    		
    	}
    }


    public void abrir( ){
        InstrucoesGui window = new InstrucoesGui();

        //window.setTitle("sem titulo");
        window.pack();
        window.setVisible(true);
        controlador.Instrucoes("jogo",window.textarea_1);

        
    
      
    }
    
    
}

// Gerenciador de Layout da classe
class instrucoesLayout implements LayoutManager {

    public instrucoesLayout() {
    }

    public void addLayoutComponent(String name, Component comp) {
    }

    public void removeLayoutComponent(Component comp) {
    }

    public Dimension preferredLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);

        Insets insets = parent.getInsets();
        dim.width = 520 + insets.left + insets.right;
        dim.height = 336 + insets.top + insets.bottom;

        return dim;
    }

    public Dimension minimumLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);
        return dim;
    }

    public void layoutContainer(Container parent) {
        Insets insets = parent.getInsets();

        Component c;
        c = parent.getComponent(0);
        if (c.isVisible()) {c.setBounds(insets.left+192,insets.top+32,136,32);}
        c = parent.getComponent(1);
        if (c.isVisible()) {c.setBounds(insets.left+104,insets.top+272,96,32);}
        c = parent.getComponent(2);
        if (c.isVisible()) {c.setBounds(insets.left+104,insets.top+88,328,152);}
    }
}
