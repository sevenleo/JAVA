﻿package vista;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


import Controlador.ControleRemoto;

public class EstalagemGUI extends JFrame implements ControleRemoto{
	
 
	/**
	 * 
	 */
	private static final long serialVersionUID = 7960008125781020822L;
	JLabel labelLoja;
    JTextField tfMensagem;
    JTextArea taDescricao;
    JScrollPane sp_taDescricao;
    JButton botOlhar;
    JButton botInteragir;
    JButton botIr;
    JButton botMenu;
    JButton botSair;
    JComboBox cbOlhar;
    JComboBox cbInteragir;
    JComboBox cbIr;
    JButton botSim;
    JButton botNao;
    JLabel labelMensagem;

    public EstalagemGUI() {
        EstalagemLayout customLayout = new EstalagemLayout();
        Font font =  new Font("Comic Sans", Font.PLAIN, 32);

        getContentPane().setFont(new Font("Helvetica", Font.PLAIN, 12));
        getContentPane().setLayout(customLayout);

        labelLoja = new JLabel("Estalagem");
        labelLoja.setFont(font);
        getContentPane().add(labelLoja);
        
        tfMensagem = new JTextField();
        tfMensagem.setEditable(false);
        getContentPane().add(tfMensagem);

        taDescricao = new JTextArea();
        taDescricao.setEditable(false);
        sp_taDescricao = new JScrollPane(taDescricao);
        getContentPane().add(sp_taDescricao);

        botOlhar = new JButton("Olhar");
        botOlhar.addActionListener(new olharOuvinte());
        getContentPane().add(botOlhar);

        botInteragir = new JButton("Interagir");
        botInteragir.addActionListener(new interagirOuvinte());
        getContentPane().add(botInteragir);

        botIr = new JButton("Ir");
        botIr.addActionListener(new irOuvinte());
        getContentPane().add(botIr);

        botMenu = new JButton("Menu");
        botMenu.addActionListener(new menuOuvinte());
        getContentPane().add(botMenu);

        botSair = new JButton("Sair");
        botSair.addActionListener(new sairOuvinte());
        getContentPane().add(botSair);

        cbOlhar = new JComboBox();
        getContentPane().add(cbOlhar);

        cbInteragir = new JComboBox();
        getContentPane().add(cbInteragir);

        cbIr = new JComboBox();
        cbIr.addItem("Praca");
        getContentPane().add(cbIr);

        botSim = new JButton("Sim");
        botSim.addActionListener(new SimOuvinte());
        getContentPane().add(botSim);

        botNao = new JButton("Nao");
        botNao.addActionListener(new NaoOuvinte());
        getContentPane().add(botNao);

        labelMensagem = new JLabel("Mensagem :");
        getContentPane().add(labelMensagem);

        setSize(getPreferredSize());

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
    
    
    
    
    
    
    
    
    
    
    
    
    // Classes dos ouvintes 
    
    class menuOuvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		new Menu().mostrar( );
    		EstalagemGUI.this.dispose();
    	}
    }
    
    class sairOuvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		System.exit(0);
    	}
    }
    
    class olharOuvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		controlador.olhar("estalagem", cbOlhar, taDescricao);
    		controlador.habilitabotao(null,botNao,botSim);
    	}
    }
    
    class interagirOuvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		controlador.interagir("estalagem", cbInteragir, taDescricao);
    		controlador.habilitabotao(cbInteragir,botNao,botSim);
    	}
    }
    
    class irOuvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		new PracaGui().abrir();
    		EstalagemGUI.this.dispose();
    		
    	}
    }
    
    class SimOuvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		try {
				controlador.dormir(EstalagemGUI.this, taDescricao);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		
    	}
    }
    
    class NaoOuvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		 botNao.setVisible(false);
    	     botSim.setVisible(false);
    		
    		
    	}
    }
    
    class dinheiroOuvinte implements ActionListener{
    	@Override
    	public void actionPerformed(ActionEvent ev){
    		
    	}
    	
    }
    
    
    
    
    
    
    
    
    
    
    
    
    public  void abrir() {
        EstalagemGUI window = new EstalagemGUI();
        window.setLocationRelativeTo(null);
        if (controlador.NomeHeroi(null).equals(null) ){
        	
        }else{
        	window.tfMensagem.setText("Voce esta jogando como " + controlador.NomeHeroi(null).toUpperCase());
        }
        controlador.LugarHeroi("estalagem");
        window.setTitle("Estalagem");
        window.botNao.setVisible(false);
        window.botSim.setVisible(false);
        window.pack();
        window.setVisible(true);
        controlador.Instrucoes("estalagem",window.taDescricao);
        controlador.ListarOpcoes("estalagem", window.cbOlhar, window.cbInteragir);
    }
}

















class EstalagemLayout implements LayoutManager {

    public EstalagemLayout() {
    }

    public void addLayoutComponent(String name, Component comp) {
    }

    public void removeLayoutComponent(Component comp) {
    }

    public Dimension preferredLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);

        Insets insets = parent.getInsets();
        dim.width = 683 + insets.left + insets.right;
        dim.height = 439 + insets.top + insets.bottom;

        return dim;
    }

    public Dimension minimumLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);
        return dim;
    }

    public void layoutContainer(Container parent) {
        Insets insets = parent.getInsets();

        Component c;
        c = parent.getComponent(0);
        if (c.isVisible()) {c.setBounds(insets.left+250,insets.top+32,216,56);}
        c = parent.getComponent(1);
        if (c.isVisible()) {c.setBounds(insets.left+144,insets.top+384,400,24);}
        c = parent.getComponent(2);
        if (c.isVisible()) {c.setBounds(insets.left+32,insets.top+104,512,136);}
        c = parent.getComponent(3);
        if (c.isVisible()) {c.setBounds(insets.left+32,insets.top+256,104,24);}
        c = parent.getComponent(4);
        if (c.isVisible()) {c.setBounds(insets.left+32,insets.top+296,104,24);}
        c = parent.getComponent(5);
        if (c.isVisible()) {c.setBounds(insets.left+32,insets.top+336,104,24);}
        c = parent.getComponent(6);
        if (c.isVisible()) {c.setBounds(insets.left+560,insets.top+104,96,24);}
        c = parent.getComponent(7);
        if (c.isVisible()) {c.setBounds(insets.left+560,insets.top+384,96,24);}
        c = parent.getComponent(8);
        if (c.isVisible()) {c.setBounds(insets.left+152,insets.top+256,72,24);}
        c = parent.getComponent(9);
        if (c.isVisible()) {c.setBounds(insets.left+152,insets.top+296,72,24);}
        c = parent.getComponent(10);
        if (c.isVisible()) {c.setBounds(insets.left+152,insets.top+336,72,24);}
        c = parent.getComponent(11);
        if (c.isVisible()) {c.setBounds(insets.left+448,insets.top+256,96,24);}
        c = parent.getComponent(12);
        if (c.isVisible()) {c.setBounds(insets.left+448,insets.top+296,96,24);}
        c = parent.getComponent(13);
        if (c.isVisible()) {c.setBounds(insets.left+32,insets.top+384,104,24);}
    }
}