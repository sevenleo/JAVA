package modelo;

public interface vaiVemItem {
	public boolean diminuiQtItem(Item a);
	public boolean aumentaQtItem(Item a);

}
