package modelo;

import java.io.Serializable;

public class Pergunta implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String pergunta;
	private String[] opcoes =new String[4];
	private Boolean[] respostas=new Boolean[4];
	private int certa;
	public Pergunta(String question, String op1, String op2, String op3, String op4, int answear){
		this.pergunta=question;
		this.opcoes[0]=op1;
		this.opcoes[1]=op2;
		this.opcoes[2]=op3;
		this.opcoes[3]=op4;
		this.certa=answear;
		
		for(int i=0; i<4;i++){
			if(i==answear-1){
				this.respostas[i]=true;
			}else{
				this.respostas[i]=false;
			}
		}
		
	}

	public int getCerta() {
		return certa;
	}

	public String getPergunta() {
		return pergunta;
	}
	public String getOpcoes(int i) {
		return opcoes[i];
	}

	public Boolean getRespostas(int i) {
		return respostas[i];
	}

}
