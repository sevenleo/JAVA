package modelo;

import java.io.Serializable;
import java.util.Random;

public class Desafio implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Pergunta[] perguntas = new Pergunta[5];
		
	public Desafio(){
		perguntas[0]=new Pergunta("Qual dessas n�o � uma lei de newton?","1a lei de newton","2a lei de newton","3a lei de newton","Atravesse sempre no sinal",4);
		perguntas[1]=new Pergunta("Quem n�o � monitor de comp2?", "Rick Martin","Erick Najjar","Gabriel Leite","Leonardo Borba",1);
		perguntas[2]=new Pergunta("Tomate �...","Verde e frito","Assassino","Fruta,","Legume",3);
		perguntas[3]=new Pergunta("Qual Desing Pattern � forever alone?","Strategy","Singleton","Factory","Command",2);
		perguntas[4]=new Pergunta("Qual o nome do cachorro favorito de comp2?","Bidu", "Jujuba","Bambu","Juba",4);
	}
	
	public Pergunta geraRandom(){
		int question = new Random().nextInt(5);
		return this.perguntas[question];

	}
}
