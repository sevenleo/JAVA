package modelo;

import java.io.Serializable;



import java.util.ArrayList;


public class Item implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String nome;
	private double preco;
	private int quantidade;
	
	//construtor
	public Item(String name, double price, int qt){
		this.nome=name;
		this.preco=price;
		this.quantidade=qt;
	}

	//get & set
	public String getNome(){
		return this.nome;
	}
	public double getPrecoNovo(){
		return this.preco;
	}
	public double getPrecoUsado(){
		return (this.preco)/2;
	}
	public int getQuantidade(){
		return this.quantidade;
	}
	public void setZero(){
		this.quantidade=0;
	}
	
	//metodos
	public static ArrayList<Item> geraArrayArmas(){
		ArrayList<Item> coisas = new ArrayList<Item>();
		
		
		Item faca=new Item("Faca", 70.50,5);
		coisas.add(faca);

		Item espada = new Item("Espada", 180.00,10);
		coisas.add(espada);
		
		Item escudo = new Item("Escudo",250.70,6);
		coisas.add(escudo);
		
		Item capacete = new Item("capacete",200.0,2);
		coisas.add(capacete);
		
		
	
		
		
		return coisas;
	}
	
	
	
	private boolean verificaQuantidade(){
		if (this.quantidade>0){
			return true;
		}
		return false;
	}
	public boolean diminuiQuantidade(){
		if(this.verificaQuantidade()){
			this.quantidade--;
			return true;
		}
		return false;
	}
	public void aumentaQuantidade(){
		this.quantidade++;
	}
}
