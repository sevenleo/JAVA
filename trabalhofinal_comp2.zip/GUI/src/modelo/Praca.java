package modelo;

import java.io.Serializable;

public class Praca extends Lugar implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	NPC boneco=new NPC("Bonecos de massa","Bonecos de massa fazendo acrobacias cirscences",null);
	NPC quimera = new NPC("Quimera","Uma quimera com cabeca de leao e corpo de cavalo fazendo quimerices",null);
	NPC velho = new NPC("Velho","Um [velho] com um tabuleiro de xadrez... Parece estar olhando para voce","Voce jogou xadrez com o velho e perdeu FEIO!");
	NPC banco = new NPC("Banco de praca","Um [banco] de praca fedorento","Voce dormiu no banco da praca");
	
	public Praca(){
		setNome("Praca");
		setResponsavel(null);
		setDescricao("Voce esta na Alameda dos Anjos.... \n" +
				"Existem {bonecos de massa} plantando no jardim, \n" +
				"uma {quimera} fazendo acrobacias de circo \n e um [velho] " +
				"sentado no [banco].");
		getCoisas().add(boneco);
		getCoisas().add(quimera);
		getCoisas().add(velho);
		getCoisas().add(banco);
	}

}

