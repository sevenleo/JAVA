package modelo;


import java.io.Serializable;

public class Casa extends Lugar implements Serializable{
	
		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		private NPC Mae = new NPC("Mae","L� est� ela \nMamae querida...","-V� tomar um banho ...");
		private NPC PC = new NPC("PC","Um simples Core2Duo","Que pena esta sem rede ...");
		private NPC Geladeira = new NPC("Geladeira","Agua,leite, arroz e feijao\n esse � o nosso almo�o de cada dia",null);
		
			
		//construtor
		public Casa(){
			setNome("Lar doce Lar");
			setResponsavel(Mae);
			setDescricao("Lar doce Lar");
			getCoisas().add(getResponsavel());
			getCoisas().add(Geladeira);
			getCoisas().add(PC);
			
		}

	}


