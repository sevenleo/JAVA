package modelo;


import java.io.Serializable;
import java.util.ArrayList;
public class Deposito extends Lugar implements vaiVemItem,Serializable{
		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		private NPC martelo = new NPC("Martelo","Um simbolo de regliao paga! Deve ser descendente de Vikings...",null);
		private NPC atendente = new NPC("Atendente","Esse atendente nao parece ser daqui.","Ola! O que deseja?");
		private NPC armarios = new NPC("Armarios","Armarios de metal com cadeado grande, parecem ser seguros.","Voce checou um dos armarios e ele realmente e seguro.");
		private NPC homem = new NPC("Homem","Deve ser algum guerreiro querendo depositar suas conquistas...","A seguranca daqui e confiavel, pode guardar seus pertences sem remorso!");
		
		private ArrayList<Item> armario = new ArrayList<Item>();
			
		//construtor
		public Deposito(){
			setNome("Deposito de itens");
			setResponsavel(atendente);
			setDescricao("Um deposito de itens.\n" +
					"Um lugar muito bom para voce deixar suas " +
					"coisas se estiver carregando muito peso.\nHa [arm�rios] " +
					"por todos os lados. H� um " +
					"[atendente] atr�s da bancada com um grande" +
					"{martelo} no cord�o em seu pescoco.\nFalando com " +
					"ele h� um [homem]");
			getCoisas().add(getResponsavel());
			getCoisas().add(martelo);
			getCoisas().add(homem);
			getCoisas().add(armarios);
			
			
			/*this.armario.add( new Item("dvd",20.0,2));
			this.armario.add( new Item("pipa",20.0,2));*/
			
			this.armario=Item.geraArrayArmas();
			
			//colocando todo o array com quantidade 0;
			for(Item descartavel : this.armario){
				descartavel.setZero();
			}
		}

		//get&set
		public ArrayList<Item> getEstoque(){
			return this.armario;
		} 
		//metodos
		public boolean diminuiQtItem(Item a){
			Item entregue = null;
			for(Item descartavel : this.armario){
				if(descartavel.getNome().equals(a.getNome())){
					entregue=descartavel;
					break;
				}
			}
			if(entregue==null){
				return false;
			}else if(entregue.diminuiQuantidade()){
				return true;
			}else{
				return false;
			}
			
		}
		public boolean aumentaQtItem(Item a){
			Item recebido = null;
			for(Item descartavel : this.armario){
				if(descartavel.getNome().equals(a.getNome())){
					recebido=descartavel;
					break;
				}
			}
			if(recebido==null){
				return false;
			}else {
				recebido.aumentaQuantidade();
				return true;
			}
		}

	}


