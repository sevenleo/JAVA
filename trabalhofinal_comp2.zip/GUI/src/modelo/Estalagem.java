package modelo;

import java.io.Serializable;

public class Estalagem extends Lugar implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int precoQuarto;
	private NPC mulher = new NPC("Mulher","Uma belissima mulher e parece estar sozinha....",null);
	private NPC atendente = new NPC("Atendente","Um homem incirvelmente grande e com uma cicatriz no rosto.... \n Parece que esta trabalhando muito hoje","Ola viajante!\nBem vindo ao Cranio Furado. \nDeseja um quarto por 500dins? \n  (noite = 5segundos)");
	private NPC caneca = new NPC("Caneca de Hidromel","Parece que essa caneca esta me esperando....","Voce bebeu o hidromel, estava gelado e muito gostoso.");
	private NPC mesa = new NPC("Mesa","Mesa de madeira, voce esta tentado a subir na mesa e gritar.","Voce subiu na mesa e comecou a gritar 'Eu sou o rei daqui!' \nTalvez voce tenha tomado muito hidromel.");
		
	//construtor
	public Estalagem(){
		this.precoQuarto=500;
		setNome("Cranio Furado");
		setResponsavel(atendente);
		setDescricao("Voce esta em uma taverna...\n" +
				"O lugar esta cheio e ha um [atendente] no\n" +
				"balcao, uma {mulher} sentada em uma mesa proxima \n" +
				"e uma [caneca de hidromel] em cima de uma [mesa] sem\n " +
				"ninguem.... ");
		getCoisas().add(getResponsavel());
		getCoisas().add(mulher);
		getCoisas().add(caneca);
		getCoisas().add(mesa);
		
	}

	//get&set
	public int getPrecoQuarto(){
		return this.precoQuarto;
	}
	
	
	//metodo
	public boolean dormir(Hero p){
		if(p.verificaDinheiro(this.precoQuarto)){
			p.diminuiDinheiro(this.precoQuarto);
			return true;
		}
		return false;
	}

}
