package modelo;


import java.io.Serializable;
import java.util.ArrayList;


public class Loja extends Lugar implements vaiVemItem,Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private NPC espadas = new NPC("Espadas","Espadas de todos os tipos e tamanhos estao presas nas paredes",null);
	private NPC atendente = new NPC("Atendente","Um homem ja com certa idade tentando vender algumas de suas armas...","Ola jovem guerreiro,  que deseja?");
	private NPC rapaz = new NPC("Guerreiro","Um jovem rapaz...Parece ser um guerreiro","Essa loja possui itens muito bons! Vale a pena comprar aqui.");
	private NPC escudos = new NPC("Escudos","Escudos de todos os tipos e tamanhos estao presos nas paredes","Voce tentou pegar um escudo mas o atendente lhe repreendeu.");
	private ArrayList<Item> estoque = new ArrayList<Item>();
		
	//construtor
	public Loja(){
		
		setNome("LojaGui de Armas");
		
		setResponsavel(atendente);
		setDescricao("LojaGui de armas." +
			"Voce entrou em uma loja armeira... \n" +
			"H� {espadas} e [escudos] nas paredes, \n" +
			"um [atendente] no balcao e \n" +
			"um [rapaz] parado ao canto.");
		getCoisas().add(getResponsavel());
		getCoisas().add(espadas);
		getCoisas().add(escudos);
		getCoisas().add(rapaz);
		
		this.estoque=Item.geraArrayArmas();
		this.estoque.add(new Item("livro sagrado",9999.0,1));
		/*this.estoque.add( new Item("mochila",20.0,2));
		this.estoque.add( new Item("sandalia",10.0,3));
		this.estoque.add( new Item("oculos",50.0,9));*/
		
	}
	

	//get&set
	public ArrayList<Item> getEstoque(){
		return this.estoque;
	} 
	//metodos
	public boolean diminuiQtItem(Item a){
		Item vendido= null;
		for(Item descartavel : this.estoque){
			if(descartavel.getNome().equals(a.getNome())){
				vendido=descartavel;
				break;
			}
		}
		if(vendido==null){
			return false;
		}else if(vendido.diminuiQuantidade()){
			return true;
		}else{
			return false;
		}
	}
	public boolean aumentaQtItem(Item a){
		Item vendidoLoja = null;
		for(Item descartavel : this.estoque){
			if(descartavel.getNome().equals(a.getNome())){
				vendidoLoja=descartavel;
				break;
			}
		}
		if(vendidoLoja==null){
			return false;
		}else {
			vendidoLoja.aumentaQuantidade();
			return true;
		}
	}
}

