package modelo;

import java.io.Serializable;


public class NPC implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String nome;
	private String descricao;
	private String interacao;
	
	public NPC(String nome, String descricao, String interacao) {
		this.nome = nome;
		this.descricao = descricao;
		this.interacao=interacao;
	}
	
	public String getInteracao(){
		return this.interacao;
	}
	public String getDescricao(){
		return this.descricao;
	}
	public String getNome(){
		return this.nome;
	}
	
}
