package modelo;

import java.io.Serializable;

public class Hospital extends Lugar implements Serializable{
	
		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		private NPC maca = new NPC("Maca","Uma maca em bom estado....",null);
		private NPC enfermeira = new NPC("Enfermeira","Que linda enfermeira parada logo ali...\nMas nao tenho tempo para paqueras agora","Ola meu querido, deseja reparar seus ferimentos?\n Ter� que esperar um pouco na fila ...");
		private NPC senhora = new NPC("Senhora","Uma senhora ja com certa idade acompanhada de uma crian�a...","Aqui as pessoas sao muito prestativas.\n Ve aquela mocinha ali?! *aponta pra enfermeira* e um amor de pessoa!");
		private NPC crianca = new NPC("Crianca","Crianca melequenta, mas fofinha.","*UNHEEEEE* - A crianca se assustou com a sua cara feia.");
			
		//construtor
		public Hospital(){
			setNome("HospitalGUI da cidade");
			setResponsavel(enfermeira);
			setDescricao("O hospital da cidade.\n" +
					"Ha uma [enfermeira] proxima a uma {maca}\n" +
					"e uma [senhora] sentada em um banco segurando uma [crianca].");
			getCoisas().add(getResponsavel());
			getCoisas().add(senhora);
			getCoisas().add(crianca);
			getCoisas().add(maca);
			
		}

		//metodos
		public String cuidar(Hero p){
			return "\n\nVoce esta curado";
		}

	}

