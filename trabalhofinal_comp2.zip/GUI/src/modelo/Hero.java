package modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;
public class Hero implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String nome;
	private int dinheiro;
	private int quantidadeItens;
	String lugar;
	ArrayList<Item> inventario = new ArrayList<Item>();
	
	//construtor
	public Hero(){
		this.nome="Ze Ninguem";
		this.setDinheiro(545);
		this.inventario=Item.geraArrayArmas();
		this.inventario.add(new Item("Armadura", 1000.0, 1));
		this.lugar="praca";
	}
	
	//get & set
	public String getLugar() {
		return lugar;
	}

	public void setLugar(String lugar) {
		this.lugar = lugar;
	}
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getDinheiro() {
		return dinheiro;
	}
	public void setDinheiro(int dinheiro) {
		this.dinheiro = dinheiro;
	}
	public int getQuantidadeItens() {
		return quantidadeItens;
	}
	public void setQuantidadeItens(int quantidadeItens) {
		this.quantidadeItens = quantidadeItens;
	}
	public ArrayList<Item> getInventario() {
		return inventario;
	}
	public void setInventario(ArrayList<Item> inventario) {
		this.inventario = inventario;
	}
	

	//metodos

	public boolean verificaDinheiro(double x){
		if(this.getDinheiro()<x){
			return false;
		}
		return true;
		
	}
	public boolean diminuiDinheiro(double x){
		if(this.getDinheiro()<x){
			this.dinheiro-=x;
			return true;
		}
		return false;
	}
	private void aumentaDinheiro(double x){
		this.dinheiro+=x;
	}
	public static double trabalha(){
		Random gerador = new Random();
		int trabalho=gerador.nextInt(8)+1;
		double valor=trabalho*12.3;
		return valor;
	}
	public boolean vendeItem(Item a, vaiVemItem onde){
		Item vendido = null;
		for(Item descartavel : this.inventario){
			if(descartavel.getNome().equals(a.getNome())){
				vendido=descartavel;
				break;
			}
		}
		if(vendido==null){
			return false;
		}else if(vendido.diminuiQuantidade()){
			if(onde.aumentaQtItem(a)){
				this.aumentaDinheiro(vendido.getPrecoUsado());
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
		
	}
	public boolean compraItem(Item a, vaiVemItem onde){
		Item comprado = null;
		if(this.verificaDinheiro(a.getPrecoNovo())){
			for(Item descartavel : this.inventario){
				if(descartavel.getNome().equals(a.getNome())){
					comprado=descartavel;
					break;
				}
			}
		}else{ 
			return false;
		}
		if(comprado==null){
			return false;
		}else {
			if(onde.diminuiQtItem(a)){
				comprado.aumentaQuantidade();
				this.diminuiDinheiro(comprado.getPrecoNovo());
				return true;
			}else{
				return false;
			}
		}
	}
	public boolean depositaItem(Item a, vaiVemItem onde){
		Item depositado = null;
		for(Item descartavel : this.inventario){
			if(descartavel.getNome().equals(a.getNome())){
				depositado=descartavel;
				break;
			}
		}
		if(depositado==null){
			return false;
		}else if(depositado.diminuiQuantidade()){
			onde.aumentaQtItem(depositado);
			return true;
		}else{
			return false;
		}
		
	}
	public boolean pegaItem(Item a, vaiVemItem onde){
		Item pego = null;
		for(Item descartavel : this.inventario){
			if(descartavel.getNome().equals(a.getNome())){
				pego=descartavel;
				break;
			}
		}
		if(pego==null){
			return false;
		}else if(onde.diminuiQtItem(a)){
			pego.aumentaQuantidade();
			return true;
		}else{
			return false;
		}
	}

}