package modelo;

import java.io.Serializable;

import Controlador.ControleRemoto;


public class Jogo implements ControleRemoto,Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String sobre ;
	private Hero heroi;
	private Loja loja;
	private Praca praca;
	private Hospital hospital;
	private Deposito deposito;
	private Estalagem estalagem;
	private Casa casa;
	
	



	public Jogo(){
		sobre = "Modo de jogar:\nO jogo � composto de diversos lugares a se explorar.\nExistem botoes expalhados pela janela do jogo que\nexecutam a�oes do personagem.\nO inventario do personagemtambem pode ser visto nas telas.";
		heroi = new Hero();
		loja = new Loja();
		praca = new Praca();
		estalagem = new Estalagem();
		hospital = new Hospital();
		deposito = new Deposito();
		casa = new Casa();
	}


	
	public Casa getCasa() {
		return casa;
	}



	public void setCasa(Casa casa) {
		this.casa = casa;
	}



	public Hospital getHospital() {
		return hospital;
	}



	public void setHospital(Hospital hospital) {
		this.hospital = hospital;
	}



	public Deposito getDeposito() {
		return deposito;
	}



	public void setDeposito(Deposito deposito) {
		this.deposito = deposito;
	}



	public Estalagem getEstalagem() {
		return estalagem;
	}



	public void setEstalagem(Estalagem estalagem) {
		this.estalagem = estalagem;
	}



	public Loja getLoja() {
		return loja;
	}


	public void setLoja(Loja loja) {
		this.loja = loja;
	}
	
	
	public String getSobre() {
		return sobre;
	}


	public void setSobre(String sobre) {
		this.sobre = sobre;
	}


	public Hero getHeroi() {
		return heroi;
	}


	public void setHeroi(Hero heroi) {
		this.heroi = heroi;
	}
	public Praca getPraca() {
		return praca;
	}
	public void setPraca(Praca praca) {
		this.praca = praca;
	}

	
	
}
