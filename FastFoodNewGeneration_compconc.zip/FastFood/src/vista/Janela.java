package vista;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import controlador.GerenciadorFila;
import controlador.Registrador;
import controlador.Simulador;
import modelo.Caixa;
import modelo.Cozinheiro;
import modelo.Entregador;
import modelo.Estoque;
import modelo.FilaAguarde;
import modelo.FilaCliente;
import modelo.FilaPedido;
import modelo.FilaPronto;
import javax.swing.JButton;

@SuppressWarnings("serial")
public class Janela extends JFrame {

	private JPanel contentPane; //painel principal
	
	JTextArea textAreaFilaCliente; //textarea fila de cliente
	JTextArea textAreaFilaPedido; //textarea fila de pedido
	JTextArea textAreaFilaPronto; //textarea fila de pronto
	JTextArea textAreaFilaAguarde; //textarea fila de aguarde
	
	JTextArea textAreaCaixa0, textAreaCaixa1, textAreaCaixa2,
		textAreaCaixa3, textAreaCaixa4, textAreaCaixa5; //textarea dos caixas
	JTextArea textAreaCozin0, textAreaCozin1, textAreaCozin2; //textarea dos cozinheiros
	JTextArea textAreaEntreg0, textAreaEntreg1; //textarea dos entregadores
	
	JTextArea textAreaEstoque; //textarea estoque
	
	JLabel lblFilaCliente; //label fila de cliente
	JLabel lblFilaPedido; //label fila de pedido
	JLabel lblFilaPronto; //label fila de pronto
	JLabel lblFilaAguarde; //label fila de aguarde
	JLabel lblCaixas; //label caixas
	JLabel lblCozinheiros; //label cozinheiros
	JLabel lblEntregadores; //label entregadores
	JLabel lblEstoque; //label entregadores
	
	JButton btnParar; //botao salvar relatorio
	
	FilaCliente filaCliente; //acesso a fila de cliente
	FilaPedido filaPedido; //acesso a fila de pedido
	FilaPronto filaPronto; //acesso a fila de pronto
	FilaAguarde filaAguarde; //acesso a fila de aguarde
	
	Estoque estoque; //acesso ao estoque
	
	Caixa[] caixa;
	Cozinheiro[] cozinheiro;
	Entregador[] entregador;
	int ContaMSG=1;
	
	private static Janela singleton = null;
	
	public static Janela getInstance(){
		if (singleton == null){
			singleton = new Janela();
		}
		return singleton;
	}
	public void AlertaRegistro(){
		try {
			new Registrador();
			JOptionPane.showMessageDialog(contentPane, "O registro foi salvo com sucesso!","Aviso",JOptionPane.PLAIN_MESSAGE);
		} catch (IOException e1) {
			JOptionPane.showMessageDialog(contentPane, "Um problema ocorreu ao tentar salvar o registro!","Erro",JOptionPane.ERROR_MESSAGE);
		}
	}

	public void BemVindos(){
		JOptionPane.showMessageDialog(contentPane, "Sejam bem vindos ao New Generation","",JOptionPane.PLAIN_MESSAGE);	
	}
	
	
	public static void main(String[] args) {
		Simulador s = Simulador.getInstance();
		Janela.getInstance(); //inicializa a janela
		s.start();
		//s.run(); //� o par ideal para simulador.interrupt()
		
	}
	
	private Janela() {
		//propriedades das threads
		caixa = Simulador.getInstance().getCaixa();
		cozinheiro = Simulador.getInstance().getCozinheiro();
		entregador = Simulador.getInstance().getEntregador();
		//propriedades das threads
		
		//propriedades do estoque
		estoque = Estoque.getInstance();
		//propriedades do estoque
		
		//propriedades das filas
		filaCliente = GerenciadorFila.getInstance().getFilaCliente();
		filaPedido = GerenciadorFila.getInstance().getFilaPedido();
		filaPronto = GerenciadorFila.getInstance().getFilaPronto();
		filaAguarde = GerenciadorFila.getInstance().getFilaAguarde();
		//propriedades das filas
		
		//propriedades da janela
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(100, 100, 549, 574);
		this.setTitle("Fast Food New Generation");
		//propriedades da janela
		
		//propriedades do painel
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setContentPane(contentPane);
		contentPane.setLayout(null);
		//propriedades do painel
		
		//propriedades das filas
		textAreaFilaCliente = new JTextArea();
		textAreaFilaCliente.setEditable(false);
		textAreaFilaCliente.setBounds(10, 36, 100, 240);
		contentPane.add(textAreaFilaCliente);
		
		textAreaFilaPedido = new JTextArea();
		textAreaFilaPedido.setEditable(false);
		textAreaFilaPedido.setBounds(150, 36, 100, 240);
		contentPane.add(textAreaFilaPedido);
		
		textAreaFilaPronto = new JTextArea();
		textAreaFilaPronto.setEditable(false);
		textAreaFilaPronto.setBounds(290, 36, 100, 240);
		contentPane.add(textAreaFilaPronto);
		
		textAreaFilaAguarde = new JTextArea();
		textAreaFilaAguarde.setEditable(false);
		textAreaFilaAguarde.setBounds(430, 36, 100, 240);
		contentPane.add(textAreaFilaAguarde);
		//propriedades das filas
		
		//propriedades das informacoes das caixas
		textAreaCaixa0 = new JTextArea();
		textAreaCaixa0.setEditable(false);
		textAreaCaixa0.setBounds(10, 325, 100, 20);
		contentPane.add(textAreaCaixa0);
		
		textAreaCaixa1 = new JTextArea();
		textAreaCaixa1.setEditable(false);
		textAreaCaixa1.setBounds(10, 355, 100, 20);
		contentPane.add(textAreaCaixa1);
		
		textAreaCaixa2 = new JTextArea();
		textAreaCaixa2.setEditable(false);
		textAreaCaixa2.setBounds(10, 385, 100, 20);
		contentPane.add(textAreaCaixa2);
		
		textAreaCaixa3 = new JTextArea();
		textAreaCaixa3.setEditable(false);
		textAreaCaixa3.setBounds(10, 415, 100, 20);
		contentPane.add(textAreaCaixa3);
		
		textAreaCaixa4 = new JTextArea();
		textAreaCaixa4.setEditable(false);
		textAreaCaixa4.setBounds(10, 445, 100, 20);
		contentPane.add(textAreaCaixa4);
		
		textAreaCaixa5 = new JTextArea();
		textAreaCaixa5.setEditable(false);
		textAreaCaixa5.setBounds(10, 475, 100, 20);
		contentPane.add(textAreaCaixa5);
		//propriedades das informacoes das caixas
		
		//propriedades das informacoes dos cozinheiros
		textAreaCozin0 = new JTextArea();
		textAreaCozin0.setEditable(false);
		textAreaCozin0.setBounds(150, 325, 100, 20);
		contentPane.add(textAreaCozin0);
		
		textAreaCozin1 = new JTextArea();
		textAreaCozin1.setEditable(false);
		textAreaCozin1.setBounds(150, 355, 100, 20);
		contentPane.add(textAreaCozin1);
		
		textAreaCozin2 = new JTextArea();
		textAreaCozin2.setEditable(false);
		textAreaCozin2.setBounds(150, 385, 100, 20);
		contentPane.add(textAreaCozin2);
		//propriedades das informacoes dos cozinheiros
		
		//propriedades das informacoes dos entregadores
		textAreaEntreg0 = new JTextArea();
		textAreaEntreg0.setEditable(false);
		textAreaEntreg0.setBounds(290, 325, 100, 20);
		contentPane.add(textAreaEntreg0);
		
		textAreaEntreg1 = new JTextArea();
		textAreaEntreg1.setEditable(false);
		textAreaEntreg1.setBounds(290, 355, 100, 20);
		contentPane.add(textAreaEntreg1);
		//propriedades das informacoes dos entregadores
		
		//propriedades das inforamcoes do estoque
		textAreaEstoque = new JTextArea();
		textAreaEstoque.setEditable(false);
		textAreaEstoque.setBounds(430, 325, 100, 150);
		contentPane.add(textAreaEstoque);
		//propriedades das inforamcoes do estoque
		
		//labels
		lblFilaCliente = new JLabel("Fila de Clientes");
		lblFilaCliente.setHorizontalAlignment(SwingConstants.CENTER);
		lblFilaCliente.setBounds(10, 11, 100, 14);
		contentPane.add(lblFilaCliente);
		
		lblFilaPedido = new JLabel("Fila de Pedidos");
		lblFilaPedido.setHorizontalAlignment(SwingConstants.CENTER);
		lblFilaPedido.setBounds(150, 11, 100, 14);
		contentPane.add(lblFilaPedido);
		
		lblFilaPronto = new JLabel("Fila de Pronto");
		lblFilaPronto.setHorizontalAlignment(SwingConstants.CENTER);
		lblFilaPronto.setBounds(290, 11, 100, 14);
		contentPane.add(lblFilaPronto);
		
		lblFilaAguarde = new JLabel("Fila de Aguarde");
		lblFilaAguarde.setHorizontalAlignment(SwingConstants.CENTER);
		lblFilaAguarde.setBounds(430, 11, 100, 14);
		contentPane.add(lblFilaAguarde);
		
		lblCaixas = new JLabel("Caixas");
		lblCaixas.setHorizontalAlignment(SwingConstants.CENTER);
		lblCaixas.setBounds(10, 300, 100, 14);
		contentPane.add(lblCaixas);
		
		lblCozinheiros = new JLabel("Cozinheiros");
		lblCozinheiros.setHorizontalAlignment(SwingConstants.CENTER);
		lblCozinheiros.setBounds(150, 300, 100, 14);
		contentPane.add(lblCozinheiros);
		
		lblEntregadores = new JLabel("Entregadores");
		lblEntregadores.setHorizontalAlignment(SwingConstants.CENTER);
		lblEntregadores.setBounds(290, 300, 100, 14);
		contentPane.add(lblEntregadores);
		
		lblEstoque = new JLabel("Estoque");
		lblEstoque.setHorizontalAlignment(SwingConstants.CENTER);
		lblEstoque.setBounds(430, 300, 100, 14);
		contentPane.add(lblEstoque);
		//labels
		
		//botao para salvar o relatorio
		btnParar = new JButton("Encerrar");
		btnParar.setBounds(439, 512, 91, 23);
		btnParar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Simulador.getInstance().Fim();
				JOptionPane.showMessageDialog(contentPane, "-Encerrando as atividades\n-Salvando registros","Fim do expediente!",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		contentPane.add(btnParar);
		//botao para parar o simulador
		
		Timer t = new Timer(100, new Update()); //dispara o update
		t.start();
		
		this.setVisible(true); //torna a janela visivel
	}
	
	class Update implements ActionListener{ //classe do update
		
		Update(){}
		
		@Override
		public void actionPerformed(ActionEvent e) { //acao a ser feita no update
			textAreaFilaCliente.setText(filaCliente.toString()); //atualiza a fila de cliente
			textAreaFilaPedido.setText(filaPedido.toString()); //atualiza a fila de pedido
			textAreaFilaPronto.setText(filaPronto.toString()); //atualiza a fila de pronto
			textAreaFilaAguarde.setText(filaAguarde.toString()); //atualiza a fila de aguarde
			
			textAreaCaixa0.setText(caixa[0].toString()); //atualiza o caixa 1
			textAreaCaixa1.setText(caixa[1].toString()); //atualiza o caixa 2
			textAreaCaixa2.setText(caixa[2].toString()); //atualiza o caixa 3 
			textAreaCaixa3.setText(caixa[3].toString()); //atualiza o caixa 4
			textAreaCaixa4.setText(caixa[4].toString()); //atualiza o caixa 5
			textAreaCaixa5.setText(caixa[5].toString()); //atualiza o caixa 6
			
			textAreaCozin0.setText(cozinheiro[0].toString()); //atualiza o cozinheiro 1
			textAreaCozin1.setText(cozinheiro[1].toString()); //atualiza o cozinheiro 2
			textAreaCozin2.setText(cozinheiro[2].toString()); //atualiza o cozinheiro 3
			
			textAreaEntreg0.setText(entregador[0].toString()); //atualiza o entregador 1
			textAreaEntreg1.setText(entregador[1].toString()); //atualiza o entregador 2
			
			textAreaEstoque.setText(estoque.toString()); //atualiza o estoque
			
			if(!Simulador.getInstance().isAlive() && GerenciadorFila.getInstance().FimDasFilas() && ContaMSG==1) {
				ContaMSG--;
				AlertaRegistro();
			}
			
		}
		
	}
}
