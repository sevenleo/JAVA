package controlador;

import modelo.FilaAguarde;
import modelo.FilaCliente;
import modelo.FilaPedido;
import modelo.FilaPronto;

public class GerenciadorFila {

	private FilaCliente filaCliente;
	private FilaPedido filaPedido;
	private FilaPronto filaPronto;
	private FilaAguarde filaAguarde;
	private static GerenciadorFila singleton = null;
	
	private GerenciadorFila(){
			filaCliente = new FilaCliente();
			filaPedido = new FilaPedido();
			filaPronto = new FilaPronto();
			filaAguarde = new FilaAguarde();
	}
	public static GerenciadorFila getInstance(){
		if (singleton == null){
			singleton = new GerenciadorFila();
		}
		return singleton;
	}
	
	
	public FilaCliente getFilaCliente(){
		return this.filaCliente;
	}
	public FilaPedido getFilaPedido(){
		return this.filaPedido;
	}
	public FilaPronto getFilaPronto(){
		return this.filaPronto;
	}
	public FilaAguarde getFilaAguarde(){
		return this.filaAguarde;
	}
	public boolean FimDasFilas(){
		if(filaCliente.getFila().isEmpty() &&
			filaAguarde.getFila().isEmpty() &&
			filaPedido.getFila().isEmpty() &&
			filaPronto.getFila().isEmpty() ) return true;
		else return false;
		
	}
	public boolean Fim(){
		while(!GerenciadorFila.getInstance().FimDasFilas()){}
		return true;
	}
}
