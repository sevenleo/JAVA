package controlador;


import java.util.ArrayList;

import vista.Janela;

import modelo.Caixa;
import modelo.Cliente;
import modelo.Cozinheiro;
import modelo.Entregador;
import modelo.Pedido;
import modelo.Refrigerante;
import modelo.Sanduiche;

public class Simulador extends Thread{

	private static Simulador singleton = null;
	private GerenciadorFila gerenciador;
	private Caixa[] caixa;
	private Cozinheiro[] cozinheiro;
	private Entregador[] entregador;
	private int contador;
	private boolean funcionando=true;
	
	
	private Simulador(){
		int i = 0;
		
		this.contador = 0;
		this.gerenciador = GerenciadorFila.getInstance();
		
		caixa = new Caixa[6];
		for (i = 0; i < 6; i++){
			caixa[i] = new Caixa(i);
		}
		
		cozinheiro = new Cozinheiro[3];
		for (i = 0; i < 3; i++){
			cozinheiro[i] = new Cozinheiro(i);
		}
		
		entregador = new Entregador[2];
		for (i = 0; i < 2; i++){
			entregador[i] = new Entregador(i);
		}
		
	}
	
	public static Simulador getInstance(){
		if (singleton == null){
			singleton = new Simulador();
		}
		return singleton;
	}
	
	public GerenciadorFila getGerenciador(){
		return gerenciador;
	}
	public Caixa[] getCaixa(){
		return caixa;
	}
	public Cozinheiro[] getCozinheiro(){
		return cozinheiro;
	}
	public Entregador[] getEntregador(){
		return entregador;
	}
	
	public boolean verifica(){
		int i = 0;
		for (i = 0; i < 6; i++){
			System.out.println("-----"+caixa[i].getState().toString());
		}
		
		for (i = 0; i < 3; i++){
		}
		
		for (i = 0; i < 2; i++){

		}
		return true;
	}


	public void Fim(){
		//this.stop();
		this.interrupt(); //nao funciona, deveria funcionar se usassemos simulador.run()
		if( funcionando && gerenciador.FimDasFilas()) {
			funcionando=false;
			Janela.getInstance().AlertaRegistro();	
		}
	}
	
	@Override
	public void run(){
		try {
			int i;
			int cont = 0;
			int xPedidos=5;
			int xDinheiro=100;
			int dinheiro, sanduicheID, refrigeranteID;
			int qtdrefrigerantes,qtdsanduiches;
			ArrayList<Sanduiche> sanduiches;
			ArrayList<Refrigerante> refrigerantes;

			//randomiza a ordem de abertura dos caixas!
			i=(int)(Math.random()*6);
			while (cont < 6){
				cont++;
				if (i >= 6){
					i = 6-i;
				}
				caixa[i].start();
				Thread.sleep(100); //solucao para uma simulacao melhor
				i++;
			}
			
			for (i = 0; i < 2; i++){
				entregador[i].start();
				Thread.sleep(100); //solucao para uma simulacao melhor
			}
			
			for (i = 0; i < 3; i++){
				cozinheiro[i].start();
				Thread.sleep(100); //solucao para uma simulacao melhor
			}

			while(true){ //while(contador < 30){ //gera ate 30 clientes 

				if(gerenciador.getFilaCliente().getFila().size() < 15){
					System.out.println("* Adicionei o cliente "+contador);
					System.out.println(GerenciadorFila.getInstance().getFilaAguarde().toString());

					
					dinheiro = (int)(Math.random()*xDinheiro);
					qtdrefrigerantes = (int)(1+Math.random()*xPedidos);
					qtdsanduiches = (int)(1+Math.random()*xPedidos);
					sanduiches = new ArrayList<Sanduiche>();
					refrigerantes = new ArrayList<Refrigerante>();
					
					
					for (int j = 0; j < qtdsanduiches; j++) {
						sanduicheID = (int)(1 + Math.random()*5);
						sanduiches.add(new Sanduiche(sanduicheID));
					}
					for (int k = 0; k < qtdrefrigerantes; k++) {
						refrigeranteID = (int)(6 + Math.random()*3);
						refrigerantes.add(new Refrigerante(refrigeranteID));
					}
					
					gerenciador.getFilaCliente().add(new Cliente(contador, new Pedido(contador, sanduiches, refrigerantes), dinheiro));
					contador++;
					//colocar sleep caso queira retardar o simulador
				}
				Thread.sleep(50);
			}
			
		}
		catch(InterruptedException ie){
			
		}
	}
}
