package controlador;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;

import modelo.Caixa;
import modelo.Estoque;

public class Registrador {
	
	private final String eol = System.getProperty("line.separator");
	private FileWriter file;
	private Caixa[] caixa;
	private Estoque estoque;
	
	public Registrador() throws IOException{
		this.caixa = Simulador.getInstance().getCaixa();
		this.estoque = Estoque.getInstance();

		file = new FileWriter("registro.txt");
		file.write(Calendar.getInstance().getTime()+eol); 
		file.write(eol);
		file.write("Registro di�rio do Fast Food New Generation"+eol);
		file.write(eol);
		file.write("Registro dos caixas:"+eol);
		file.write("Caixa 1: R$ "+caixa[0].getDinheiro()+eol);
		file.write("Caixa 2: R$ "+caixa[1].getDinheiro()+eol);
		file.write("Caixa 3: R$ "+caixa[2].getDinheiro()+eol);
		file.write("Caixa 4: R$ "+caixa[3].getDinheiro()+eol);
		file.write("Caixa 5: R$ "+caixa[4].getDinheiro()+eol);
		file.write(eol);
		file.write("Registro do estoque:"+eol);
		file.write(estoque.toStringFile());
		file.close();
	}
}
