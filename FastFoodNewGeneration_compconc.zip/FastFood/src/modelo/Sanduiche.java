package modelo;

import java.util.ArrayList;

public class Sanduiche {

	public static final int ID_HAMBURGUER = 1;
	public static final int ID_XBURGUER = 2;
	public static final int ID_XBACON = 3;
	public static final int ID_XSALADA = 4;
	public static final int ID_XFRANGO = 5;
	
	private int id;
	private String nome;
	private double preco;
	private ArrayList<Integer> materiaPrimaUsada;
	
	public Sanduiche(int id){
		materiaPrimaUsada = new ArrayList<Integer>();
		
		switch (id){
		case ID_HAMBURGUER:
			this.id = ID_HAMBURGUER;
			this.nome = "Hamb�rguer";
			this.preco = 3.00;
			this.materiaPrimaUsada.add(Ingrediente.PAO);
			this.materiaPrimaUsada.add(Ingrediente.CARNE);
		break;
		case ID_XBURGUER:
			this.id = ID_XBURGUER;
			this.nome = "X-B�rguer";
			this.preco = 4.00;
			this.materiaPrimaUsada.add(Ingrediente.PAO);
			this.materiaPrimaUsada.add(Ingrediente.CARNE);
			this.materiaPrimaUsada.add(Ingrediente.QUEIJO);
		break;
		case ID_XBACON:
			this.id = ID_XBACON;
			this.nome = "X-Bacon";
			this.preco = 5.00;
			this.materiaPrimaUsada.add(Ingrediente.PAO);
			this.materiaPrimaUsada.add(Ingrediente.CARNE);
			this.materiaPrimaUsada.add(Ingrediente.QUEIJO);
			this.materiaPrimaUsada.add(Ingrediente.BACON);
		break;
		case ID_XSALADA:
			this.id = ID_XSALADA;
			this.nome = "X-Salada";
			this.preco = 4.50;
			this.materiaPrimaUsada.add(Ingrediente.PAO);
			this.materiaPrimaUsada.add(Ingrediente.CARNE);
			this.materiaPrimaUsada.add(Ingrediente.QUEIJO);
			this.materiaPrimaUsada.add(Ingrediente.SALADA);
		break;
		case ID_XFRANGO:
			this.id = ID_XFRANGO;
			this.nome = "X-Frango";
			this.preco = 3.50;
			this.materiaPrimaUsada.add(Ingrediente.PAO);
			this.materiaPrimaUsada.add(Ingrediente.FRANGO);
			this.materiaPrimaUsada.add(Ingrediente.QUEIJO);
		break;
		}
	}
	
	public int getId(){
		return id;
	}
	public String getNome(){
		return nome;
	}
	public double getPreco(){
		return preco;
	}
	public ArrayList<Integer> getMateriaPrimaUsada(){
		return materiaPrimaUsada;
	}
}
