package modelo;

import controlador.GerenciadorFila;

public class Caixa extends Thread{

	private int id;
	private Cliente cliente;
	private FilaCliente filaCliente;
	private FilaPedido filaPedido;
	private FilaAguarde filaAguarde;
	private Estoque estoque;
	private double dinheiro;
	
	public Caixa(int id){
		this.id = id;
		this.filaCliente = GerenciadorFila.getInstance().getFilaCliente();
		this.filaPedido = GerenciadorFila.getInstance().getFilaPedido();
		this.filaAguarde = GerenciadorFila.getInstance().getFilaAguarde();
		this.estoque = Estoque.getInstance();
		this.dinheiro = 0;
		this.cliente = null;
	}
	
	@Override
	public void run() {//atividade de um caixa
		try{
			while(true){
				if (cliente == null){//se nao possuir nenhum cliente, tenta pegar um na fila
					cliente = filaCliente.poll(this.id);
					if (cliente != null){//se pegou um cliente
						Thread.sleep(1000);//aparece na simulacao
						if (this.avaliaPedido(cliente,cliente.getPedido()) == true){ //se possuir dinheiro para comprar o lanche
							if(estoque.verifica(this.id, cliente.getPedido().getMateriaPrimaUsada()) == true){//checa o estoque
								filaPedido.add(cliente.getPedido());
								filaAguarde.add(cliente.getId(), cliente);
								this.dinheiro += cliente.getPedido().getPreco();
							}
							else{
								//TODO:banir pedido
							}
						}
						cliente = null;
					}
				}
				Thread.sleep(1000);//tenta pegar um cliente a cada intervalo de tempo
			}
		}
		catch (InterruptedException ie) {
		}
	}
	
	private boolean avaliaPedido(Cliente c, Pedido p){
		if (c.getDinheiro() >= p.getPreco()){
			return true;
		}
		return false;
	}
	
	public double getDinheiro(){
		return this.dinheiro;
	}
	
	@Override
	public String toString(){
		if (cliente != null){
			return "Cliente "+cliente.getId();
		}
		return "";
	}
}