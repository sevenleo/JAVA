package modelo;

import controlador.GerenciadorFila;

public class Entregador extends Thread{

	private long id;
	private Pedido pedidoPronto;
	private FilaPronto filaPronto;
	private FilaAguarde filaAguarde;
	
	public Entregador(int id){
		this.id = id;
		this.filaPronto = GerenciadorFila.getInstance().getFilaPronto();
		this.filaAguarde = GerenciadorFila.getInstance().getFilaAguarde();
		this.pedidoPronto = null;
	}

	public long getId(){
		return this.id;
	}
	
	@Override
	public void run() {
		try{
			while(true){
				if (pedidoPronto == null){//se nao possuir nenhum pedido pronto, tenta pegar um na fila
					pedidoPronto = filaPronto.poll((int)this.id);
					if (pedidoPronto != null){//se pegou um pedido pronto
						Thread.sleep(500);//aparece na simulacao
						filaAguarde.remove(pedidoPronto.getIdCliente());//entrega o pedido
						pedidoPronto = null;
					}
				}
				Thread.sleep(500);
			}
		}
		catch (InterruptedException ie) {
		}
	}
	
	@Override
	public String toString(){
		if (pedidoPronto != null){
			return "Pedido "+pedidoPronto.getIdCliente();
		}
		return "";
	}
}