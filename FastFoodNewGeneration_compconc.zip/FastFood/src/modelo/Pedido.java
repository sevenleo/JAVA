package modelo;

import java.util.ArrayList;

public class Pedido {

	private int idCliente;
	private ArrayList<Sanduiche> sanduiches = new ArrayList<Sanduiche>();
	private ArrayList<Refrigerante> refrigerantes = new ArrayList<Refrigerante>();
	private double preco;
	private ArrayList<Integer> materiaPrimaUsada;
	
	public Pedido(int idCliente,ArrayList<Sanduiche> sanduiches,ArrayList<Refrigerante> refrigerantes){
		this.idCliente = idCliente;
		this.sanduiches = sanduiches;
		this.refrigerantes = refrigerantes;
		this.preco = CalculaPreco();
		this.materiaPrimaUsada = Anexa(sanduiches, refrigerantes);
	}
	
	public double CalculaPreco(){
		double oPreco=0;
		for(Sanduiche s : this.sanduiches){
			oPreco=oPreco+s.getPreco();
		}
		for(Refrigerante r : this.refrigerantes){
			oPreco=oPreco+r.getPreco();
		}
		return oPreco;
	}
	
	public ArrayList<Integer> Anexa(ArrayList<Sanduiche> sanduiches,ArrayList<Refrigerante> refrigerantes){
		ArrayList<Integer> materiaP= new ArrayList<Integer>();
		
		for(Sanduiche s : sanduiches){
			materiaP.addAll(s.getMateriaPrimaUsada());
		}
		for(Refrigerante r : refrigerantes){
			materiaP.add(r.getId());
		}
		
		return materiaP;
		
	}
	
	public int getIdCliente() {
		return idCliente;
	}

	public ArrayList<Sanduiche> getSanduiches() {
		return sanduiches;
	}

	public ArrayList<Refrigerante> getRefrigerantes() {
		return refrigerantes;
	}

	public double getPreco() {
		return preco;
	}

	public ArrayList<Integer> getMateriaPrimaUsada() {
		return materiaPrimaUsada;
	}
	
	@Override
	public String toString(){
		return "Pedido "+this.idCliente;
	}
	
	//Especificacao completa do pedido
	/*@Override
	public String toString(){
		ArrayList<String> sand = new ArrayList<String>();
		ArrayList<String> refri= new ArrayList<String>();
		
		for(Sanduiche s : this.sanduiches){
			sand.add(s.getNome());
		}
		for(Refrigerante r : this.refrigerantes){
			refri.add(r.getNome());
		}
		
		return sand+" + "+refri+" = "+this.getPreco();
	}*/

}
