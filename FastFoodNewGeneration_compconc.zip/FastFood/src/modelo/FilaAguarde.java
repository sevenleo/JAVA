package modelo;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

public class FilaAguarde {

	private HashMap<Integer,Cliente> fila;
	
	public FilaAguarde(){
		fila = new HashMap<Integer,Cliente>();
	}
	
	public HashMap<Integer,Cliente> getFila(){
		return fila;
	}
	
	public void add(Integer i,Cliente c){
		fila.put(i,c);
	}
	
	public void remove(Integer i){
		fila.remove(i);
	}
	
	@Override
	public String toString(){
		Collection<Cliente> c = fila.values();
		Iterator<Cliente> i = c.iterator();
		String str = "";
		
		if (fila.isEmpty() == false){
			while (i.hasNext()){
				str+=i.next().toString()+"\n";
			}
			return str;
		}
		return "";
	}
}
