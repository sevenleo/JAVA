package modelo;

public class Cliente {

	private int id;
	private Pedido pedido;
	private double dinheiro;
	
	public Cliente(int id, Pedido pedido, double dinheiro){
		this.id = id;
		this.pedido = pedido;
		this.dinheiro = dinheiro;
	}
	
	public int getId(){
		return id;
	}
	public Pedido getPedido(){
		return pedido;
	}
	public double getDinheiro(){
		return dinheiro;
	}
	
	@Override
	public String toString(){
		return "Cliente "+this.id;
	}
}
