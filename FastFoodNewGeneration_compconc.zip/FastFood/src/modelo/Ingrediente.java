package modelo;

public abstract class Ingrediente {

	public static final int PAO = 0;
	public static final int CARNE = 1;
	public static final int QUEIJO = 2;
	public static final int SALADA = 3;
	public static final int BACON = 4;
	public static final int FRANGO = 5;
	
}
