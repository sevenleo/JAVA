package modelo;

import java.util.ArrayList;

public class FilaCliente {

	private ArrayList<Cliente> fila;
	
	public FilaCliente(){
		fila = new ArrayList<Cliente>();
	}
	
	public ArrayList<Cliente> getFila(){
		return fila;
	}
	
	public void add(Cliente c){
		fila.add(c);
	}
	
	public synchronized Cliente poll(int idCaixa){
		if (fila.isEmpty() == false){
			Cliente c = fila.get(0);
			fila.remove(0);
			System.out.println("Sou o caixa "+idCaixa+" e peguei o cliente "+c.getId());
			return c;
		}
		return null;
	}
	
	@Override
	public String toString(){
		int i;
		String str = "";
		
		for (i = 0; i < fila.size(); i++){
			str+=fila.get(i).toString()+"\n";
		}
		
		return str;
	}
}
