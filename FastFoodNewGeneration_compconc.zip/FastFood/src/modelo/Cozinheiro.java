package modelo;

import controlador.GerenciadorFila;

public class Cozinheiro extends Thread{

	private long id;
	private Pedido pedido;
	private FilaPedido filaPedido;
	private FilaPronto filaPronto;
	
	public Cozinheiro(int id){
		this.id = id;
		this.filaPedido = GerenciadorFila.getInstance().getFilaPedido();
		this.filaPronto = GerenciadorFila.getInstance().getFilaPronto();
		this.pedido = null;
	}
	
	public long getId(){
		return this.id;
	}
	
	@Override
	public void run() {
		try{
			while(true){
				if (pedido == null){//se nao possuir nenhum pedido, tenta pegar um na fila
					pedido = filaPedido.poll((int)this.id);
					if (pedido != null){//se pegou um pedido
						Thread.sleep(1000);//aparece na simulacao
						filaPronto.add(pedido);//prepara o pedido e adiciona na fila de pronto
						pedido = null;
					}
				}
				Thread.sleep(1000); 
			}
		}
		catch (InterruptedException ie) {
		}
	}
	
	@Override
	public String toString(){
		if (pedido != null){
			return "Pedido "+pedido.getIdCliente();
		}
		return "";
	}
}
