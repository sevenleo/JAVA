package modelo;

public class Refrigerante {

	public static final int ID_COLA = 6;
	public static final int ID_LARANJA = 7;
	public static final int ID_UVA = 8;
	
	private int id;
	private String nome;
	private double preco;
	
	public Refrigerante(int id){
		switch(id){
		case ID_COLA:
			this.id = ID_COLA;
			this.nome = "Cola";
			this.preco = 2.50;
		break;
		case ID_LARANJA:
			this.id = ID_LARANJA;
			this.nome = "Laranja";
			this.preco = 2.00;
		break;
		case ID_UVA:
			this.id = ID_UVA;
			this.nome = "Uva";
			this.preco = 2.00;
		break;
		}
	}
	
	public int getId(){
		return id;
	}
	public String getNome(){
		return nome;
	}
	public double getPreco(){
		return preco;
	}
	
}
