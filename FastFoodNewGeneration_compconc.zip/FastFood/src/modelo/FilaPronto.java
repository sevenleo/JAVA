package modelo;

import java.util.ArrayList;

public class FilaPronto {

	private ArrayList<Pedido> fila;
	
	public FilaPronto(){
		fila = new ArrayList<Pedido>();
	}
	
	public ArrayList<Pedido> getFila(){
		return fila;
	}
	
	public void add(Pedido p){
		fila.add(p);
	}
	public synchronized Pedido poll(int idEntregador){
		if (fila.isEmpty() == false){
			Pedido p = fila.get(0);
			fila.remove(0);
			System.out.println("Sou o entregador "+idEntregador+" e entreguei o pedido para o cliente "+p.getIdCliente());
			return p;
		}
		return null;
	}
	
	@Override
	public String toString(){
		int i;
		String str = "";
		
		for (i = 0; i < fila.size(); i++){
			str+="Pedido "+(fila.get(i).getIdCliente())+"\n";
		}
		
		return str;
	}
}
