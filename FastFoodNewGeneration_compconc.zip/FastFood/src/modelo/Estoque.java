package modelo;

import java.util.ArrayList;

import controlador.Simulador;

public class Estoque {

	private final int VALOR_INICIAL_ESTOQUE = 1000;
	private int[] materiaPrima;
	private static Estoque singleton = null;
	
	private Estoque(){
		this.materiaPrima = new int[9];
		this.inicializaMateriaPrima();
	}
	
	public static Estoque getInstance(){
		if (singleton == null){
			singleton = new Estoque();
		}
		return singleton;
	}
	
	private void inicializaMateriaPrima(){
		int i;
		
		for (i = 0; i < 9; i++){
			materiaPrima[i] = VALOR_INICIAL_ESTOQUE;
		}
	}
	
	public synchronized boolean verifica(int idCaixa,ArrayList<Integer> materiaPrimaUsada){
		if(materiaPrima[0] <= 0) {
			Simulador.getInstance().Fim();
			return false;
		}
		else{
			for (Integer i : materiaPrimaUsada) {
				if (materiaPrima[i] == 0){
					return false;
					//TODO: anunciar a falta dessa materia-prima para nao deixar o cliente pedir novamente algo que a utilize
				}
			}
			for (Integer i : materiaPrimaUsada) {
				if(materiaPrima[i]>0) materiaPrima[i]--;
				else return false;
			}
			System.out.println("Sou o caixa "+idCaixa+" e verifiquei o estoque!");
			return true;
		}
	}
	
	@Override
	public String toString(){
		String str = "";
		
		str+="P�o: "+materiaPrima[0]+"\n";
		str+="Carne: "+materiaPrima[1]+"\n";
		str+="Queijo: "+materiaPrima[2]+"\n";
		str+="Salada: "+materiaPrima[3]+"\n";
		str+="Bacon: "+materiaPrima[4]+"\n";
		str+="Frango: "+materiaPrima[5]+"\n";
		str+="Cola: "+materiaPrima[6]+"\n";
		str+="Laranja: "+materiaPrima[7]+"\n";
		str+="Uva: "+materiaPrima[8];
		
		return str;
	}
	
	public String toStringFile(){ //usado especialmente para escrever no registro
		String eol = System.getProperty("line.separator");
		String str = "";
		
		
		str+="P�o: "+materiaPrima[0]+eol;
		str+="Carne: "+materiaPrima[1]+eol;
		str+="Queijo: "+materiaPrima[2]+eol;
		str+="Salada: "+materiaPrima[3]+eol;
		str+="Bacon: "+materiaPrima[4]+eol;
		str+="Frango: "+materiaPrima[5]+eol;
		str+="Cola: "+materiaPrima[6]+eol;
		str+="Laranja: "+materiaPrima[7]+eol;
		str+="Uva: "+materiaPrima[8]+eol;
		
		return str;
	}
}
