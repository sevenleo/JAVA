package Play;


import java.util.Scanner;

import jogo.*;

public class Main {

	/**
	 * @param args
	 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Baralho mesa = new Baralho();
		mesa.emBaralha();
		
		Jogador p1;
		Jogador p2;
		
		
	while(true){
		System.out.println("////// Quer jogar m5 ou 21??\n");
		int escolha = new Scanner(System.in).nextInt();
		p1 = new Jogador("jogador");
		p2 = new Jogador("oponente");
		if (escolha==5)new Regras().melhor5(p1, p2, mesa);
		if (escolha==21)new Regras().jogo21(p1, p2, mesa);
	}
		

	}

}
