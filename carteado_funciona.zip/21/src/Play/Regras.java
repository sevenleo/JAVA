package Play;
import java.util.Scanner;

import jogo.Baralho;
import jogo.Jogador;

public class Regras {

	
	void melhor5(Jogador p1, Jogador p2,Baralho mesa){
		p1.puxa(5,mesa);
		p2.puxa(5,mesa);
		
		p1.show();
		p2.show();
		
		if ( p1.disputa(p2) )System.out.println("\n*****ganhou****");
		else System.out.println("\n****perdeu****");	
	}

	
	
	
	void jogo21(Jogador p1, Jogador p2,Baralho mesa){
		boolean mesaplay=true;
		
		p2.puxa(2, mesa);
		while(mesaplay){
			if( p2.getPontos() <= 15 ) p2.puxa(1, mesa);
			else mesaplay=false;
		}
		
		
		
		p1.puxa(2,mesa);
		while(p1.getPontos()<21){
			p1.show();
			System.out.println("\n\t\tQuer outra?");
			if (!new Scanner(System.in).next().equals("n")){
				p1.puxa(1, mesa);
			}
			else break;
		}
		
		System.out.println("\n\n\n\n\n\n");
		
		if (p1.getPontos()>21) {
			if (p2.getPontos()>21)System.out.println("empate");
			else System.out.println("perdeu");
		}

		else if (p2.getPontos()>21) System.out.println("ganhou");
		else if(p1.getPontos() == p2.getPontos())System.out.println("empate");
		else if(p1.getPontos() > p2.getPontos()) System.out.println("Ganhou");
		else System.out.println("perdeu");
		System.out.println("\n\n");
		p1.show();
		p2.show();
	}
	
	
	
	
}
