package jogo;

import Controle.ControleRemoto;

public class Jogador implements ControleRemoto {
	
	private String nome;
	private Baralho mao;
	private int pontos;
	
	
	public String getNome() {
		return nome;
	}

	
	public void setNome(String nome) {
		this.nome = nome;
	}
	

	public Baralho getMao() {
		return mao;
	}


	public void setMao(Baralho mao) {
		this.mao = mao;
	}


	public int getPontos() {
		return pontos;
	}


	public void setPontos(int pontos) {
		this.pontos = pontos;
	}

	
	
	
	
	
	
	
	
	public Jogador(String nom){
		nome=nom;
		mao=new Baralho();
		pontos=0;
		
	}

	
	public void show(){
		System.out.println("-------'"+nome+"' ------");
		System.out.println(" tem "+this.pontos+"pts");
		System.out.println(" tem as seguintes cartas");
		for (Carta es : this.mao.getMonte()) {
			//System.out.println(es);
			System.out.println(es.getNome()+" "+es.getNaipe());
		}
	}
	
	
	public void puxa(int n,Baralho b){
		if (n>b.getMonte().size()) System.err.println("Voce puxou cartas demais");
		else for(int i=0;i<n;i++){
			Carta temp=b.sorteia();
			mao.getMonte().add(temp);
			pontos = pontos+temp.getValor();
		}

	}
	
	
	public boolean disputa(Jogador a){
		boolean yn=false;
		if (this.pontos > a.getPontos()) yn=true;
		if (this.pontos == a.getPontos()) System.out.println("\n***empate = derrota xD");
		
		return yn;
	}


}
