package Controle;

public interface ControleRemoto {

	Controlador mix = new Controlador(); 
}
